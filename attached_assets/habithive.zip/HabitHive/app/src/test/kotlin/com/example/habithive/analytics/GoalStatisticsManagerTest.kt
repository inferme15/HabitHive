package com.example.habithive.analytics

import com.example.habithive.data.model.*
import com.example.habithive.data.repository.GoalRepository
import com.example.habithive.util.DateRange
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.util.*

class GoalStatisticsManagerTest {
    private lateinit var goalRepository: GoalRepository
    private lateinit var statisticsManager: GoalStatisticsManager

    @Before
    fun setup() {
        goalRepository = mockk()
        statisticsManager = GoalStatisticsManager(goalRepository)
    }

    @Test
    fun `getGoalStatistics returns correct statistics for empty goals`() = runTest {
        // Given
        val userId = "user1"
        val timeRange = DateRange.last7Days()
        coEvery { goalRepository.getUserGoals(userId) } returns flowOf(emptyList())

        // When
        val stats = statisticsManager.getGoalStatistics(userId, timeRange)

        // Then
        assertEquals(0, stats.totalGoals)
        assertEquals(0, stats.completedGoals)
        assertEquals(0, stats.activeGoals)
        assertEquals(0.0, stats.completionRate, 0.01)
        assertTrue(stats.averageCompletion.isEmpty())
        assertTrue(stats.goalsByType.isEmpty())
        assertTrue(stats.progressOverTime.isNotEmpty()) // Should have entries for each day
        assertEquals(0, stats.streaks.currentStreak)
        assertEquals(0, stats.streaks.longestStreak)
        assertTrue(stats.mostPopularTypes.isEmpty())
    }

    @Test
    fun `getGoalStatistics calculates correct statistics for mixed goals`() = runTest {
        // Given
        val userId = "user1"
        val timeRange = DateRange.last7Days()
        val now = System.currentTimeMillis()
        
        val goals = listOf(
            Goal(
                id = "1",
                userId = userId,
                type = GoalType.EXERCISE,
                exerciseTypes = listOf(ExerciseType.RUNNING),
                startDate = now - 5 * 24 * 60 * 60 * 1000,
                endDate = now + 2 * 24 * 60 * 60 * 1000,
                targetValue = 100,
                currentValue = 50,
                status = GoalStatus.ACTIVE
            ),
            Goal(
                id = "2",
                userId = userId,
                type = GoalType.EXERCISE,
                exerciseTypes = listOf(ExerciseType.RUNNING),
                startDate = now - 3 * 24 * 60 * 60 * 1000,
                endDate = now - 1 * 24 * 60 * 60 * 1000,
                targetValue = 100,
                currentValue = 100,
                status = GoalStatus.COMPLETED,
                completedAt = now - 1 * 24 * 60 * 60 * 1000
            )
        )

        coEvery { goalRepository.getUserGoals(userId) } returns flowOf(goals)

        // When
        val stats = statisticsManager.getGoalStatistics(userId, timeRange)

        // Then
        assertEquals(2, stats.totalGoals)
        assertEquals(1, stats.completedGoals)
        assertEquals(1, stats.activeGoals)
        assertEquals(50.0, stats.completionRate, 0.01)
        assertEquals(75.0, stats.averageCompletion[GoalType.EXERCISE], 0.01)
        
        val exerciseStats = stats.goalsByType[GoalType.EXERCISE]!!
        assertEquals(2, exerciseStats.total)
        assertEquals(1, exerciseStats.completed)
        assertEquals(150.0, exerciseStats.totalValue, 0.01)
        assertEquals(75.0, exerciseStats.averageValue, 0.01)

        assertTrue(stats.progressOverTime.isNotEmpty())
        assertEquals(1, stats.streaks.currentStreak)
        assertEquals(1, stats.streaks.longestStreak)
        
        val runningType = stats.mostPopularTypes.first()
        assertEquals(ExerciseType.RUNNING, runningType.type)
        assertEquals(2, runningType.count)
        assertEquals(50.0, runningType.successRate, 0.01)
    }

    @Test
    fun `getGoalStatistics calculates correct streak for consecutive completions`() = runTest {
        // Given
        val userId = "user1"
        val timeRange = DateRange.last7Days()
        val now = System.currentTimeMillis()
        
        val goals = listOf(
            Goal(
                id = "1",
                userId = userId,
                type = GoalType.EXERCISE,
                status = GoalStatus.COMPLETED,
                completedAt = now - 3 * 24 * 60 * 60 * 1000
            ),
            Goal(
                id = "2",
                userId = userId,
                type = GoalType.EXERCISE,
                status = GoalStatus.COMPLETED,
                completedAt = now - 2 * 24 * 60 * 60 * 1000
            ),
            Goal(
                id = "3",
                userId = userId,
                type = GoalType.EXERCISE,
                status = GoalStatus.COMPLETED,
                completedAt = now - 1 * 24 * 60 * 60 * 1000
            )
        )

        coEvery { goalRepository.getUserGoals(userId) } returns flowOf(goals)

        // When
        val stats = statisticsManager.getGoalStatistics(userId, timeRange)

        // Then
        assertEquals(3, stats.streaks.currentStreak)
        assertEquals(3, stats.streaks.longestStreak)
    }

    @Test
    fun `getGoalStatistics handles broken streaks correctly`() = runTest {
        // Given
        val userId = "user1"
        val timeRange = DateRange.last7Days()
        val now = System.currentTimeMillis()
        
        val goals = listOf(
            Goal(
                id = "1",
                userId = userId,
                type = GoalType.EXERCISE,
                status = GoalStatus.COMPLETED,
                completedAt = now - 5 * 24 * 60 * 60 * 1000
            ),
            Goal(
                id = "2",
                userId = userId,
                type = GoalType.EXERCISE,
                status = GoalStatus.COMPLETED,
                completedAt = now - 4 * 24 * 60 * 60 * 1000
            ),
            Goal(
                id = "3",
                userId = userId,
                type = GoalType.EXERCISE,
                status = GoalStatus.COMPLETED,
                completedAt = now - 2 * 24 * 60 * 60 * 1000
            )
        )

        coEvery { goalRepository.getUserGoals(userId) } returns flowOf(goals)

        // When
        val stats = statisticsManager.getGoalStatistics(userId, timeRange)

        // Then
        assertEquals(1, stats.streaks.currentStreak)
        assertEquals(2, stats.streaks.longestStreak)
    }
} 