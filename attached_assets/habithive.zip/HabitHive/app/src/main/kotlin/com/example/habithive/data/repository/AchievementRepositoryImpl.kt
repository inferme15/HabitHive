package com.example.habithive.data.repository

import com.example.habithive.data.model.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton

@Singleton
class AchievementRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore,
    @Named("achievements") private val achievementsCollection: CollectionReference,
    @Named("user_achievements") private val userAchievementsCollection: CollectionReference,
    private val exerciseRepository: ExerciseRepository,
    private val goalRepository: GoalRepository,
    private val friendRepository: FriendRepository,
    private val communityRepository: CommunityRepository
) : AchievementRepository {

    override suspend fun getAllAchievements(): List<Achievement> {
        return achievementsCollection
            .get()
            .await()
            .toObjects(Achievement::class.java)
    }

    override suspend fun getUserAchievements(userId: String): List<UserAchievement> {
        return userAchievementsCollection
            .whereEqualTo("userId", userId)
            .get()
            .await()
            .toObjects(UserAchievement::class.java)
            .map { userAchievement ->
                // Fetch the full achievement data
                val achievement = achievementsCollection
                    .document(userAchievement.achievementId)
                    .get()
                    .await()
                    .toObject(Achievement::class.java)
                userAchievement.copy(achievement = achievement)
            }
    }

    override fun getUserAchievementsFlow(userId: String): Flow<List<UserAchievement>> {
        return userAchievementsCollection
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(UserAchievement::class.java)
                    .map { userAchievement ->
                        val achievement = achievementsCollection
                            .document(userAchievement.achievementId)
                            .get()
                            .await()
                            .toObject(Achievement::class.java)
                        userAchievement.copy(achievement = achievement)
                    }
            }
    }

    override suspend fun updateUserAchievementProgress(
        userId: String,
        achievementId: String,
        progress: Int
    ) {
        val userAchievementDoc = userAchievementsCollection
            .document("${userId}_${achievementId}")

        val achievement = achievementsCollection
            .document(achievementId)
            .get()
            .await()
            .toObject(Achievement::class.java)
            ?: throw IllegalStateException("Achievement not found")

        val currentUserAchievement = userAchievementDoc
            .get()
            .await()
            .toObject(UserAchievement::class.java)

        val updatedUserAchievement = if (currentUserAchievement == null) {
            UserAchievement(
                userId = userId,
                achievementId = achievementId,
                achievement = achievement,
                progress = progress,
                isCompleted = progress >= achievement.requirement
            )
        } else {
            currentUserAchievement.copy(
                progress = progress,
                isCompleted = progress >= achievement.requirement
            )
        }

        userAchievementDoc.set(updatedUserAchievement).await()

        if (updatedUserAchievement.isCompleted && currentUserAchievement?.isCompleted != true) {
            completeAchievement(userId, achievementId)
        }
    }

    override suspend fun completeAchievement(userId: String, achievementId: String) {
        val userAchievementDoc = userAchievementsCollection
            .document("${userId}_${achievementId}")

        firestore.runTransaction { transaction ->
            val userAchievement = transaction
                .get(userAchievementDoc)
                .toObject(UserAchievement::class.java)
                ?: throw IllegalStateException("User achievement not found")

            if (!userAchievement.isCompleted) {
                transaction.set(
                    userAchievementDoc,
                    userAchievement.copy(
                        isCompleted = true,
                        completedAt = System.currentTimeMillis()
                    )
                )
            }
        }.await()
    }

    override suspend fun checkAndUpdateAchievements(userId: String) {
        val achievements = getAllAchievements()
        
        for (achievement in achievements) {
            val progress = when (achievement.type) {
                AchievementCategory.EXERCISE_COUNT -> {
                    exerciseRepository.getUserExerciseCount(userId)
                }
                AchievementCategory.EXERCISE_DURATION -> {
                    exerciseRepository.getUserTotalExerciseDuration(userId)
                }
                AchievementCategory.CALORIES_BURNED -> {
                    exerciseRepository.getUserTotalCaloriesBurned(userId)
                }
                AchievementCategory.GOALS_COMPLETED -> {
                    goalRepository.getUserCompletedGoalsCount(userId)
                }
                AchievementCategory.STREAK_DAYS -> {
                    exerciseRepository.getUserCurrentStreak(userId)
                }
                AchievementCategory.FRIEND_COUNT -> {
                    friendRepository.getFriends(userId).size
                }
                AchievementCategory.COMMUNITY_POSTS -> {
                    communityRepository.getUserPosts(userId).size
                }
                AchievementCategory.GENERAL -> {
                    continue // General achievements are handled separately
                }
            }
            
            updateUserAchievementProgress(userId, achievement.id, progress)
        }
    }

    override suspend fun awardAchievement(userId: String, achievementId: String) {
        val achievement = achievementsCollection
            .document(achievementId)
            .get()
            .await()
            .toObject(Achievement::class.java)
            ?: throw IllegalStateException("Achievement not found")

        val userAchievementDoc = userAchievementsCollection
            .document("${userId}_${achievementId}")

        val currentUserAchievement = userAchievementDoc
            .get()
            .await()
            .toObject(UserAchievement::class.java)

        if (currentUserAchievement?.isCompleted != true) {
            val updatedUserAchievement = UserAchievement(
                userId = userId,
                achievementId = achievementId,
                achievement = achievement,
                progress = achievement.requirement,
                isCompleted = true,
                completedAt = System.currentTimeMillis()
            )

            userAchievementDoc.set(updatedUserAchievement).await()
        }
    }
} 