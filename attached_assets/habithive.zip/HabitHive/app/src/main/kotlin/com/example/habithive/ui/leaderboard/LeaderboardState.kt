package com.example.habithive.ui.leaderboard

import com.example.habithive.data.model.LeaderboardEntry
import com.example.habithive.data.model.LeaderboardStats
import com.example.habithive.data.model.LeaderboardType

sealed class LeaderboardState {
    object Loading : LeaderboardState()
    data class Success(
        val type: LeaderboardType,
        val stats: LeaderboardStats,
        val userEntry: LeaderboardEntry?
    ) : LeaderboardState()
    data class Error(val message: String) : LeaderboardState()
}

data class LeaderboardFilter(
    val type: LeaderboardType = LeaderboardType.GLOBAL,
    val showFriendsOnly: Boolean = false
) 