package com.example.habithive.util

interface UiState {
} 