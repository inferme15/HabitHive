package com.example.habithive.data.model

import kotlinx.serialization.Serializable
import com.example.habithive.data.model.ExerciseType

@Serializable
enum class GoalStatus {
    ACTIVE,
    COMPLETED,
    FAILED,
    ARCHIVED
}

@Serializable
enum class GoalType {
    EXERCISE,
    STEPS,
    DISTANCE,
    CALORIES,
    WATER,
    SLEEP,
    MEDITATION,
    CUSTOM
}

@Serializable
data class Goal(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val description: String = "",
    val type: GoalType = GoalType.CUSTOM,
    val exerciseTypes: List<ExerciseType> = emptyList(),
    val startDate: Long = System.currentTimeMillis(),
    val endDate: Long = System.currentTimeMillis() + 7 * 24 * 60 * 60 * 1000, // 1 week default
    val targetValue: Int = 0,
    val currentValue: Int = 0,
    val unit: String = "",
    val status: GoalStatus = GoalStatus.ACTIVE,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val COLLECTION = "goals"
    }
} 