package com.example.habithive.services

import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.IBinder
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.preference.PreferenceManager
import java.util.*

class StepCounterService : Service(), SensorEventListener {
    private var sensorManager: SensorManager? = null
    private var stepSensor: Sensor? = null
    private var _stepCount = MutableLiveData<Int>(0)
    private var _distance = MutableLiveData<Float>(0f)
    private var _calories = MutableLiveData<Int>(0)
    private var lastStepCount = 0
    private var startTime: Long = 0
    private lateinit var prefs: SharedPreferences

    companion object {
        val stepCount: LiveData<Int> get() = _instance._stepCount
        val distance: LiveData<Float> get() = _instance._distance
        val calories: LiveData<Int> get() = _instance._calories
        private lateinit var _instance: StepCounterService
        
        private const val PREF_LAST_STEP_COUNT = "last_step_count"
        private const val PREF_LAST_SAVE_DATE = "last_save_date"
    }

    override fun onCreate() {
        super.onCreate()
        _instance = this
        prefs = PreferenceManager.getDefaultSharedPreferences(this)
        startTime = System.currentTimeMillis()
        
        // Check if we need to reset (new day)
        checkAndResetDaily()
        
        // Load saved values
        lastStepCount = prefs.getInt(PREF_LAST_STEP_COUNT, 0)
        _stepCount.value = lastStepCount
        
        setupSensor()
    }

    private fun checkAndResetDaily() {
        val lastSaveDate = prefs.getString(PREF_LAST_SAVE_DATE, "")
        val today = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
        }.get(Calendar.DAY_OF_YEAR).toString()
        
        if (lastSaveDate != today) {
            // Reset counters for new day
            prefs.edit().apply {
                putInt(PREF_LAST_STEP_COUNT, 0)
                putString(PREF_LAST_SAVE_DATE, today)
            }.apply()
            
            lastStepCount = 0
            _stepCount.postValue(0)
            _distance.postValue(0f)
            _calories.postValue(0)
        }
    }

    private fun setupSensor() {
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        stepSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        stepSensor?.let {
            sensorManager?.registerListener(
                this,
                it,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            if (it.sensor.type == Sensor.TYPE_STEP_COUNTER) {
                if (lastStepCount == 0) {
                    lastStepCount = it.values[0].toInt()
                }
                val steps = it.values[0].toInt() - lastStepCount
                _stepCount.postValue(steps)
                
                // Save step count
                prefs.edit().putInt(PREF_LAST_STEP_COUNT, steps).apply()
                
                // Calculate distance (rough estimate: average step length = 0.762 meters)
                val distanceInKm = (steps * 0.762f) / 1000f
                _distance.postValue(distanceInKm)
                
                // Calculate calories (rough estimate: 0.04 calories per step)
                val caloriesBurned = (steps * 0.04).toInt()
                _calories.postValue(caloriesBurned)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Not needed for step counter
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        sensorManager?.unregisterListener(this)
    }
} 