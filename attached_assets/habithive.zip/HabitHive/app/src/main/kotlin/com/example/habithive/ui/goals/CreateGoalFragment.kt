package com.example.habithive.ui.goals

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.example.habithive.R
import com.example.habithive.data.model.ExerciseType
import com.example.habithive.data.model.GoalFrequency
import com.example.habithive.data.model.GoalType
import com.example.habithive.databinding.FragmentCreateGoalBinding
import com.example.habithive.util.showError
import com.example.habithive.util.viewBinding
import com.google.android.material.chip.Chip
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@AndroidEntryPoint
class CreateGoalFragment : Fragment(R.layout.fragment_create_goal) {

    private val binding by viewBinding(FragmentCreateGoalBinding::bind)
    private val viewModel: GoalViewModel by viewModels()
    private var selectedEndDate: Long = 0
    private var selectedReminderTime: Long = 0

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeState()
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collect { state ->
                    when (state) {
                        is GoalState.Loading -> showLoading(true)
                        is GoalState.Success -> {
                            showLoading(false)
                            findNavController().navigateUp()
                            Snackbar.make(requireView(), "Goal created successfully!", Snackbar.LENGTH_SHORT).show()
                        }
                        is GoalState.Error -> {
                            showLoading(false)
                            showError(state.message)
                        }
                        is GoalState.Idle -> showLoading(false)
                    }
                }
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.isVisible = isLoading
        binding.createButton.isEnabled = !isLoading
    }

    private fun setupUI() {
        setupToolbar()
        setupDropdowns()
        setupExerciseTypes()
        setupDatePicker()
        setupReminder()
        setupCreateButton()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun setupDropdowns() {
        // Goal Type Dropdown
        val goalTypes = GoalType.values().map { it.name.replace("_", " ") }
        val goalTypeAdapter = ArrayAdapter(
            requireContext(),
            R.layout.item_dropdown,
            goalTypes
        )
        binding.goalTypeDropdown.setAdapter(goalTypeAdapter)

        // Frequency Dropdown
        val frequencies = GoalFrequency.values().map { it.name.replace("_", " ") }
        val frequencyAdapter = ArrayAdapter(
            requireContext(),
            R.layout.item_dropdown,
            frequencies
        )
        binding.frequencyDropdown.setAdapter(frequencyAdapter)
    }

    private fun setupExerciseTypes() {
        ExerciseType.values().forEach { type ->
            val chip = Chip(requireContext()).apply {
                text = type.name.replace("_", " ")
                isCheckable = true
            }
            binding.exerciseTypesChipGroup.addView(chip)
        }
    }

    private fun setupDatePicker() {
        binding.endDateInput.setOnClickListener {
            showDatePicker()
        }
    }

    private fun setupReminder() {
        binding.reminderSwitch.setOnCheckedChangeListener { _, isChecked ->
            binding.reminderTimeLayout.isVisible = isChecked
        }

        binding.reminderTimeInput.setOnClickListener {
            showTimePicker()
        }
    }

    private fun setupCreateButton() {
        binding.createButton.setOnClickListener {
            if (validateInputs()) {
                createGoal()
            }
        }
    }

    private fun validateInputs(): Boolean {
        with(binding) {
            var isValid = true

            if (titleInput.text.isNullOrBlank()) {
                titleInput.error = "Title is required"
                isValid = false
            }

            if (goalTypeDropdown.text.isNullOrBlank()) {
                goalTypeDropdown.error = "Goal type is required"
                isValid = false
            }

            if (targetValueInput.text.isNullOrBlank()) {
                targetValueInput.error = "Target value is required"
                isValid = false
            }

            if (frequencyDropdown.text.isNullOrBlank()) {
                frequencyDropdown.error = "Frequency is required"
                isValid = false
            }

            if (selectedEndDate == 0L) {
                endDateInput.error = "End date is required"
                isValid = false
            }

            if (binding.reminderSwitch.isChecked && selectedReminderTime == 0L) {
                reminderTimeInput.error = "Reminder time is required"
                isValid = false
            }

            if (exerciseTypesChipGroup.checkedChipIds.isEmpty()) {
                showError("Please select at least one exercise type")
                isValid = false
            }

            return isValid
        }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        DatePickerDialog(
            requireContext(),
            { _, year, month, day ->
                calendar.set(year, month, day)
                selectedEndDate = calendar.timeInMillis
                binding.endDateInput.setText(
                    SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                        .format(calendar.time)
                )
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun showTimePicker() {
        val calendar = Calendar.getInstance()
        TimePickerDialog(
            requireContext(),
            { _, hour, minute ->
                calendar.set(Calendar.HOUR_OF_DAY, hour)
                calendar.set(Calendar.MINUTE, minute)
                selectedReminderTime = calendar.timeInMillis
                binding.reminderTimeInput.setText(
                    SimpleDateFormat("hh:mm a", Locale.getDefault())
                        .format(calendar.time)
                )
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            false
        ).show()
    }

    private fun createGoal() {
        with(binding) {
            val title = titleInput.text.toString()
            val description = descriptionInput.text.toString()
            val goalType = GoalType.valueOf(
                goalTypeDropdown.text.toString().replace(" ", "_")
            )
            val targetValue = targetValueInput.text.toString().toDouble()
            val frequency = GoalFrequency.valueOf(
                frequencyDropdown.text.toString().replace(" ", "_")
            )
            
            val selectedTypes = exerciseTypesChipGroup.checkedChipIds.mapNotNull { id ->
                val chip = exerciseTypesChipGroup.findViewById<Chip>(id)
                ExerciseType.valueOf(chip.text.toString().replace(" ", "_"))
            }.toSet()

            viewModel.createGoal(
                title = title,
                description = description,
                goalType = goalType,
                targetValue = targetValue,
                frequency = frequency,
                endDate = Date(selectedEndDate),
                reminderTime = if (reminderSwitch.isChecked) Date(selectedReminderTime) else null,
                exerciseTypes = selectedTypes
            )
        }
    }
} 