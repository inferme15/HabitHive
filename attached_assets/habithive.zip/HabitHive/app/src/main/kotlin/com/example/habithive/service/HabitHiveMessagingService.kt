package com.example.habithive.service

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.example.habithive.util.NotificationHelper

class HabitHiveMessagingService : FirebaseMessagingService() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createNotificationChannel(this)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        message.notification?.let { notification ->
            NotificationHelper.showNotification(
                context = this,
                title = notification.title ?: "HabitHive",
                message = notification.body ?: ""
            )
        }
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // TODO: Send token to server for future notifications
        // This could be implemented later when we have a backend service
    }
} 