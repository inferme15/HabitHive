package com.example.habithive.ui.community

import android.net.Uri
import androidx.lifecycle.viewModelScope
import com.example.habithive.base.BaseViewModel
import com.example.habithive.data.model.Comment
import com.example.habithive.data.model.Post
import com.example.habithive.data.repository.CommunityRepository
import com.example.habithive.data.repository.UserRepository
import com.example.habithive.util.NetworkUtils
import com.google.firebase.storage.FirebaseStorage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

@HiltViewModel
class CommunityViewModel @Inject constructor(
    private val communityRepository: CommunityRepository,
    private val userRepository: UserRepository,
    private val storage: FirebaseStorage,
    private val networkUtils: NetworkUtils
) : BaseViewModel() {

    private val _communityState = MutableStateFlow<CommunityState>(CommunityState.Loading)
    val communityState: StateFlow<CommunityState> = _communityState

    private val _postState = MutableStateFlow<PostState>(PostState.Loading)
    val postState: StateFlow<PostState> = _postState

    private val _postCreationState = MutableStateFlow<PostCreationState>(PostCreationState.Idle)
    val postCreationState: StateFlow<PostCreationState> = _postCreationState

    init {
        loadPosts()
    }

    fun loadPosts() {
        if (!networkUtils.isNetworkAvailable()) {
            _communityState.value = CommunityState.Error("No internet connection")
            return
        }

        viewModelScope.launch {
            _communityState.value = CommunityState.Loading
            safeCall(
                onError = { _communityState.value = CommunityState.Error(it.message ?: "Failed to load posts") }
            ) {
                val allPosts = communityRepository.getAllPosts()
                val trendingPosts = communityRepository.getTrendingPosts()
                val currentUser = userRepository.getCurrentUser()
                    ?: throw IllegalStateException("User not found")
                val userPosts = communityRepository.getUserPosts(currentUser.id)

                _communityState.value = CommunityState.Success(
                    posts = allPosts,
                    trendingPosts = trendingPosts,
                    userPosts = userPosts
                )
            }
        }
    }

    fun createPost(content: String, imageUri: Uri? = null, type: PostType = PostType.GENERAL) {
        if (!networkUtils.isNetworkAvailable()) {
            _postCreationState.value = PostCreationState.Error("No internet connection")
            return
        }

        viewModelScope.launch {
            _postCreationState.value = PostCreationState.Loading
            safeCall(
                onError = { _postCreationState.value = PostCreationState.Error(it.message ?: "Failed to create post") }
            ) {
                val currentUser = userRepository.getCurrentUser()
                    ?: throw IllegalStateException("User not found")

                var imageUrl: String? = null
                if (imageUri != null) {
                    val imageRef = storage.reference.child("post_images/${System.currentTimeMillis()}")
                    imageRef.putFile(imageUri).await()
                    imageUrl = imageRef.downloadUrl.await().toString()
                }

                val post = Post(
                    userId = currentUser.id,
                    userName = currentUser.name,
                    userPhotoUrl = currentUser.photoUrl,
                    content = content,
                    imageUrl = imageUrl,
                    type = type
                )

                communityRepository.createPost(post)
                _postCreationState.value = PostCreationState.Success
                loadPosts() // Refresh posts
            }
        }
    }

    fun loadPost(postId: String) {
        viewModelScope.launch {
            _postState.value = PostState.Loading
            safeCall(
                onError = { _postState.value = PostState.Error(it.message ?: "Failed to load post") }
            ) {
                val post = communityRepository.getPost(postId)
                    ?: throw IllegalStateException("Post not found")
                val comments = communityRepository.getComments(postId)
                val isLiked = communityRepository.isPostLiked(postId)

                _postState.value = PostState.Success(
                    post = post,
                    comments = comments,
                    likes = post.likes,
                    isLiked = isLiked
                )
            }
        }
    }

    fun toggleLike(postId: String) {
        viewModelScope.launch {
            safeCall {
                val isLiked = communityRepository.isPostLiked(postId)
                if (isLiked) {
                    communityRepository.unlikePost(postId)
                } else {
                    communityRepository.likePost(postId)
                }
                loadPost(postId) // Refresh post state
            }
        }
    }

    fun addComment(postId: String, content: String) {
        viewModelScope.launch {
            safeCall {
                val currentUser = userRepository.getCurrentUser()
                    ?: throw IllegalStateException("User not found")

                val comment = Comment(
                    postId = postId,
                    userId = currentUser.id,
                    userName = currentUser.name,
                    userPhotoUrl = currentUser.photoUrl,
                    content = content
                )

                communityRepository.addComment(comment)
                loadPost(postId) // Refresh post state
            }
        }
    }

    fun deletePost(postId: String) {
        viewModelScope.launch {
            safeCall {
                communityRepository.deletePost(postId)
                loadPosts() // Refresh posts
            }
        }
    }

    fun deleteComment(commentId: String, postId: String) {
        viewModelScope.launch {
            safeCall {
                communityRepository.deleteComment(commentId)
                loadPost(postId) // Refresh post state
            }
        }
    }
} 