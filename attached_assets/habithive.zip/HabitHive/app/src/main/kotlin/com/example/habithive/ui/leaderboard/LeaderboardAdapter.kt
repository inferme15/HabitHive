package com.example.habithive.ui.leaderboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.habithive.R
import com.example.habithive.data.model.LeaderboardEntry
import com.example.habithive.databinding.ItemLeaderboardEntryBinding

class LeaderboardAdapter(
    private val currentUserId: String
) : ListAdapter<LeaderboardEntry, LeaderboardAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemLeaderboardEntryBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: ItemLeaderboardEntryBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(entry: LeaderboardEntry) {
            with(binding) {
                rankTextView.text = "#${entry.rank}"
                userNameTextView.text = entry.userName
                
                // Load user photo
                Glide.with(userPhotoImageView)
                    .load(entry.userPhotoUrl)
                    .placeholder(R.drawable.ic_profile_placeholder)
                    .circleCrop()
                    .into(userPhotoImageView)

                // Format stats text
                statsTextView.text = itemView.context.getString(
                    R.string.leaderboard_stats_format,
                    entry.exerciseMinutes,
                    entry.goalsCompleted,
                    entry.currentStreak
                )

                scoreTextView.text = entry.score.toString()

                // Highlight current user
                root.setBackgroundResource(
                    if (entry.userId == currentUserId) {
                        R.drawable.bg_leaderboard_current_user
                    } else {
                        android.R.color.transparent
                    }
                )
            }
        }
    }

    private class DiffCallback : DiffUtil.ItemCallback<LeaderboardEntry>() {
        override fun areItemsTheSame(oldItem: LeaderboardEntry, newItem: LeaderboardEntry): Boolean {
            return oldItem.userId == newItem.userId
        }

        override fun areContentsTheSame(oldItem: LeaderboardEntry, newItem: LeaderboardEntry): Boolean {
            return oldItem == newItem
        }
    }
} 