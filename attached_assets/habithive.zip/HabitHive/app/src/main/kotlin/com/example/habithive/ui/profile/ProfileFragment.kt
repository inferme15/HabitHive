package com.example.habithive.ui.profile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.google.android.material.datepicker.MaterialDatePicker
import com.example.habithive.R
import com.example.habithive.databinding.FragmentProfileBinding
import com.example.habithive.data.model.User
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.launch

@AndroidEntryPoint
class ProfileFragment : Fragment() {
    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ProfileViewModel by viewModels()
    private var selectedImageUri: Uri? = null
    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    private val getContent = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                viewModel.updateProfilePhoto(uri)
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        setupSpinners()
        observeViewModel()
    }

    private fun setupUI() {
        binding.btnEditProfile.setOnClickListener {
            // Handle edit profile click
        }

        binding.btnSignOut.setOnClickListener {
            viewModel.signOut()
        }

        binding.btnChangePhoto.setOnClickListener {
            openImagePicker()
        }

        binding.btnSave.setOnClickListener {
            saveProfile()
        }

        binding.birthDateInput.editText?.setOnClickListener {
            showDatePicker()
        }
    }

    private fun setupSpinners() {
        // Gender spinner
        val genders = arrayOf("Male", "Female", "Other", "Prefer not to say")
        val genderAdapter = ArrayAdapter(requireContext(), R.layout.dropdown_item, genders)
        (binding.genderInput.editText as? AutoCompleteTextView)?.setAdapter(genderAdapter)

        // Fitness level spinner
        val fitnessLevels = arrayOf("Beginner", "Intermediate", "Advanced", "Expert")
        val fitnessAdapter = ArrayAdapter(requireContext(), R.layout.dropdown_item, fitnessLevels)
        (binding.fitnessLevelInput.editText as? AutoCompleteTextView)?.setAdapter(fitnessAdapter)

        // Units spinner
        val units = arrayOf("Metric", "Imperial")
        val unitsAdapter = ArrayAdapter(requireContext(), R.layout.dropdown_item, units)
        (binding.unitsInput.editText as? AutoCompleteTextView)?.setAdapter(unitsAdapter)

        // Theme spinner
        val themes = arrayOf("System", "Light", "Dark")
        val themeAdapter = ArrayAdapter(requireContext(), R.layout.dropdown_item, themes)
        (binding.themeInput.editText as? AutoCompleteTextView)?.setAdapter(themeAdapter)
    }

    private fun showDatePicker() {
        val picker = MaterialDatePicker.Builder.datePicker()
            .setTitleText("Select birth date")
            .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
            .build()

        picker.addOnPositiveButtonClickListener { selection ->
            val date = Date(selection)
            binding.birthDateInput.editText?.setText(dateFormat.format(date))
            binding.birthDateInput.editText?.tag = date
        }

        picker.show(parentFragmentManager, "DATE_PICKER")
    }

    private fun saveProfile() {
        val currentUser = viewModel.profileState.value.user ?: return
        
        val name = binding.nameInput.editText?.text?.toString() ?: ""
        val email = binding.emailInput.editText?.text?.toString() ?: ""
        val height = binding.heightInput.editText?.text?.toString()?.toFloatOrNull()
        val weight = binding.weightInput.editText?.text?.toString()?.toFloatOrNull()
        val birthDate = binding.birthDateInput.editText?.tag as? Date ?: currentUser.birthDate
        val gender = (binding.genderInput.editText as? AutoCompleteTextView)?.text?.toString()
        val fitnessLevel = (binding.fitnessLevelInput.editText as? AutoCompleteTextView)?.text?.toString()
        val notifications = binding.notificationsSwitch.isChecked
        val units = (binding.unitsInput.editText as? AutoCompleteTextView)?.text?.toString()
        val theme = (binding.themeInput.editText as? AutoCompleteTextView)?.text?.toString()

        if (validateInput(name, email)) {
            val updatedUser = currentUser.copy(
                name = name,
                email = email,
                height = height ?: currentUser.height,
                weight = weight ?: currentUser.weight,
                birthDate = birthDate,
                gender = gender?.takeIf { it.isNotBlank() } ?: currentUser.gender,
                fitnessLevel = fitnessLevel?.takeIf { it.isNotBlank() } ?: currentUser.fitnessLevel,
                preferences = User.Preferences(
                    notifications = notifications,
                    units = units?.takeIf { it.isNotBlank() } ?: currentUser.preferences?.units ?: "Metric",
                    theme = theme?.takeIf { it.isNotBlank() } ?: currentUser.preferences?.theme ?: "System"
                )
            )
            viewModel.updateProfile(updatedUser)
        }
    }

    private fun validateInput(name: String, email: String): Boolean {
        var isValid = true

        if (name.isBlank()) {
            binding.nameInput.error = "Name is required"
            isValid = false
        } else {
            binding.nameInput.error = null
        }

        if (email.isBlank()) {
            binding.emailInput.error = "Email is required"
            isValid = false
        } else {
            binding.emailInput.error = null
        }

        return isValid
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.profileState.collect { state ->
                    binding.progressBar.visibility = if (state.isLoading) View.VISIBLE else View.GONE
                    
                    state.user?.let { user ->
                        updateUI(user)
                    }
                    
                    state.error?.let { error ->
                        Snackbar.make(requireView(), error, Snackbar.LENGTH_LONG).show()
                    }

                    if (state.isSignedOut) {
                        findNavController().navigate(R.id.action_profileFragment_to_signInFragment)
                    }
                }
            }
        }
    }

    private fun updateUI(user: User) {
        binding.apply {
            tvName.text = user.name
            tvEmail.text = user.email
            tvPoints.text = "${user.points} points"
            tvStreak.text = "${user.streakCount} days"
            
            Glide.with(requireContext())
                .load(user.photoUrl)
                .placeholder(R.drawable.default_profile)
                .error(R.drawable.default_profile)
                .circleCrop()
                .into(ivProfile)
        }
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
        }
        getContent.launch(intent)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        fun newInstance() = ProfileFragment()
    }
} 