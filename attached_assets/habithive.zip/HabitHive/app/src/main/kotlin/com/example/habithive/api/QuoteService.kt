package com.example.habithive.api

import kotlinx.serialization.Serializable
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface QuoteService {
    @GET("random")
    suspend fun getRandomQuote(@Query("tags") tags: String = "inspirational,fitness,health"): Response<Quote>
}

@Serializable
data class Quote(
    val _id: String,
    val content: String,
    val author: String,
    val tags: List<String>
) 