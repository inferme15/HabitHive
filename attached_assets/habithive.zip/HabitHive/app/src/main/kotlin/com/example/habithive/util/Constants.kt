package com.example.habithive.util

object Constants {
    // Firebase Collections
    const val USERS_COLLECTION = "users"
    const val EXERCISES_COLLECTION = "exercises"
    const val FRIEND_REQUESTS_COLLECTION = "friend_requests"
    const val DAILY_SUMMARIES_COLLECTION = "daily_summaries"
    const val ACHIEVEMENTS_COLLECTION = "achievements"
    const val GOALS_COLLECTION = "goals"

    // Shared Preferences
    const val PREFS_NAME = "HabitHivePrefs"
    const val KEY_USER_ID = "user_id"
    const val KEY_USER_NAME = "user_name"
    const val KEY_USER_EMAIL = "user_email"
    const val KEY_USER_PHOTO = "user_photo"
    const val KEY_THEME = "theme"
    const val KEY_NOTIFICATIONS = "notifications"

    // Request Codes
    const val RC_SIGN_IN = 9001
    const val RC_PHOTO_PICKER = 9002

    // Notification Channels
    const val CHANNEL_EXERCISES = "exercises"
    const val CHANNEL_GOALS = "goals"
    const val CHANNEL_FRIENDS = "friends"

    // Time Constants
    const val ONE_DAY_MILLIS = 24 * 60 * 60 * 1000L
    const val ONE_WEEK_MILLIS = 7 * ONE_DAY_MILLIS

    // Exercise Types
    val EXERCISE_TYPES = listOf(
        "Running",
        "Walking",
        "Cycling",
        "Swimming",
        "Yoga",
        "Weightlifting",
        "HIIT",
        "Other"
    )

    // Goal Types
    val GOAL_FREQUENCIES = listOf(
        "Daily",
        "Weekly",
        "Monthly"
    )

    // Error Messages
    const val ERROR_NO_USER = "User not found"
    const val ERROR_NO_INTERNET = "No internet connection"
    const val ERROR_GENERIC = "Something went wrong"
    const val ERROR_INVALID_INPUT = "Please check your input"
} 