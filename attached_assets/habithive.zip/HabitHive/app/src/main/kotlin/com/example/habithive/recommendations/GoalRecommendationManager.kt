package com.example.habithive.recommendations

import com.example.habithive.data.model.*
import com.example.habithive.data.repository.GoalRepository
import com.example.habithive.data.repository.UserRepository
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoalRecommendationManager @Inject constructor(
    private val goalRepository: GoalRepository,
    private val userRepository: UserRepository,
    private val statisticsManager: GoalStatisticsManager
) {
    suspend fun getRecommendations(userId: String): List<GoalRecommendation> {
        val user = userRepository.getUserById(userId).first()
        val userGoals = goalRepository.getUserGoals(userId).first()
        val statistics = statisticsManager.getGoalStatistics(userId, DateRange.MONTH)

        val recommendations = mutableListOf<GoalRecommendation>()

        // Add progression-based recommendations
        recommendations.addAll(generateProgressionRecommendations(userGoals, statistics))

        // Add habit-based recommendations
        recommendations.addAll(generateHabitRecommendations(statistics))

        // Add user preference-based recommendations
        recommendations.addAll(generatePreferenceBasedRecommendations(user, statistics))

        // Add community-based recommendations
        recommendations.addAll(generateCommunityRecommendations(user))

        return recommendations.sortedByDescending { it.relevanceScore }
    }

    private fun generateProgressionRecommendations(
        userGoals: List<Goal>,
        statistics: GoalStatistics
    ): List<GoalRecommendation> {
        val recommendations = mutableListOf<GoalRecommendation>()

        // Analyze completed goals for progression patterns
        userGoals.filter { it.status == GoalStatus.COMPLETED }
            .groupBy { it.type }
            .forEach { (type, goals) ->
                val lastGoal = goals.maxByOrNull { it.completedAt!! }
                if (lastGoal != null) {
                    // Suggest a more challenging goal based on the last completion
                    val progressionFactor = calculateProgressionFactor(goals)
                    val nextTarget = lastGoal.targetValue * progressionFactor

                    recommendations.add(
                        GoalRecommendation(
                            title = generateProgressionTitle(type, nextTarget),
                            description = "Based on your successful completion of previous goals",
                            type = type,
                            targetValue = nextTarget,
                            difficulty = calculateDifficulty(nextTarget, statistics),
                            relevanceScore = calculateRelevanceScore(type, statistics),
                            recommendationType = RecommendationType.PROGRESSION
                        )
                    )
                }
            }

        return recommendations
    }

    private fun generateHabitRecommendations(
        statistics: GoalStatistics
    ): List<GoalRecommendation> {
        val recommendations = mutableListOf<GoalRecommendation>()

        // Analyze exercise patterns
        statistics.mostPopularTypes.forEach { popularType ->
            if (popularType.successRate >= 70.0) {
                // Suggest streak-based goals for successful exercise types
                recommendations.add(
                    GoalRecommendation(
                        title = "Build a streak with ${popularType.type.name.lowercase()}",
                        description = "You're doing great with this exercise type!",
                        type = GoalType.STREAK,
                        targetValue = 7.0, // 7-day streak
                        difficulty = Difficulty.MEDIUM,
                        relevanceScore = popularType.successRate / 100,
                        recommendationType = RecommendationType.HABIT,
                        exerciseTypes = setOf(popularType.type)
                    )
                )
            }
        }

        return recommendations
    }

    private fun generatePreferenceBasedRecommendations(
        user: User,
        statistics: GoalStatistics
    ): List<GoalRecommendation> {
        val recommendations = mutableListOf<GoalRecommendation>()

        // Consider user preferences and fitness level
        user.preferences.preferredExerciseTypes.forEach { exerciseType ->
            if (exerciseType !in statistics.mostPopularTypes.map { it.type }) {
                // Suggest goals for underutilized preferred exercise types
                recommendations.add(
                    GoalRecommendation(
                        title = "Try ${exerciseType.name.lowercase()} workouts",
                        description = "Based on your exercise preferences",
                        type = GoalType.WORKOUTS,
                        targetValue = 3.0, // Start with 3 workouts
                        difficulty = Difficulty.EASY,
                        relevanceScore = 0.8,
                        recommendationType = RecommendationType.PREFERENCE,
                        exerciseTypes = setOf(exerciseType)
                    )
                )
            }
        }

        return recommendations
    }

    private suspend fun generateCommunityRecommendations(
        user: User
    ): List<GoalRecommendation> {
        val recommendations = mutableListOf<GoalRecommendation>()

        // Get popular goals from users with similar fitness levels
        val similarUsers = userRepository.getSimilarUsers(
            fitnessLevel = user.fitnessLevel,
            limit = 10
        ).first()

        val popularGoals = goalRepository.getPopularGoals(
            userIds = similarUsers.map { it.id },
            limit = 5
        ).first()

        popularGoals.forEach { goal ->
            recommendations.add(
                GoalRecommendation(
                    title = "Popular: ${goal.title}",
                    description = "Many users like you are trying this goal",
                    type = goal.type,
                    targetValue = goal.targetValue,
                    difficulty = calculateDifficulty(goal),
                    relevanceScore = 0.7,
                    recommendationType = RecommendationType.COMMUNITY,
                    exerciseTypes = goal.exerciseTypes
                )
            )
        }

        return recommendations
    }

    private fun calculateProgressionFactor(goals: List<Goal>): Double {
        // Calculate the average increase between consecutive goals
        return goals
            .sortedBy { it.completedAt }
            .zipWithNext { a, b -> b.targetValue / a.targetValue }
            .average()
            .coerceIn(1.1, 1.5) // Ensure progression is challenging but achievable
    }

    private fun calculateDifficulty(
        targetValue: Double,
        statistics: GoalStatistics
    ): Difficulty {
        val averageValue = statistics.goalsByType[GoalType.DISTANCE]?.averageValue ?: return Difficulty.MEDIUM
        return when {
            targetValue <= averageValue * 0.8 -> Difficulty.EASY
            targetValue <= averageValue * 1.2 -> Difficulty.MEDIUM
            else -> Difficulty.HARD
        }
    }

    private fun calculateRelevanceScore(
        type: GoalType,
        statistics: GoalStatistics
    ): Double {
        val typeStats = statistics.goalsByType[type] ?: return 0.5
        return (typeStats.completed.toDouble() / typeStats.total).coerceIn(0.0, 1.0)
    }
} 