package com.example.habithive.ui.goals

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.DialogFragment
import com.example.habithive.databinding.FragmentCreateGoalBinding
import com.example.habithive.model.UserGoal
import com.google.android.material.datepicker.MaterialDatePicker
import java.util.Calendar
import java.util.Date
import java.util.TimeZone

class CreateGoalDialogFragment(
    private val onGoalCreated: (UserGoal) -> Unit
) : DialogFragment() {

    private var _binding: FragmentCreateGoalBinding? = null
    private val binding get() = _binding!!
    
    private var startDate: Date = Date()
    private var endDate: Date = Date()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCreateGoalBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupSpinners()
        setupDatePickers()
        setupCreateButton()
    }

    private fun setupSpinners() {
        val frequencies = arrayOf("DAILY", "WEEKLY", "MONTHLY")
        val frequencyAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, frequencies)
        frequencyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.frequencySpinner.adapter = frequencyAdapter

        val types = arrayOf("EXERCISE", "STEPS", "CALORIES", "WATER", "MEDITATION", "SLEEP")
        val typeAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, types)
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.typeSpinner.adapter = typeAdapter

        val units = arrayOf("minutes", "steps", "calories", "ml", "hours")
        val unitAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, units)
        unitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.unitSpinner.adapter = unitAdapter
    }

    private fun setupDatePickers() {
        binding.startDateButton.setOnClickListener {
            showDatePicker(true)
        }

        binding.endDateButton.setOnClickListener {
            showDatePicker(false)
        }
    }

    private fun showDatePicker(isStartDate: Boolean) {
        val picker = MaterialDatePicker.Builder.datePicker()
            .setTitleText(if (isStartDate) "Select start date" else "Select end date")
            .build()

        picker.addOnPositiveButtonClickListener { selection ->
            val calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
            calendar.timeInMillis = selection
            
            if (isStartDate) {
                startDate = calendar.time
                binding.startDateButton.text = "Start: ${formatDate(startDate)}"
            } else {
                endDate = calendar.time
                binding.endDateButton.text = "End: ${formatDate(endDate)}"
            }
        }

        picker.show(childFragmentManager, "date_picker")
    }

    private fun formatDate(date: Date): String {
        val calendar = Calendar.getInstance()
        calendar.time = date
        return "${calendar.get(Calendar.MONTH) + 1}/${calendar.get(Calendar.DAY_OF_MONTH)}/${calendar.get(Calendar.YEAR)}"
    }

    private fun setupCreateButton() {
        binding.createButton.setOnClickListener {
            val title = binding.titleInput.text.toString()
            val description = binding.descriptionInput.text.toString()
            val targetValue = binding.targetValueInput.text.toString().toDoubleOrNull() ?: 0.0
            val frequency = binding.frequencySpinner.selectedItem.toString()
            val type = binding.typeSpinner.selectedItem.toString()
            val unit = binding.unitSpinner.selectedItem.toString()

            if (validateInput(title, targetValue)) {
                val goal = UserGoal(
                    title = title,
                    description = description,
                    targetValue = targetValue,
                    currentValue = 0.0,
                    frequency = frequency,
                    type = type,
                    unit = unit,
                    startDate = startDate,
                    endDate = endDate
                )
                onGoalCreated(goal)
                dismiss()
            }
        }
    }

    private fun validateInput(title: String, targetValue: Double): Boolean {
        if (title.isBlank()) {
            binding.titleInput.error = "Title is required"
            return false
        }
        if (targetValue <= 0) {
            binding.targetValueInput.error = "Target value must be greater than 0"
            return false
        }
        if (endDate.before(startDate)) {
            binding.endDateButton.error = "End date must be after start date"
            return false
        }
        return true
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 