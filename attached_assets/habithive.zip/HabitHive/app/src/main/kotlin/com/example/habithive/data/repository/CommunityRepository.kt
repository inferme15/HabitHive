package com.example.habithive.data.repository

import com.example.habithive.data.model.Post
import com.example.habithive.data.model.Comment
import kotlinx.coroutines.flow.Flow

interface CommunityRepository {
    suspend fun createPost(post: Post): String
    suspend fun getPost(postId: String): Post?
    suspend fun getAllPosts(): List<Post>
    suspend fun getUserPosts(userId: String): List<Post>
    suspend fun getTrendingPosts(): List<Post>
    fun getPostsFlow(): Flow<List<Post>>
    suspend fun updatePost(post: Post)
    suspend fun deletePost(postId: String)
    suspend fun likePost(postId: String)
    suspend fun unlikePost(postId: String)
    suspend fun isPostLiked(postId: String): Boolean
    suspend fun addComment(comment: Comment): String
    suspend fun getComments(postId: String): List<Comment>
    suspend fun deleteComment(commentId: String)
} 