package com.example.habithive.ui.viewmodels

@HiltViewModel
class ChallengesViewModel @Inject constructor(
    private val socialManager: GoalSocialManager
) : ViewModel() {
    private val _challenges = MutableLiveData<List<Challenge>>()
    val challenges: LiveData<List<Challenge>> = _challenges

    init {
        loadChallenges()
    }

    fun joinChallenge(challengeId: String) {
        viewModelScope.launch {
            socialManager.joinChallenge(challengeId, getCurrentUserId())
        }
    }
}

@HiltViewModel
class SocialFeedViewModel @Inject constructor(
    private val socialRepository: SocialRepository
) : ViewModel() {
    private val _posts = MutableLiveData<List<SocialPost>>()
    val posts: LiveData<List<SocialPost>> = _posts

    init {
        loadPosts()
    }

    fun likePost(postId: String) {
        viewModelScope.launch {
            socialRepository.likePost(postId)
        }
    }
}

@HiltViewModel
class LeaderboardViewModel @Inject constructor(
    private val socialManager: GoalSocialManager
) : ViewModel() {
    private val _leaderboard = MutableLiveData<List<LeaderboardEntry>>()
    val leaderboard: LiveData<List<LeaderboardEntry>> = _leaderboard

    fun updateType(type: LeaderboardType) {
        viewModelScope.launch {
            _leaderboard.value = socialManager.getLeaderboard(type, DateRange.WEEK)
        }
    }
}

@HiltViewModel
class RewardsShopViewModel @Inject constructor(
    private val rewardsRepository: RewardsRepository
) : ViewModel() {
    private val _rewards = MutableLiveData<List<Reward>>()
    val rewards: LiveData<List<Reward>> = _rewards

    fun purchaseReward(rewardId: String) {
        viewModelScope.launch {
            rewardsRepository.purchaseReward(rewardId)
        }
    }
} 