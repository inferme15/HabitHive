package com.example.habithive.util

import java.util.Date

data class DateRange(
    val start: Date,
    val end: Date
) {
    init {
        require(start.time <= end.time) { "Start date must be before or equal to end date" }
    }

    companion object {
        fun fromTimeRange(startTime: Long, endTime: Long): DateRange {
            return DateRange(Date(startTime), Date(endTime))
        }

        fun last7Days(): DateRange {
            val end = Date()
            val start = Date(end.time - 7 * 24 * 60 * 60 * 1000)
            return DateRange(start, end)
        }

        fun last30Days(): DateRange {
            val end = Date()
            val start = Date(end.time - 30 * 24 * 60 * 60 * 1000)
            return DateRange(start, end)
        }
    }
} 