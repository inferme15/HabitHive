package com.example.habithive.base

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch

abstract class BaseViewModel : ViewModel() {
    private val _error = MutableSharedFlow<String>()
    val error: SharedFlow<String> = _error

    protected fun handleError(throwable: Throwable) {
        viewModelScope.launch {
            _error.emit(throwable.message ?: "An unexpected error occurred")
        }
    }

    protected suspend fun <T> safeCall(
        onError: (Exception) -> Unit = { handleError(it) },
        block: suspend () -> T
    ): T? {
        return try {
            block()
        } catch (e: Exception) {
            onError(e)
            null
        }
    }
} 