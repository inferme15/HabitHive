package com.example.habithive.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.habithive.data.model.Exercise
import com.example.habithive.databinding.ItemRecentActivityBinding
import java.text.SimpleDateFormat
import java.util.*

class RecentActivitiesAdapter : ListAdapter<Exercise, RecentActivitiesAdapter.ActivityViewHolder>(ActivityDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ActivityViewHolder {
        val binding = ItemRecentActivityBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ActivityViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ActivityViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ActivityViewHolder(
        private val binding: ItemRecentActivityBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(exercise: Exercise) {
            binding.apply {
                tvActivityName.text = exercise.name
                tvActivityDate.text = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                    .format(Date(exercise.timestamp))
                tvActivityDuration.text = "${exercise.durationMinutes} min"
                tvActivityCalories.text = "${exercise.caloriesBurned} cal"
                tvActivityPoints.text = "${exercise.points} pts"
            }
        }
    }

    private class ActivityDiffCallback : DiffUtil.ItemCallback<Exercise>() {
        override fun areItemsTheSame(oldItem: Exercise, newItem: Exercise): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Exercise, newItem: Exercise): Boolean {
            return oldItem == newItem
        }
    }
} 