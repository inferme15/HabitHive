package com.example.habithive.data.repository

import com.example.habithive.data.model.Achievement
import com.example.habithive.data.model.UserAchievement
import kotlinx.coroutines.flow.Flow

interface AchievementRepository {
    suspend fun getAllAchievements(): List<Achievement>
    suspend fun getUserAchievements(userId: String): List<UserAchievement>
    fun getUserAchievementsFlow(userId: String): Flow<List<UserAchievement>>
    suspend fun updateUserAchievementProgress(userId: String, achievementId: String, progress: Int)
    suspend fun completeAchievement(userId: String, achievementId: String)
    suspend fun checkAndUpdateAchievements(userId: String)
    suspend fun awardAchievement(userId: String, achievementId: String)
} 