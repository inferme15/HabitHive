package com.example.habithive.data.model

import kotlinx.serialization.Serializable

@Serializable
data class User(
    val id: String = "",
    val name: String = "",
    val email: String = "",
    val photoUrl: String = "",
    val height: Float = 0f,
    val weight: Float = 0f,
    val birthDate: Long = System.currentTimeMillis(),
    val gender: String? = null,
    val fitnessLevel: String? = null,
    val preferences: Preferences? = null,
    val points: Int = 0,
    val streakCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val friends: List<String> = emptyList(),
    val pendingFriendRequests: List<String> = emptyList()
) {
    @Serializable
    data class Preferences(
        val notifications: Boolean = true,
        val units: String = "Metric",
        val theme: String = "System"
    )

    companion object {
        const val COLLECTION = "users"
    }
} 