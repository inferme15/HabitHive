package com.example.habithive.ui.statistics

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.habithive.R
import com.example.habithive.databinding.FragmentGoalStatisticsBinding
import com.example.habithive.util.DateRange
import com.example.habithive.util.setupBarChart
import com.example.habithive.util.setupLineChart
import com.example.habithive.util.setupPieChart
import com.google.android.material.tabs.TabLayout
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.*

@AndroidEntryPoint
class GoalStatisticsFragment : Fragment(R.layout.fragment_goal_statistics) {
    private val binding by viewBinding(FragmentGoalStatisticsBinding::bind)
    private val viewModel: GoalStatisticsViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeState()
    }

    private fun setupUI() {
        setupTimeRangeTabs()
        setupCharts()
    }

    private fun setupTimeRangeTabs() {
        binding.timeRangeTabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> viewModel.updateTimeRange(DateRange.WEEK)
                    1 -> viewModel.updateTimeRange(DateRange.MONTH)
                    2 -> viewModel.updateTimeRange(DateRange.YEAR)
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupCharts() {
        binding.progressChart.setupLineChart()
        binding.typeDistributionChart.setupPieChart()
        binding.completionRateChart.setupBarChart()
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.statisticsState.collect { state ->
                    when (state) {
                        is StatisticsState.Success -> updateUI(state.statistics)
                        is StatisticsState.Error -> showError(state.message)
                        is StatisticsState.Loading -> showLoading()
                    }
                }
            }
        }
    }

    private fun updateUI(statistics: GoalStatistics) {
        with(binding) {
            // Update summary cards
            totalGoalsValue.text = statistics.totalGoals.toString()
            completedGoalsValue.text = statistics.completedGoals.toString()
            activeGoalsValue.text = statistics.activeGoals.toString()
            completionRateValue.text = getString(
                R.string.percentage_format,
                statistics.completionRate
            )

            // Update streak information
            currentStreakValue.text = statistics.streaks.currentStreak.toString()
            longestStreakValue.text = statistics.streaks.longestStreak.toString()
            totalDaysValue.text = statistics.streaks.totalDays.toString()

            // Update charts
            updateProgressChart(statistics.progressOverTime)
            updateTypeDistributionChart(statistics.goalsByType)
            updateCompletionRateChart(statistics.averageCompletion)

            // Update popular types
            updatePopularTypes(statistics.mostPopularTypes)
        }
    }

    private fun updateProgressChart(progressPoints: List<ProgressPoint>) {
        // Implementation of progress chart update using MPAndroidChart
    }

    private fun updateTypeDistributionChart(goalsByType: Map<GoalType, TypeStatistics>) {
        // Implementation of type distribution pie chart update
    }

    private fun updateCompletionRateChart(averageCompletion: Map<GoalType, Double>) {
        // Implementation of completion rate bar chart update
    }

    private fun updatePopularTypes(popularTypes: List<PopularType>) {
        binding.popularTypesGroup.removeAllViews()
        popularTypes.take(5).forEach { popularType ->
        }
    }
} 