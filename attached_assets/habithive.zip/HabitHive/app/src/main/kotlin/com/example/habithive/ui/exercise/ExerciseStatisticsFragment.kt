package com.example.habithive.ui.exercise

import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.habithive.R
import com.example.habithive.data.model.Exercise
import com.example.habithive.data.model.ExerciseType
import com.example.habithive.databinding.FragmentExerciseStatisticsBinding
import com.example.habithive.util.*
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.PercentFormatter
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.*
import kotlin.math.min

@AndroidEntryPoint
class ExerciseStatisticsFragment : Fragment(R.layout.fragment_exercise_statistics) {

    private val binding by viewBinding(FragmentExerciseStatisticsBinding::bind)
    private val viewModel: ExerciseViewModel by viewModels()
    private var timeRange = TimeRange.WEEK

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeState()
        viewModel.loadExercises()
    }

    private fun setupUI() {
        setupToolbar()
        setupCharts()
        setupTabLayout()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            requireActivity().onBackPressed()
        }
    }

    private fun setupCharts() {
        setup
    }
} 