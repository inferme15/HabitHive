package com.example.habithive.ui.challenges

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.habithive.R
import com.example.habithive.databinding.FragmentChallengesBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ChallengesFragment : Fragment(R.layout.fragment_challenges) {
    private val binding by viewBinding(FragmentChallengesBinding::bind)
    private val viewModel: ChallengesViewModel by viewModels()
    private lateinit var adapter: ChallengesAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observeChallenges()
        setupFab()
    }

    private fun setupRecyclerView() {
        adapter = ChallengesAdapter(
            onJoinClick = { challenge -> viewModel.joinChallenge(challenge.id) },
            onDetailsClick = { challenge -> navigateToChallengeDetails(challenge.id) }
        )
        binding.challengesRecyclerView.adapter = adapter
    }

    private fun observeChallenges() {
        viewModel.challenges.observe(viewLifecycleOwner) { challenges ->
            adapter.submitList(challenges)
            binding.emptyState.isVisible = challenges.isEmpty()
        }
    }
} 