package com.example.habithive.di

import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    @Named("users_collection")
    fun provideUsersCollection(firestore: FirebaseFirestore): CollectionReference {
        return firestore.collection("users")
    }

    @Provides
    @Singleton
    @Named("exercises_collection")
    fun provideExercisesCollection(firestore: FirebaseFirestore): CollectionReference {
        return firestore.collection("exercises")
    }

    @Provides
    @Singleton
    @Named("friend_requests_collection")
    fun provideFriendRequestsCollection(firestore: FirebaseFirestore): CollectionReference {
        return firestore.collection("friend_requests")
    }

    @Provides
    @Singleton
    @Named("daily_summaries_collection")
    fun provideDailySummariesCollection(firestore: FirebaseFirestore): CollectionReference {
        return firestore.collection("daily_summaries")
    }
} 