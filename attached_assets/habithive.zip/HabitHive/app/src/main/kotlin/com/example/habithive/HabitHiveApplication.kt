package com.example.habithive

import android.app.Application
import com.google.firebase.FirebaseApp
import com.example.habithive.util.NotificationHelper
import com.example.habithive.util.notification.NotificationWorker
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class HabitHiveApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        NotificationHelper.createNotificationChannel(this)
        setupNotifications()
    }

    private fun setupNotifications() {
        NotificationWorker.schedule(this)
    }
} 