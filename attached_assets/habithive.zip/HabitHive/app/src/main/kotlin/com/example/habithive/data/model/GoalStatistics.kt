package com.example.habithive.data.model

import kotlinx.serialization.Serializable

@Serializable
data class GoalStatistics(
    val totalGoals: Int,
    val completedGoals: Int,
    val activeGoals: Int,
    val completionRate: Double,
    val averageCompletion: Map<GoalType, Double>,
    val goalsByType: Map<GoalType, TypeStatistics>,
    val progressOverTime: List<ProgressPoint>,
    val streaks: StreakStatistics,
    val mostPopularTypes: List<PopularType>,
    val failedGoals: Int = 0,
    val archivedGoals: Int = 0,
    val averageGoalDuration: Long = 0,
    val bestPerformingType: GoalType? = null,
    val worstPerformingType: GoalType? = null,
    val weeklyProgress: WeeklyProgress? = null,
    val monthlyProgress: MonthlyProgress? = null
)

@Serializable
data class TypeStatistics(
    val total: Int,
    val completed: Int,
    val totalValue: Double,
    val averageValue: Double,
    val failureRate: Double = 0.0,
    val averageDuration: Long = 0,
    val bestStreak: Int = 0,
    val totalPoints: Int = 0
)

@Serializable
data class ProgressPoint(
    val timestamp: Long,
    val progress: Double,
    val activeGoals: Int,
    val completedGoals: Int = 0,
    val failedGoals: Int = 0,
    val totalPoints: Int = 0
)

@Serializable
data class StreakStatistics(
    val currentStreak: Int,
    val longestStreak: Int,
    val totalDays: Int,
    val averageStreak: Double = 0.0,
    val streakHistory: List<Streak> = emptyList(),
    val bestDayOfWeek: Int = 1,
    val worstDayOfWeek: Int = 1
)

@Serializable
data class PopularType(
    val type: ExerciseType,
    val count: Int,
    val successRate: Double,
    val averageProgress: Double = 0.0,
    val totalDuration: Long = 0,
    val pointsEarned: Int = 0
)

@Serializable
data class Streak(
    val startDate: Long,
    val endDate: Long,
    val length: Int,
    val goalsCompleted: Int
)

@Serializable
data class WeeklyProgress(
    val weekStartDate: Long,
    val completedGoals: Int,
    val totalGoals: Int,
    val completionRate: Double,
    val totalPoints: Int,
    val bestDay: DayProgress,
    val worstDay: DayProgress
)

@Serializable
data class MonthlyProgress(
    val monthStartDate: Long,
    val completedGoals: Int,
    val totalGoals: Int,
    val completionRate: Double,
    val totalPoints: Int,
    val bestWeek: WeekProgress,
    val worstWeek: WeekProgress
)

@Serializable
data class DayProgress(
    val date: Long,
    val completedGoals: Int,
    val totalGoals: Int,
    val points: Int
)

@Serializable
data class WeekProgress(
    val weekStartDate: Long,
    val completedGoals: Int,
    val totalGoals: Int,
    val points: Int
) 