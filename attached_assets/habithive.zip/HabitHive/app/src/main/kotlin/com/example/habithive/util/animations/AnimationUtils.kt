package com.example.habithive.util.animations

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.view.View
import android.view.ViewPropertyAnimator
import androidx.core.view.isVisible

object AnimationUtils {

    fun View.fadeIn(duration: Long = 300) {
        alpha = 0f
        isVisible = true
        animate()
            .alpha(1f)
            .setDuration(duration)
            .setListener(null)
    }

    fun View.fadeOut(duration: Long = 300) {
        animate()
            .alpha(0f)
            .setDuration(duration)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    isVisible = false
                }
            })
    }

    fun View.slideUp(duration: Long = 300): ViewPropertyAnimator {
        translationY = height.toFloat()
        isVisible = true
        return animate()
            .translationY(0f)
            .setDuration(duration)
            .setListener(null)
    }

    fun View.slideDown(duration: Long = 300): ViewPropertyAnimator {
        return animate()
            .translationY(height.toFloat())
            .setDuration(duration)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    isVisible = false
                }
            })
    }

    fun View.scaleIn(duration: Long = 300) {
        scaleX = 0f
        scaleY = 0f
        isVisible = true
        animate()
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(duration)
            .setListener(null)
    }

    fun View.scaleOut(duration: Long = 300) {
        animate()
            .scaleX(0f)
            .scaleY(0f)
            .setDuration(duration)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    isVisible = false
                }
            })
    }
} 