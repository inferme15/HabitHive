package com.example.habithive.ui.shop

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.habithive.R
import com.example.habithive.databinding.FragmentRewardsShopBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class RewardsShopFragment : Fragment(R.layout.fragment_rewards_shop) {
    private val binding by viewBinding(FragmentRewardsShopBinding::bind)
    private val viewModel: RewardsShopViewModel by viewModels()
    private lateinit var adapter: RewardsAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observeRewards()
        setupUserBalance()
    }

    private fun setupRecyclerView() {
        adapter = RewardsAdapter { reward ->
            viewModel.purchaseReward(reward.id)
        }
        binding.rewardsRecyclerView.adapter = adapter
    }
} 