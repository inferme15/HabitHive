package com.example.habithive.ui.exercise

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.habithive.R
import com.example.habithive.data.model.Exercise
import com.example.habithive.data.model.ExerciseMood
import com.example.habithive.databinding.FragmentExerciseDetailsBinding
import com.example.habithive.util.*
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.PolylineOptions
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@AndroidEntryPoint
class ExerciseDetailsFragment : Fragment(R.layout.fragment_exercise_details) {

    private val binding by viewBinding(FragmentExerciseDetailsBinding::bind)
    private val viewModel: ExerciseViewModel by viewModels()
    private val args: ExerciseDetailsFragmentArgs by navArgs()
    private var googleMap: GoogleMap? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeState()
        viewModel.loadExercise(args.exerciseId)
    }

    private fun setupUI() {
        with(binding) {
            toolbar.setNavigationOnClickListener {
                findNavController().navigateUp()
            }

            mapView.onCreate(null)
            mapView.getMapAsync { map ->
                googleMap = map
            }

            shareButton.setOnClickListener {
                shareExercise()
            }

            setupElevationChart()
        }
    }

    private fun setupElevationChart() {
        with(binding.elevationChart) {
            description.isEnabled = false
            legend.isEnabled = false
            setTouchEnabled(true)
            setScaleEnabled(true)
            setPinchZoom(false)

            x
        }
    }
} 