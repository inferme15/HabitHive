package com.example.habithive.di

import android.content.Context
import com.example.habithive.data.repository.FriendRepository
import com.example.habithive.data.repository.FriendRepositoryImpl
import com.example.habithive.data.repository.UserRepository
import com.example.habithive.data.repository.UserRepositoryImpl
import com.example.habithive.repository.CommunityGoalRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

    @Provides
    @Singleton
    fun provideFirebaseFirestore(): FirebaseFirestore = FirebaseFirestore.getInstance()

    @Provides
    @Singleton
    fun provideFirebaseStorage(): FirebaseStorage = FirebaseStorage.getInstance()

    @Provides
    @Singleton
    fun provideUserRepository(
        auth: FirebaseAuth,
        db: FirebaseFirestore
    ): UserRepository = UserRepositoryImpl(auth, db)

    @Provides
    @Singleton
    fun provideFriendRepository(
        firestore: FirebaseFirestore,
        auth: FirebaseAuth
    ): FriendRepository = FriendRepositoryImpl(firestore, auth)

    @Provides
    @Singleton
    fun provideCommunityGoalRepository(
        db: FirebaseFirestore
    ): CommunityGoalRepository = CommunityGoalRepository(db)
} 