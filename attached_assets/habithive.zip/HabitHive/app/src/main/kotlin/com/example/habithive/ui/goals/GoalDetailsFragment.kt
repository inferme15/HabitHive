package com.example.habithive.ui.goals

import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.habithive.R
import com.example.habithive.data.model.Exercise
import com.example.habithive.data.model.ExerciseType
import com.example.habithive.data.model.Goal
import com.example.habithive.databinding.FragmentGoalDetailsBinding
import com.example.habithive.ui.exercise.ExerciseAdapter
import com.example.habithive.util.*
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@AndroidEntryPoint
class GoalDetailsFragment : Fragment(R.layout.fragment_goal_details) {

    private val binding by viewBinding(FragmentGoalDetailsBinding::bind)
    private val viewModel: GoalViewModel by viewModels()
    private val args: GoalDetailsFragmentArgs by navArgs()
    private lateinit var exerciseAdapter: ExerciseAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeState()
        viewModel.loadGoalDetails(args.goalId)
    }

    private fun setupUI() {
        setupToolbar()
        setupExerciseAdapter()
        setupProgressChart()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }

        binding.toolbar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.action_edit -> {
                    navigateToEditGoal()
                    true
                }
                R.id.action_delete -> {
                    showDeleteConfirmation()
                    true
                }
                else -> false
            }
        }
    }

    private fun setupExerciseAdapter() {
        exerciseAdapter = ExerciseAdapter(
            // Initialize the exercise adapter
        )
    }

    private fun setupProgressChart() {
        // Setup the progress chart
    }

    private fun observeState() {
        // Implement the state observer
    }

    private fun navigateToEditGoal() {
        // Implement the navigation to edit goal
    }

    private fun showDeleteConfirmation() {
        // Implement the delete confirmation dialog
    }
} 