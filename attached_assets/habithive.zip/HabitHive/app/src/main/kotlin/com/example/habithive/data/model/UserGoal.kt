package com.example.habithive.data.model

import kotlinx.serialization.Serializable

@Serializable
data class UserGoal(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val description: String = "",
    val targetDate: String = "",
    val isCompleted: Boolean = false,
    val progress: Int = 0
) 