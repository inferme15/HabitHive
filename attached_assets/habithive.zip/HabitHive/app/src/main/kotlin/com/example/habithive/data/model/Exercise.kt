package com.example.habithive.data.model

import kotlinx.serialization.Serializable

@Serializable
enum class ExerciseType {
    RUNNING,
    CYCLING,
    SWIMMING,
    WALKING,
    YOGA,
    STRENGTH,
    HIIT,
    OTHER
}

@Serializable
data class Exercise(
    val id: String,
    val type: ExerciseType,
    val duration: Long,
    val distance: Double? = null,
    val caloriesBurned: Int? = null,
    val date: Long,
    val userId: String,
    val notes: String? = null
)

@Serializable
enum class ExerciseMood {
    GREAT,
    GOOD,
    NORMAL,
    TIRED,
    EXHAUSTED
}

@Serializable
data class ExerciseSession(
    val id: String = "",
    val exerciseId: String = "",
    val startTime: Long = 0L,
    val endTime: Long = 0L,
    val isActive: Boolean = false,
    val currentDistance: Double = 0.0,
    val currentCalories: Int = 0,
    val locationPoints: List<LocationPoint> = emptyList()
)

@Serializable
data class LocationPoint(
    val latitude: Double,
    val longitude: Double,
    val timestamp: Long
) 