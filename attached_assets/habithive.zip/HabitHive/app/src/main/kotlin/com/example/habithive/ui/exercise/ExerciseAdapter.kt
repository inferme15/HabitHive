package com.example.habithive.ui.exercise

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.habithive.R
import com.example.habithive.data.model.Exercise
import com.example.habithive.databinding.ItemExerciseBinding
import java.text.SimpleDateFormat
import java.util.*

class ExerciseAdapter(
    private val onItemClick: (Exercise) -> Unit,
    private val onDeleteClick: (Exercise) -> Unit
) : ListAdapter<Exercise, ExerciseAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemExerciseBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: ItemExerciseBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                onItemClick(getItem(adapterPosition))
            }
            binding.deleteButton.setOnClickListener {
                onDeleteClick(getItem(adapterPosition))
            }
        }

        fun bind(exercise: Exercise) {
            with(binding) {
                // Set exercise type icon and name
                exerciseTypeImageView.setImageResource(
                    when (exercise.type) {
                        ExerciseType.RUNNING -> R.drawable.ic_running
                        ExerciseType.WALKING -> R.drawable.ic_walking
                        ExerciseType.CYCLING -> R.drawable.ic_cycling
                        ExerciseType.SWIMMING -> R.drawable.ic_swimming
                    }
                )
                exerciseName.text = exercise.type
                exerciseType.text = exercise.type
                exerciseDuration.text = "${exercise.duration} minutes"
                caloriesBurned.text = "${exercise.calories} calories"
            }
        }
    }

    private class DiffCallback : DiffUtil.ItemCallback<Exercise>() {
        override fun areItemsTheSame(oldItem: Exercise, newItem: Exercise): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Exercise, newItem: Exercise): Boolean {
            return oldItem == newItem
        }
    }
} 