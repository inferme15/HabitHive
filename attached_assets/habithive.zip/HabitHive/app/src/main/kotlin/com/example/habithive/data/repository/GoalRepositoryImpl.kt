package com.example.habithive.data.repository

import com.example.habithive.data.model.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.tasks.await
import java.util.*
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton

@Singleton
class GoalRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore,
    @Named("goals") private val goalsCollection: CollectionReference,
    private val exerciseRepository: ExerciseRepository
) : GoalRepository {

    override suspend fun createGoal(goal: Goal): String {
        val goalRef = goalsCollection.document()
        val goalWithId = goal.copy(id = goalRef.id)
        goalRef.set(goalWithId).await()
        return goalRef.id
    }

    override suspend fun getGoal(goalId: String): Goal? {
        return goalsCollection
            .document(goalId)
            .get()
            .await()
            .toObject(Goal::class.java)
    }

    override suspend fun getAllGoals(userId: String): List<Goal> {
        return goalsCollection
            .whereEqualTo("userId", userId)
            .orderBy("startDate", Query.Direction.DESCENDING)
            .get()
            .await()
            .toObjects(Goal::class.java)
    }

    override suspend fun getActiveGoals(userId: String): List<Goal> {
        return goalsCollection
            .whereEqualTo("userId", userId)
            .whereEqualTo("status", GoalStatus.IN_PROGRESS)
            .get()
            .await()
            .toObjects(Goal::class.java)
    }

    override fun getGoalsFlow(userId: String): Flow<List<Goal>> {
        return goalsCollection
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot -> snapshot.toObjects(Goal::class.java) }
    }

    override suspend fun updateGoal(goal: Goal) {
        goalsCollection.document(goal.id).set(goal).await()
    }

    override suspend fun deleteGoal(goalId: String) {
        goalsCollection.document(goalId).delete().await()
    }

    override suspend fun updateGoalProgress(goalId: String, exercise: Exercise) {
        val goal = getGoal(goalId) ?: return

        if (!isExerciseApplicableToGoal(exercise, goal)) return

        val progressValue = when (goal.type) {
            GoalType.DISTANCE -> exercise.distance
            GoalType.DURATION -> exercise.duration.toDouble()
            GoalType.CALORIES -> exercise.caloriesBurned.toDouble()
            GoalType.WORKOUTS -> 1.0
            GoalType.STREAK -> {
                val currentStreak = exerciseRepository.getUserCurrentStreak(exercise.userId)
                currentStreak.toDouble()
            }
        }

        val updatedGoal = goal.copy(
            currentValue = goal.currentValue + progressValue,
            status = if (goal.currentValue + progressValue >= goal.targetValue) {
                GoalStatus.COMPLETED
            } else {
                GoalStatus.IN_PROGRESS
            }
        )

        updateGoal(updatedGoal)
    }

    override suspend fun checkAndUpdateGoalStatus(userId: String) {
        val activeGoals = getActiveGoals(userId)
        val currentTime = System.currentTimeMillis()

        for (goal in activeGoals) {
            // Check if goal has expired
            if (currentTime > goal.endDate) {
                val updatedGoal = goal.copy(
                    status = if (goal.currentValue >= goal.targetValue) {
                        GoalStatus.COMPLETED
                    } else {
                        GoalStatus.FAILED
                    }
                )
                updateGoal(updatedGoal)
                continue
            }

            // Check if goal needs progress update
            when (goal.frequency) {
                GoalFrequency.DAILY -> {
                    if (!isWithinToday(goal.startDate)) {
                        resetGoalProgress(goal)
                    }
                }
                GoalFrequency.WEEKLY -> {
                    if (!isWithinCurrentWeek(goal.startDate)) {
                        resetGoalProgress(goal)
                    }
                }
                GoalFrequency.MONTHLY -> {
                    if (!isWithinCurrentMonth(goal.startDate)) {
                        resetGoalProgress(goal)
                    }
                }
                GoalFrequency.CUSTOM -> {
                    // Custom frequency goals don't reset until end date
                }
            }
        }
    }

    override suspend fun getUserCompletedGoalsCount(userId: String): Int {
        return goalsCollection
            .whereEqualTo("userId", userId)
            .whereEqualTo("status", GoalStatus.COMPLETED)
            .get()
            .await()
            .size()
    }

    private fun isExerciseApplicableToGoal(exercise: Exercise, goal: Goal): Boolean {
        // Check if exercise type is included in goal's exercise types
        if (goal.exerciseTypes.isNotEmpty() && exercise.type !in goal.exerciseTypes) {
            return false
        }

        // Check if exercise is within goal's time period
        if (exercise.timestamp < goal.startDate || exercise.timestamp > goal.endDate) {
            return false
        }

        return true
    }

    private suspend fun resetGoalProgress(goal: Goal) {
        val updatedGoal = goal.copy(
            currentValue = 0.0,
            status = GoalStatus.IN_PROGRESS,
            startDate = System.currentTimeMillis()
        )
        updateGoal(updatedGoal)
    }

    private fun isWithinToday(timestamp: Long): Boolean {
        val calendar = Calendar.getInstance()
        val today = calendar.get(Calendar.DAY_OF_YEAR)
        calendar.timeInMillis = timestamp
        return calendar.get(Calendar.DAY_OF_YEAR) == today
    }

    private fun isWithinCurrentWeek(timestamp: Long): Boolean {
        val calendar = Calendar.getInstance()
        val currentWeek = calendar.get(Calendar.WEEK_OF_YEAR)
        calendar.timeInMillis = timestamp
        return calendar.get(Calendar.WEEK_OF_YEAR) == currentWeek
    }

    private fun isWithinCurrentMonth(timestamp: Long): Boolean {
        val calendar = Calendar.getInstance()
        val currentMonth = calendar.get(Calendar.MONTH)
        calendar.timeInMillis = timestamp
        return calendar.get(Calendar.MONTH) == currentMonth
    }
} 