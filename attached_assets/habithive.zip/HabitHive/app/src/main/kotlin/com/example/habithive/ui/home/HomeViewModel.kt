package com.example.habithive.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.habithive.data.model.Exercise
import com.example.habithive.repository.ExerciseRepository
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val exerciseRepository: ExerciseRepository,
    private val auth: FirebaseAuth
) : ViewModel() {

    private val _homeState = MutableStateFlow(HomeState())
    val homeState: StateFlow<HomeState> = _homeState

    init {
        loadTodayStats()
        loadWeeklyStats()
    }

    private fun loadTodayStats() {
        viewModelScope.launch {
            try {
                _homeState.update { it.copy(isLoading = true) }
                val userId = auth.currentUser?.uid ?: return@launch
                val calendar = Calendar.getInstance()
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                val startTime = calendar.timeInMillis
                calendar.set(Calendar.HOUR_OF_DAY, 23)
                calendar.set(Calendar.MINUTE, 59)
                calendar.set(Calendar.SECOND, 59)
                val endTime = calendar.timeInMillis

                val exercises = exerciseRepository.getExercisesByDateRange(userId, startTime, endTime)
                _homeState.update { currentState ->
                    currentState.copy(
                        activities = exercises,
                        todayCalories = exercises.sumOf { it.calories },
                        todayExercises = exercises.size,
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                _homeState.update { 
                    it.copy(
                        error = e.message ?: "Error loading today's stats",
                        isLoading = false
                    )
                }
            }
        }
    }

    private fun loadWeeklyStats() {
        viewModelScope.launch {
            try {
                val userId = auth.currentUser?.uid ?: return@launch
                val calendar = Calendar.getInstance()
                calendar.add(Calendar.DAY_OF_YEAR, -7)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                val startTime = calendar.timeInMillis
                calendar.add(Calendar.DAY_OF_YEAR, 7)
                calendar.set(Calendar.HOUR_OF_DAY, 23)
                calendar.set(Calendar.MINUTE, 59)
                calendar.set(Calendar.SECOND, 59)
                val endTime = calendar.timeInMillis

                val exercises = exerciseRepository.getExercisesByDateRange(userId, startTime, endTime)
                val weeklyCalories = exercises.sumOf { it.calories }

                // Find the best day
                val dailyCalories = exercises.groupBy { 
                    val cal = Calendar.getInstance()
                    cal.timeInMillis = it.date.toDate().time
                    cal.get(Calendar.DAY_OF_WEEK)
                }.mapValues { it.value.sumOf { exercise -> exercise.calories } }

                val bestDay = dailyCalories.maxByOrNull { it.value }
                val bestDayName = when (bestDay?.key) {
                    Calendar.SUNDAY -> "Sunday"
                    Calendar.MONDAY -> "Monday"
                    Calendar.TUESDAY -> "Tuesday"
                    Calendar.WEDNESDAY -> "Wednesday"
                    Calendar.THURSDAY -> "Thursday"
                    Calendar.FRIDAY -> "Friday"
                    Calendar.SATURDAY -> "Saturday"
                    else -> null
                }

                _homeState.update { currentState ->
                    currentState.copy(
                        weeklyCalories = weeklyCalories,
                        bestDay = bestDayName
                    )
                }
            } catch (e: Exception) {
                _homeState.update { 
                    it.copy(error = e.message ?: "Error loading weekly stats")
                }
            }
        }
    }

    fun refreshData() {
        loadTodayStats()
        loadWeeklyStats()
    }
} 