package com.example.habithive.ui.exercise

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.habithive.R
import com.example.habithive.data.model.Exercise
import com.example.habithive.data.model.ExerciseMood
import com.example.habithive.databinding.FragmentExerciseSummaryBinding
import com.example.habithive.util.formatDuration
import com.example.habithive.util.formatPace
import com.example.habithive.util.viewBinding
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.PolylineOptions
import com.google.android.material.chip.Chip
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class ExerciseSummaryFragment : Fragment(R.layout.fragment_exercise_summary) {

    private val binding by viewBinding(FragmentExerciseSummaryBinding::bind)
    private val viewModel: ExerciseViewModel by viewModels()
    private val args: ExerciseSummaryFragmentArgs by navArgs()
    private var googleMap: GoogleMap? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeState()
        viewModel.loadExercise(args.exerciseId)
    }

    private fun setupUI() {
        with(binding) {
            toolbar.setNavigationOnClickListener {
                findNavController().navigateUp()
            }

            mapView.onCreate(null)
            mapView.getMapAsync { map ->
                googleMap = map
            }

            // Setup mood chips
            moodChipGroup.setOnCheckedStateChangeListener { group, checkedIds ->
                val selectedChip = group.findViewById<Chip>(checkedIds.firstOrNull() ?: return@setOnCheckedStateChangeListener)
                val mood = when (selectedChip.id) {
                    R.id.moodGreatChip -> ExerciseMood.GREAT
                    R.id.moodGoodChip -> ExerciseMood.GOOD
                    R.id.moodNormalChip -> ExerciseMood.NORMAL
                    R.id.moodTiredChip -> ExerciseMood.TIRED
                    R.id.moodExhaustedChip -> ExerciseMood.EXHAUSTED
                    else -> ExerciseMood.NORMAL
                }
                viewModel.updateMood(mood)
            }

            saveButton.setOnClickListener {
                viewModel.saveExercise(notesEditText.text.toString())
            }
        }
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.exerciseState.collect { state ->
                    when (state) {
                        is ExerciseState.Success -> {
                            state.exercises.firstOrNull { it.id == args.exerciseId }?.let { exercise ->
                                updateUI(exercise)
                            }
                        }
                        is ExerciseState.Error -> {
                            Snackbar.make(
                                requireView(),
                                state.message,
                                Snackbar.LENGTH_LONG
                            ).show()
                        }
                        else -> {
                            // Handle loading state
                        }
                    }
                }
            }
        }
    }

    private fun updateUI(exercise: Exercise) {
        with(binding) {
            durationTextView.text = formatDuration(exercise.duration * 60 * 1000L)
            distanceTextView.text = getString(R.string.distance_format, exercise.distance)
            paceTextView.text = formatPace(exercise.duration.toDouble() / exercise.distance)
            caloriesTextView.text = getString(R.string.calories_format, exercise.caloriesBurned)

            // Set mood chip
            val chipId = when (exercise.mood) {
                ExerciseMood.GREAT -> R.id.moodGreatChip
                ExerciseMood.GOOD -> R.id.moodGoodChip
                ExerciseMood.NORMAL -> R.id.moodNormalChip
                ExerciseMood.TIRED -> R.id.moodTiredChip
                ExerciseMood.EXHAUSTED -> R.id.moodExhaustedChip
            }
            moodChipGroup.check(chipId)

            notesEditText.setText(exercise.notes)

            updateMap(exercise)
        }
    }

    private fun updateMap(exercise: Exercise) {
        val map = googleMap ?: return
        val points = exercise.locationPoints

        if (points.isEmpty()) return

        val lat
    }
} 