package com.example.habithive.ui.achievements

import androidx.lifecycle.viewModelScope
import com.example.habithive.base.BaseViewModel
import com.example.habithive.data.model.Achievement
import com.example.habithive.data.repository.AchievementRepository
import com.example.habithive.data.repository.UserRepository
import com.example.habithive.util.NetworkUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AchievementViewModel @Inject constructor(
    private val achievementRepository: AchievementRepository,
    private val userRepository: UserRepository,
    private val networkUtils: NetworkUtils
) : BaseViewModel() {

    private val _achievementsState = MutableStateFlow<AchievementsState>(AchievementsState.Loading)
    val achievementsState: StateFlow<AchievementsState> = _achievementsState

    private val _achievementDetailState = MutableStateFlow<AchievementDetailState>(AchievementDetailState.Loading)
    val achievementDetailState: StateFlow<AchievementDetailState> = _achievementDetailState

    init {
        loadAchievements()
    }

    fun loadAchievements() {
        if (!networkUtils.isNetworkAvailable()) {
            _achievementsState.value = AchievementsState.Error("No internet connection")
            return
        }

        viewModelScope.launch {
            _achievementsState.value = AchievementsState.Loading
            safeCall(
                onError = { _achievementsState.value = AchievementsState.Error(it.message ?: "Failed to load achievements") }
            ) {
                val currentUser = userRepository.getCurrentUser()
                    ?: throw IllegalStateException("User not found")

                // Update achievements first
                achievementRepository.checkAndUpdateAchievements(currentUser.id)

                val userAchievements = achievementRepository.getUserAchievements(currentUser.id)
                val allAchievements = achievementRepository.getAllAchievements()

                val completedAchievements = userAchievements.filter { it.isCompleted }
                val totalPoints = completedAchievements.sumOf { it.achievement?.points ?: 0 }

                // Find next achievements to complete
                val nextAchievements = allAchievements.filter { achievement ->
                    val userAchievement = userAchievements.find { it.achievementId == achievement.id }
                    userAchievement == null || !userAchievement.isCompleted
                }.sortedBy { it.requirement }
                    .take(3)

                _achievementsState.value = AchievementsState.Success(
                    userAchievements = userAchievements,
                    completedCount = completedAchievements.size,
                    totalPoints = totalPoints,
                    nextAchievements = nextAchievements
                )
            }
        }
    }

    fun loadAchievementDetails(achievementId: String) {
        viewModelScope.launch {
            _achievementDetailState.value = AchievementDetailState.Loading
            safeCall(
                onError = { _achievementDetailState.value = AchievementDetailState.Error(it.message ?: "Failed to load achievement details") }
            ) {
                val currentUser = userRepository.getCurrentUser()
                    ?: throw IllegalStateException("User not found")

                val userAchievements = achievementRepository.getUserAchievements(currentUser.id)
                val userAchievement = userAchievements.find { it.achievementId == achievementId }
                    ?: throw IllegalStateException("Achievement not found")

                val allAchievements = achievementRepository.getAllAchievements()
                val similarAchievements = allAchievements.filter { achievement ->
                    achievement.type == userAchievement.achievement?.type &&
                    achievement.id != achievementId
                }

                _achievementDetailState.value = AchievementDetailState.Success(
                    userAchievement = userAchievement,
                    similarAchievements = similarAchievements
                )
            }
        }
    }

    fun refreshAchievements() {
        viewModelScope.launch {
            safeCall {
                val currentUser = userRepository.getCurrentUser()
                    ?: throw IllegalStateException("User not found")
                achievementRepository.checkAndUpdateAchievements(currentUser.id)
                loadAchievements()
            }
        }
    }
} 