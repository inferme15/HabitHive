package com.example.habithive.ui.exercise

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.habithive.model.Exercise
import com.example.habithive.repository.ExerciseRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ExerciseViewModel @Inject constructor(
    private val repository: ExerciseRepository,
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore
) : ViewModel() {
    private val _exercises = MutableLiveData<List<Exercise>>()
    val exercises: LiveData<List<Exercise>> = _exercises

    private val _selectedExercise = MutableLiveData<Exercise?>()
    val selectedExercise: LiveData<Exercise?> = _selectedExercise

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    private val _exerciseSaved = MutableLiveData<Boolean>()
    val exerciseSaved: LiveData<Boolean> = _exerciseSaved

    init {
        loadExercises()
    }

    private fun getCurrentUserId(): String {
        return auth.currentUser?.uid ?: throw IllegalStateException("User not authenticated")
    }

    private fun loadExercises() {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                val userId = getCurrentUserId()
                val exercises = repository.getExercises(userId)
                _exercises.value = exercises
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message
                _exercises.value = emptyList()
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun saveExercise(exercise: Exercise) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.createExercise(exercise)
                loadExercises()
                _error.value = null
                _exerciseSaved.value = true
            } catch (e: Exception) {
                _error.value = e.message
                _exerciseSaved.value = false
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteExercise(exercise: Exercise) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                repository.deleteExercise(exercise.id)
                loadExercises()
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun getExercisesByType(userId: String, type: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val exerciseList = repository.getExercisesByType(userId, type)
                _exercises.value = exerciseList
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun getExercisesByDateRange(userId: String, startTime: Long, endTime: Long) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val exerciseList = repository.getExercisesByDateRange(userId, startTime, endTime)
                _exercises.value = exerciseList
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun selectExercise(exercise: Exercise) {
        _selectedExercise.value = exercise
    }
} 