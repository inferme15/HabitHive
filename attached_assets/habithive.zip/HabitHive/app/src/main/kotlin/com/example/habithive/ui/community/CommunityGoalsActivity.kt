package com.example.habithive.ui.community

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.example.habithive.R
import com.example.habithive.databinding.ActivityCommunityGoalsBinding
import com.example.habithive.databinding.DialogCreateCommunityGoalBinding
import com.example.habithive.model.CommunityGoal
import com.example.habithive.model.GoalType
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope

class CommunityGoalsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCommunityGoalsBinding
    private val viewModel: CommunityGoalViewModel by viewModels()
    private lateinit var viewPagerAdapter: CommunityGoalsViewPagerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCommunityGoalsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupViewPager()
        setupFab()
        observeViewModel()
        loadData()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { 
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun setupViewPager() {
        viewPagerAdapter = CommunityGoalsViewPagerAdapter(this)
        binding.viewPager.adapter = viewPagerAdapter

        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> "My Goals"
                1 -> "Participating"
                else -> null
            }
        }.attach()

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                val userId = "current_user_id" // Replace with actual user ID
                when (position) {
                    0 -> viewModel.loadGoals(userId)
                    1 -> viewModel.loadGoals(userId)
                }
            }
        })
    }

    private fun setupFab() {
        binding.fabCreateGoal.setOnClickListener {
            showCreateGoalDialog()
        }
    }

    private fun showCreateGoalDialog() {
        val dialogBinding = DialogCreateCommunityGoalBinding.inflate(LayoutInflater.from(this))
        
        // Setup goal type spinner
        val goalTypes = GoalType.values().map { it.name.replace("_", " ").replaceFirstChar { it.uppercase() } }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, goalTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        dialogBinding.spinnerGoalType.adapter = adapter

        MaterialAlertDialogBuilder(this)
            .setTitle("Create Community Goal")
            .setView(dialogBinding.root)
            .setPositiveButton("Create") { _, _ ->
                val title = dialogBinding.editTextTitle.text.toString()
                val description = dialogBinding.editTextDescription.text.toString()
                val targetValue = dialogBinding.editTextTargetValue.text.toString().toIntOrNull() ?: 0
                val selectedType = GoalType.values()[dialogBinding.spinnerGoalType.selectedItemPosition]

                if (title.isNotBlank() && description.isNotBlank() && targetValue > 0) {
                    val userId = "current_user_id" // Replace with actual user ID
                    val goal = CommunityGoal(
                        creatorId = userId,
                        title = title,
                        description = description,
                        targetValue = targetValue,
                        type = selectedType
                    )
                    viewModel.createGoal(goal)
                } else {
                    Toast.makeText(this, "Please fill all fields correctly", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.myGoals.collectLatest { goals ->
                viewPagerAdapter.updateMyGoals(goals)
            }
        }

        lifecycleScope.launch {
            viewModel.participatingGoals.collectLatest { goals ->
                viewPagerAdapter.updateParticipatingGoals(goals)
            }
        }

        lifecycleScope.launch {
            viewModel.error.collectLatest { error ->
                error?.let {
                    Toast.makeText(this@CommunityGoalsActivity, it, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun loadData() {
        val userId = "current_user_id" // Replace with actual user ID
        viewModel.loadGoals(userId)
    }
} 