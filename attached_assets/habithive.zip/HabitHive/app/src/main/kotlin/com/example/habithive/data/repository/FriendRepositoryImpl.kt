package com.example.habithive.data.repository

import com.example.habithive.data.model.FriendRequest
import com.example.habithive.data.model.RequestStatus
import com.example.habithive.data.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FriendRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) : FriendRepository {

    private val currentUserId: String
        get() = auth.currentUser?.uid ?: throw IllegalStateException("User not logged in")

    private val friendRequestsCollection = firestore.collection("friend_requests")

    override suspend fun getFriends(): Flow<List<User>> = flow {
        val snapshot = firestore.collection("users")
            .document(currentUserId)
            .collection("friends")
            .get()
            .await()

        val friendIds = snapshot.documents.map { it.id }
        val friends = friendIds.mapNotNull { friendId ->
            firestore.collection("users")
                .document(friendId)
                .get()
                .await()
                .toObject(User::class.java)
        }
        emit(friends)
    }

    override suspend fun sendFriendRequest(senderId: String, receiverId: String, senderName: String, senderPhotoUrl: String?) {
        val request = FriendRequest(
            id = friendRequestsCollection.document().id,
            senderId = senderId,
            receiverId = receiverId,
            senderName = senderName,
            senderPhotoUrl = senderPhotoUrl,
            status = RequestStatus.PENDING
        )
        friendRequestsCollection.document(request.id).set(request).await()
    }

    override suspend fun acceptFriendRequest(requestId: String) {
        friendRequestsCollection.document(requestId)
            .update("status", RequestStatus.ACCEPTED.name)
            .await()
    }

    override suspend fun rejectFriendRequest(requestId: String) {
        friendRequestsCollection.document(requestId)
            .update("status", RequestStatus.REJECTED.name)
            .await()
    }

    override suspend fun getFriendRequests(): Flow<List<FriendRequest>> = flow {
        try {
            val snapshot = friendRequestsCollection
                .whereEqualTo("receiverId", currentUserId)
                .whereEqualTo("status", RequestStatus.PENDING.name)
                .get()
                .await()
            
            val requests = snapshot.documents.mapNotNull { 
                it.toObject(FriendRequest::class.java) 
            }
            emit(requests)
        } catch (e: Exception) {
            throw e
        }
    }

    override suspend fun getPendingRequests(userId: String): List<FriendRequest> {
        val snapshot = friendRequestsCollection
            .whereEqualTo("senderId", userId)
            .whereEqualTo("status", RequestStatus.PENDING.name)
            .get()
            .await()
        
        return snapshot.documents.mapNotNull { it.toObject(FriendRequest::class.java) }
    }

    override suspend fun removeFriend(friendId: String) {
        firestore.collection("users")
            .document(currentUserId)
            .collection("friends")
            .document(friendId)
            .delete()
            .await()

        firestore.collection("users")
            .document(friendId)
            .collection("friends")
            .document(currentUserId)
            .delete()
            .await()
    }

    override suspend fun getFriends(userId: String): Flow<List<User>> = flow {
        val snapshot = firestore.collection("users")
            .document(userId)
            .collection("friends")
            .get()
            .await()

        val friendIds = snapshot.documents.map { it.id }
        val friends = friendIds.mapNotNull { friendId ->
            firestore.collection("users")
                .document(friendId)
                .get()
                .await()
                .toObject(User::class.java)
        }
        emit(friends)
    }
} 