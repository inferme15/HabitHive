package com.example.habithive.ui.leaderboard

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.habithive.model.User

class LeaderboardViewPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
    private var globalUsers: List<User> = emptyList()
    private var friendsUsers: List<User> = emptyList()

    fun updateLeaderboard(users: List<User>) {
        // For now, we'll use the same list for both tabs
        // In a real app, you'd separate global and friends lists
        globalUsers = users
        friendsUsers = users
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = 2 // Global and Friends tabs

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> LeaderboardFragment.newInstance(globalUsers)
            1 -> LeaderboardFragment.newInstance(friendsUsers)
            else -> throw IllegalArgumentException("Invalid position: $position")
        }
    }
} 