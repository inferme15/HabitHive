package com.example.habithive.ui.goals

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.habithive.model.UserGoal
import com.example.habithive.repository.UserGoalRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UserGoalViewModel @Inject constructor(
    private val repository: UserGoalRepository
) : ViewModel() {

    private val _goals = MutableStateFlow<List<UserGoal>>(emptyList())
    val goals: StateFlow<List<UserGoal>> = _goals

    private val _activeGoals = MutableStateFlow<List<UserGoal>>(emptyList())
    val activeGoals: StateFlow<List<UserGoal>> = _activeGoals

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    init {
        loadActiveGoals()
    }

    fun loadGoals(frequency: String? = null) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                repository.getUserGoals(frequency)
                    .catch { e ->
                        _error.value = e.message
                    }
                    .collect { goals ->
                        _goals.value = goals
                    }
            } finally {
                _loading.value = false
            }
        }
    }

    fun loadActiveGoals() {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                repository.getActiveGoals()
                    .catch { e ->
                        _error.value = e.message
                    }
                    .collect { goals ->
                        _activeGoals.value = goals
                    }
            } finally {
                _loading.value = false
            }
        }
    }

    fun createGoal(goal: UserGoal) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                repository.createGoal(goal)
                loadActiveGoals()
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _loading.value = false
            }
        }
    }

    fun updateGoal(goal: UserGoal) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                repository.updateGoal(goal)
                loadActiveGoals()
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _loading.value = false
            }
        }
    }

    fun deleteGoal(goalId: String) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                repository.deleteGoal(goalId)
                loadActiveGoals()
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _loading.value = false
            }
        }
    }

    fun updateGoalProgress(goalId: String, currentValue: Double) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                repository.updateGoalProgress(goalId, currentValue)
                loadActiveGoals()
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _loading.value = false
            }
        }
    }
} 