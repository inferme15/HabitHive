package com.example.habithive.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.parcelize.RawValue

@Parcelize
data class User(
    val id: String? = null,
    val name: String = "",
    val email: String = "",
    val username: String = "",
    val photoUrl: String? = null,
    val profileImageUrl: String? = null,
    val height: Float? = null,
    val weight: Float? = null,
    val birthDate: Long? = null,
    val gender: String? = null,
    val fitnessLevel: String? = null,
    val level: Int = 1,
    val totalPoints: Int = 0,
    val preferences: @RawValue Preferences? = Preferences(),
    val userAchievements: @RawValue List<UserAchievement> = emptyList(),
    val friends: @RawValue Map<String, FriendStatus> = emptyMap()
) : Parcelable {
    // Empty constructor required for Firestore
    constructor() : this(
        id = null,
        name = "",
        email = "",
        username = "",
        photoUrl = null,
        profileImageUrl = null,
        height = null,
        weight = null,
        birthDate = null,
        gender = null,
        fitnessLevel = null,
        level = 1,
        totalPoints = 0,
        preferences = Preferences(),
        userAchievements = emptyList(),
        friends = emptyMap()
    )

    @Parcelize
    data class Preferences(
        val notifications: Boolean = true,
        val units: String = "Metric",
        val theme: String = "System"
    ) : Parcelable

    @Parcelize
    data class UserAchievement(
        val id: String = "",
        val title: String = "",
        val description: String = "",
        val earnedDate: Long = 0
    ) : Parcelable

    @Parcelize
    data class FriendStatus(
        val status: String = "pending",
        val since: Long = System.currentTimeMillis()
    ) : Parcelable
} 