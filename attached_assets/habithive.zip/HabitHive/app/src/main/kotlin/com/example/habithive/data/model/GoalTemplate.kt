package com.example.habithive.data.model

import kotlinx.serialization.Serializable
import kotlinx.datetime.LocalDateTime
import kotlinx.datetime.LocalTime
import kotlinx.datetime.serializers.LocalDateTimeSerializer
import kotlinx.datetime.serializers.LocalTimeSerializer
import com.example.habithive.data.model.ExerciseType
import com.example.habithive.data.model.GoalType
import java.time.LocalDateTime
import java.time.LocalTime

@Serializable
enum class Frequency {
    DAILY,
    WEEKLY,
    MONTHLY,
    CUSTOM
}

@Serializable
enum class TimeUnit {
    MINUTES,
    HOURS,
    DAYS,
    WEEKS,
    MONTHS
}

@Serializable
data class GoalTemplate(
    val id: String,
    val name: String,
    val description: String?,
    val type: GoalType,
    val targetValue: Double,
    val frequency: Frequency,
    val duration: Duration,
    val exerciseTypes: Set<ExerciseType>,
    val reminderEnabled: Boolean,
    @Serializable(with = LocalTimeSerializer::class)
    val reminderTime: LocalTime?,
    val userId: String,
    val isPublic: Boolean,
    @Serializable(with = LocalDateTimeSerializer::class)
    val createdAt: LocalDateTime,
    val usageCount: Int = 0
)

@Serializable
data class GoalCustomization(
    val title: String? = null,
    val description: String? = null,
    val targetValue: Double? = null,
    val frequency: Frequency? = null,
    val exerciseTypes: Set<ExerciseType>? = null,
    val reminderEnabled: Boolean? = null,
    @Serializable(with = LocalTimeSerializer::class)
    val reminderTime: LocalTime? = null
)

@Serializable
enum class TemplateFilter {
    ALL,
    PUBLIC,
    PRIVATE,
    POPULAR
}

@Serializable
data class Duration(
    val value: Int,
    val unit: TimeUnit
)

@Serializable
data class Time(
    val hour: Int,
    val minute: Int
) 