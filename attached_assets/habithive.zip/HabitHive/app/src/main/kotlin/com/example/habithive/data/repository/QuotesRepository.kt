package com.example.habithive.data.repository

import com.example.habithive.data.model.FitnessQuote
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

class QuotesRepository {
    companion object {
        private const val QUOTES_API_URL = "https://api.quotable.io/random?tags=fitness,health,motivation"
    }

    suspend fun getRandomQuote(): FitnessQuote = withContext(Dispatchers.IO) {
        try {
            val response = URL(QUOTES_API_URL).readText()
            val jsonObject = JSONObject(response)
            FitnessQuote(
                quote = jsonObject.getString("content"),
                author = jsonObject.getString("author")
            )
        } catch (e: Exception) {
            FitnessQuote(
                quote = "The only bad workout is the one that didn't happen.",
                author = "Unknown"
            )
        }
    }
} 