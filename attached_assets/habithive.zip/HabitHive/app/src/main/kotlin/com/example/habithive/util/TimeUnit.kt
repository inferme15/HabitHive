package com.example.habithive.util

enum class TimeUnit {
    DAYS,
    WEEKS,
    MONTHS,
    YEARS;

    fun toMillis(value: Int): Long {
        return when (this) {
            DAYS -> value * 24 * 60 * 60 * 1000L
            WEEKS -> value * 7 * 24 * 60 * 60 * 1000L
            MONTHS -> value * 30 * 24 * 60 * 60 * 1000L
            YEARS -> value * 365 * 24 * 60 * 60 * 1000L
        }
    }
} 