package com.example.habithive.data.model

data class Comment(
    val id: String = "",
    val postId: String = "",
    val userId: String = "",
    val userName: String = "",
    val userPhotoUrl: String? = null,
    val content: String = "",
    val timestamp: Long = System.currentTimeMillis()
) 