package com.example.habithive.ui.views

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import com.example.habithive.R
import com.example.habithive.databinding.ViewUserLevelProgressBinding
import com.example.habithive.util.animateProgress

class UserLevelProgressView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val binding = ViewUserLevelProgressBinding.inflate(
        LayoutInflater.from(context), this, true
    )

    init {
        setupAttributes(attrs)
    }

    private fun setupAttributes(attrs: AttributeSet?) {
        context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.UserLevelProgressView,
            0, 0
        ).apply {
            try {
                binding.levelText.setTextColor(
                    getColor(
                        R.styleable.UserLevelProgressView_levelTextColor,
                        ContextCompat.getColor(context, R.color.text_primary)
                    )
                )
                binding.experienceText.setTextColor(
                    getColor(
                        R.styleable.UserLevelProgressView_experienceTextColor,
                        ContextCompat.getColor(context, R.color.text_secondary)
                    )
                )
            } finally {
                recycle()
            }
        }
    }

    fun setUserProgress(
        level: Int,
        experience: Int,
        requiredExperience: Int,
        animate: Boolean = true
    ) {
        binding.levelText.text = context.getString(R.string.level_format, level)
        binding.experienceText.text = context.getString(
            R.string.experience_format,
            experience,
            requiredExperience
        )

        val progress = (experience.toFloat() / requiredExperience * 100).toInt()
        if (animate) {
            binding.progressBar.animateProgress(progress)
        } else {
            binding.progressBar.progress = progress
        }
    }
} 