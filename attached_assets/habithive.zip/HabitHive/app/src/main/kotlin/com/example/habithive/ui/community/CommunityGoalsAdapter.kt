package com.example.habithive.ui.community

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.habithive.databinding.ItemCommunityGoalBinding
import com.example.habithive.model.CommunityGoal

class CommunityGoalsAdapter(
    private val onGoalClick: (CommunityGoal) -> Unit
) : ListAdapter<CommunityGoal, CommunityGoalsAdapter.GoalViewHolder>(GoalDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GoalViewHolder {
        val binding = ItemCommunityGoalBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return GoalViewHolder(binding)
    }

    override fun onBindViewHolder(holder: GoalViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class GoalViewHolder(
        private val binding: ItemCommunityGoalBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onGoalClick(getItem(position))
                }
            }
        }

        fun bind(goal: CommunityGoal) {
            binding.apply {
                titleText.text = goal.title
                descriptionText.text = goal.description
                progressText.text = "${goal.currentValue}/${goal.targetValue}"
                progressIndicator.progress = (goal.currentValue.toFloat() / goal.targetValue * 100).toInt()
                participantsText.text = "${goal.participants.size} participants"
                supportersText.text = "${goal.supporters.size} supporters"

                joinButton.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        // TODO: Handle join button click
                    }
                }

                supportButton.setOnClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        // TODO: Handle support button click
                    }
                }
            }
        }
    }

    private class GoalDiffCallback : DiffUtil.ItemCallback<CommunityGoal>() {
        override fun areItemsTheSame(oldItem: CommunityGoal, newItem: CommunityGoal): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: CommunityGoal, newItem: CommunityGoal): Boolean {
            return oldItem == newItem
        }
    }
} 