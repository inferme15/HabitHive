package com.example.habithive.ui.achievement

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.habithive.databinding.ActivityAchievementsBinding
import com.example.habithive.ui.achievements.AchievementViewModel
import com.example.habithive.ui.achievements.AchievementsState
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import androidx.activity.OnBackPressedCallback

@AndroidEntryPoint
class AchievementsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAchievementsBinding
    private val viewModel: AchievementViewModel by viewModels()
    private lateinit var achievementAdapter: AchievementAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAchievementsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        observeViewModel()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finish()
            }
        })
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }

    private fun setupRecyclerView() {
        achievementAdapter = AchievementAdapter()
        binding.achievementsRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@AchievementsActivity)
            adapter = achievementAdapter
        }

        binding.swipeRefreshLayout.setOnRefreshListener {
            viewModel.refreshAchievements()
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.achievementsState.collectLatest { state ->
                when (state) {
                    is AchievementsState.Loading -> {
                        binding.progressBar.visibility = View.VISIBLE
                        binding.errorText.visibility = View.GONE
                    }
                    is AchievementsState.Success -> {
                        binding.progressBar.visibility = View.GONE
                        binding.errorText.visibility = View.GONE
                        binding.swipeRefreshLayout.isRefreshing = false

                        achievementAdapter.submitList(state.userAchievements)
                        
                        binding.levelText.text = "Level ${state.completedCount}"
                        binding.pointsText.text = "${state.totalPoints} XP"
                        
                        // Update next achievements section if you have one
                        // binding.nextAchievementsSection.setAchievements(state.nextAchievements)
                    }
                    is AchievementsState.Error -> {
                        binding.progressBar.visibility = View.GONE
                        binding.errorText.visibility = View.VISIBLE
                        binding.errorText.text = state.message
                        binding.swipeRefreshLayout.isRefreshing = false
                        
                        Toast.makeText(this@AchievementsActivity, state.message, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }
} 