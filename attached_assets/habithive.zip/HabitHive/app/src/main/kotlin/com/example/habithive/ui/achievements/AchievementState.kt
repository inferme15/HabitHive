package com.example.habithive.ui.achievements

import com.example.habithive.data.model.Achievement
import com.example.habithive.data.model.UserAchievement

sealed class AchievementsState {
    object Loading : AchievementsState()
    data class Success(
        val userAchievements: List<UserAchievement>,
        val completedCount: Int,
        val totalPoints: Int,
        val nextAchievements: List<Achievement>
    ) : AchievementsState()
    data class Error(val message: String) : AchievementsState()
}

sealed class AchievementDetailState {
    object Loading : AchievementDetailState()
    data class Success(
        val userAchievement: UserAchievement,
        val similarAchievements: List<Achievement>
    ) : AchievementDetailState()
    data class Error(val message: String) : AchievementDetailState()
} 