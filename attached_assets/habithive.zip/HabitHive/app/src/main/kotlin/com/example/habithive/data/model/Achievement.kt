package com.example.habithive.data.model

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Entity(tableName = "achievements")
@Parcelize
data class Achievement(
    @PrimaryKey
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val iconUrl: String = "",
    val type: AchievementCategory = AchievementCategory.GENERAL,
    val requirement: Int = 0,
    val points: Int = 0,
    val isSecret: Boolean = false,
    val rewardType: RewardType? = null,
    val rewardAmount: Int = 0,
    val rewardBadgeId: String? = null,
    val rewardItemId: String? = null
) : Parcelable {
    companion object {
        fun fromDefinition(definition: AchievementDefinition, id: String): Achievement {
            return Achievement(
                id = id,
                title = definition.title,
                description = definition.description,
                iconUrl = definition.icon,
                type = definition.category,
                requirement = definition.requirement,
                points = definition.experiencePoints,
                isSecret = false,
                rewardType = definition.reward?.type,
                rewardAmount = definition.reward?.amount ?: 0,
                rewardBadgeId = definition.reward?.badgeId,
                rewardItemId = definition.reward?.itemId
            )
        }

        val EARLY_BIRD = fromDefinition(AchievementDefinition.EARLY_BIRD, "early_bird")
        val STREAK_MASTER = fromDefinition(AchievementDefinition.STREAK_MASTER, "streak_master")
        val STREAK_WARRIOR = fromDefinition(AchievementDefinition.STREAK_WARRIOR, "streak_warrior")
        val DISTANCE_MASTER = fromDefinition(AchievementDefinition.DISTANCE_MASTER, "distance_master")
        val DISTANCE_ENTHUSIAST = fromDefinition(AchievementDefinition.DISTANCE_ENTHUSIAST, "distance_enthusiast")
        val CENTURION = fromDefinition(AchievementDefinition.CENTURION, "centurion")
        val GOAL_MASTER = fromDefinition(AchievementDefinition.GOAL_MASTER, "goal_master")
        val GOAL_SETTER = fromDefinition(AchievementDefinition.GOAL_SETTER, "goal_setter")
        val VERSATILE_ACHIEVER = fromDefinition(AchievementDefinition.VERSATILE_ACHIEVER, "versatile_achiever")
    }

    fun toReward(): Reward? {
        return if (rewardType != null) {
            Reward(
                type = rewardType,
                amount = rewardAmount,
                badgeId = rewardBadgeId,
                itemId = rewardItemId
            )
        } else null
    }
}

@Parcelize
data class UserAchievement(
    val userId: String = "",
    val achievementId: String = "",
    val achievement: Achievement? = null,
    val progress: Int = 0,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null
) : Parcelable

enum class AchievementCategory {
    GENERAL,
    EXERCISE_COUNT,
    EXERCISE_DURATION,
    CALORIES_BURNED,
    GOALS_COMPLETED,
    STREAK_DAYS,
    FRIEND_COUNT,
    COMMUNITY_POSTS
}

sealed class AchievementDefinition {
    abstract val title: String
    abstract val description: String
    abstract val icon: String
    abstract val experiencePoints: Int
    abstract val category: AchievementCategory
    abstract val requirement: Int
    abstract val reward: Reward?

    data object EARLY_BIRD : AchievementDefinition() {
        override val title = "Early Bird"
        override val description = "Complete a goal before half the allotted time"
        override val icon = "ic_achievement_early_bird"
        override val experiencePoints = 200
        override val category = AchievementCategory.GENERAL
        override val requirement = 1
        override val reward = Reward(type = RewardType.COINS, amount = 200)
    }

    data object GOAL_SETTER : AchievementDefinition() {
        override val title = "Goal Setter"
        override val description = "Complete 10 goals"
        override val icon = "ic_achievement_goal_setter"
        override val experiencePoints = 100
        override val category = AchievementCategory.GOALS_COMPLETED
        override val requirement = 10
        override val reward = Reward(type = RewardType.COINS, amount = 100)
    }
    
    data object GOAL_MASTER : AchievementDefinition() {
        override val title = "Goal Master"
        override val description = "Complete 50 goals"
        override val icon = "ic_achievement_goal_master"
        override val experiencePoints = 500
        override val category = AchievementCategory.GOALS_COMPLETED
        override val requirement = 50
        override val reward = Reward(type = RewardType.COINS, amount = 500)
    }
    
    data object CENTURION : AchievementDefinition() {
        override val title = "Centurion"
        override val description = "Complete 100 goals"
        override val icon = "ic_achievement_centurion"
        override val experiencePoints = 1000
        override val category = AchievementCategory.GOALS_COMPLETED
        override val requirement = 100
        override val reward = Reward(type = RewardType.BADGE, badgeId = "centurion_badge")
    }
    
    data object STREAK_WARRIOR : AchievementDefinition() {
        override val title = "Streak Warrior"
        override val description = "Maintain a 7-day streak"
        override val icon = "ic_achievement_streak_warrior"
        override val experiencePoints = 200
        override val category = AchievementCategory.STREAK_DAYS
        override val requirement = 7
        override val reward = Reward(type = RewardType.COINS, amount = 200)
    }
    
    data object STREAK_MASTER : AchievementDefinition() {
        override val title = "Streak Master"
        override val description = "Maintain a 30-day streak"
        override val icon = "ic_achievement_streak_master"
        override val experiencePoints = 1000
        override val category = AchievementCategory.STREAK_DAYS
        override val requirement = 30
        override val reward = Reward(type = RewardType.BADGE, badgeId = "streak_master_badge")
    }

    data object DISTANCE_ENTHUSIAST : AchievementDefinition() {
        override val title = "Distance Enthusiast"
        override val description = "Complete 10 distance goals"
        override val icon = "ic_achievement_distance_enthusiast"
        override val experiencePoints = 200
        override val category = AchievementCategory.GENERAL
        override val requirement = 10
        override val reward = Reward(type = RewardType.COINS, amount = 200)
    }

    data object DISTANCE_MASTER : AchievementDefinition() {
        override val title = "Distance Master"
        override val description = "Complete 50 distance goals"
        override val icon = "ic_achievement_distance_master"
        override val experiencePoints = 500
        override val category = AchievementCategory.GENERAL
        override val requirement = 50
        override val reward = Reward(type = RewardType.BADGE, badgeId = "distance_master_badge")
    }

    data object VERSATILE_ACHIEVER : AchievementDefinition() {
        override val title = "Versatile Achiever"
        override val description = "Complete goals of every type"
        override val icon = "ic_achievement_versatile"
        override val experiencePoints = 1000
        override val category = AchievementCategory.GENERAL
        override val requirement = 1
        override val reward = Reward(type = RewardType.BADGE, badgeId = "versatile_badge")
    }
}

@Parcelize
data class Reward(
    val type: RewardType,
    val amount: Int = 0,
    val badgeId: String? = null,
    val itemId: String? = null
) : Parcelable

enum class RewardType {
    COINS,
    BADGE,
    ITEM
} 