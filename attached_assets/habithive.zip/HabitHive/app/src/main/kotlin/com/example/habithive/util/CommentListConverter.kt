package com.example.habithive.util

import androidx.room.TypeConverter
import com.example.habithive.model.Comment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class CommentListConverter {
    private val gson = Gson()
    private val type = object : TypeToken<List<Comment>>() {}.type

    @TypeConverter
    fun fromString(value: String?): List<Comment> {
        if (value == null) return emptyList()
        return gson.fromJson(value, type)
    }

    @TypeConverter
    fun fromList(list: List<Comment>): String {
        return gson.toJson(list, type)
    }
} 