package com.example.habithive.ui.exercise

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.habithive.databinding.ActivityExerciseTrackingBinding
import com.example.habithive.model.Exercise
import com.example.habithive.model.ExerciseType
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.Timestamp
import java.util.Date
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ExerciseTrackingActivity : AppCompatActivity() {
    private lateinit var binding: ActivityExerciseTrackingBinding
    private val viewModel: ExerciseViewModel by viewModels()
    @Inject lateinit var auth: FirebaseAuth
    private var selectedExerciseType: ExerciseType? = null
    private var calculatedCalories: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExerciseTrackingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupCategorySpinner()
        setupClickListeners()
        observeViewModel()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { 
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun setupCategorySpinner() {
        val categories = ExerciseType.getCategories()
        val categoryAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, categories)
        (binding.categoryInput as? AutoCompleteTextView)?.setAdapter(categoryAdapter)

        binding.categoryInput.setOnItemClickListener { _, _, position, _ ->
            val selectedCategory = categories[position]
            updateExerciseTypeSpinner(selectedCategory)
        }
    }

    private fun updateExerciseTypeSpinner(category: String) {
        val exerciseTypes = ExerciseType.getByCategory(category)
        val exerciseNames = exerciseTypes.map { it.name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, exerciseNames)
        binding.exerciseTypeInput.setAdapter(adapter)

        binding.exerciseTypeInput.setOnItemClickListener { _, _, position, _ ->
            selectedExerciseType = exerciseTypes[position]
            binding.exerciseTypeInput.setText(exerciseNames[position], false)
        }
    }

    private fun setupClickListeners() {
        binding.calculateCaloriesButton.setOnClickListener {
            calculateCalories()
        }

        binding.saveButton.setOnClickListener {
            saveExercise()
        }
    }

    private fun calculateCalories() {
        val duration = binding.durationInput.text.toString().toIntOrNull()
        if (duration == null) {
            Toast.makeText(this, "Please enter duration", Toast.LENGTH_SHORT).show()
            return
        }

        if (selectedExerciseType == null) {
            Toast.makeText(this, "Please select exercise type", Toast.LENGTH_SHORT).show()
            return
        }

        calculatedCalories = ExerciseType.calculateCalories(selectedExerciseType!!, duration)
        binding.caloriesText.apply {
            text = "Calories Burned: $calculatedCalories"
            visibility = View.VISIBLE
        }
    }

    private fun saveExercise() {
        val name = binding.exerciseNameInput.text.toString()
        val duration = binding.durationInput.text.toString().toIntOrNull() ?: 0
        val type = selectedExerciseType?.name ?: ""

        when {
            name.isBlank() -> {
                Toast.makeText(this, "Please enter exercise name", Toast.LENGTH_SHORT).show()
                return
            }
            type.isBlank() -> {
                Toast.makeText(this, "Please select exercise type", Toast.LENGTH_SHORT).show()
                return
            }
            duration <= 0 -> {
                Toast.makeText(this, "Please enter valid duration", Toast.LENGTH_SHORT).show()
                return
            }
        }

        val exercise = Exercise(
            id = "",
            userId = auth.currentUser?.uid ?: "",
            type = type,
            duration = duration,
            calories = calculatedCalories,
            date = Timestamp(Date(System.currentTimeMillis())),
            notes = name
        )

        viewModel.saveExercise(exercise)
    }

    private fun observeViewModel() {
        viewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        viewModel.error.observe(this) { error ->
            error?.let {
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            }
        }

        viewModel.exerciseSaved.observe(this) { success ->
            if (success) {
                Toast.makeText(this, "Exercise saved successfully", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
} 