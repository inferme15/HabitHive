package com.example.habithive.data

import com.example.habithive.model.Exercise
import com.google.firebase.Timestamp
import com.google.firebase.firestore.PropertyName

data class DailyExerciseSummary(
    val userId: String = "",
    val date: Timestamp = Timestamp.now(),
    @get:PropertyName("totalCalories")
    @set:PropertyName("totalCalories")
    var totalCalories: Int = 0,
    @get:PropertyName("exercises")
    @set:PropertyName("exercises")
    var exercises: List<Exercise> = emptyList()
) {
    // Empty constructor for Firestore
    constructor() : this("", Timestamp.now(), 0, emptyList())
} 