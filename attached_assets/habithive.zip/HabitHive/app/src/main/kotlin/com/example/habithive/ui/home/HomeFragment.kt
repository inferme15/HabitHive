package com.example.habithive.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.habithive.adapters.RecentActivitiesAdapter
import com.example.habithive.data.DailyExerciseSummary
import com.example.habithive.data.repository.UserRepository
import com.example.habithive.databinding.FragmentHomeBinding
import com.example.habithive.repository.ExerciseRepository
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import kotlinx.coroutines.launch

@AndroidEntryPoint
class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by viewModels()
    private lateinit var adapter: RecentActivitiesAdapter

    @Inject
    lateinit var exerciseRepository: ExerciseRepository

    @Inject
    lateinit var userRepository: UserRepository

    @Inject
    lateinit var auth: FirebaseAuth

    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupSwipeRefresh()
        observeViewModel()
        loadUserData()
    }

    private fun setupRecyclerView() {
        adapter = RecentActivitiesAdapter()
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@HomeFragment.adapter
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.refreshData()
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.homeState.collect { state ->
                    binding.progressBar.visibility = if (state.isLoading) View.VISIBLE else View.GONE
                    binding.swipeRefresh.isRefreshing = state.isLoading
                    
                    // Update activities
                    state.activities?.let { activities ->
                        adapter.submitList(activities)
                        binding.emptyView.visibility = if (activities.isEmpty()) View.VISIBLE else View.GONE
                    }
                    
                    // Update today's stats
                    binding.todayCaloriesText.text = "Today's Calories: ${state.todayCalories} kcal"
                    binding.todayExercisesText.text = "Today's Exercises: ${state.todayExercises}"
                    
                    // Update weekly stats
                    binding.weeklyCaloriesText.text = "Weekly Calories: ${state.weeklyCalories} kcal"
                    binding.bestDayText.text = "Best Day: ${state.bestDay ?: "None"}"
                    
                    // Show any errors
                    state.error?.let { error ->
                        showError(error)
                    }
                }
            }
        }
    }

    private fun loadUserData() {
        auth.currentUser?.uid?.let { userId ->
            userRepository.getUser(userId) { user ->
                if (user != null) {
                    binding.welcomeText.text = "Welcome, ${user.name}!"
                }
            }
        }
    }

    private fun showError(message: String) {
        Snackbar.make(requireView(), message, Snackbar.LENGTH_LONG).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 