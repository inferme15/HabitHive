package com.example.habithive.ui.exercise

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.habithive.data.model.ExerciseType
import com.example.habithive.databinding.DialogExerciseTypeBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class ExerciseTypeDialog : BottomSheetDialogFragment() {

    private var _binding: DialogExerciseTypeBinding? = null
    private val binding get() = _binding!!

    var onTypeSelected: ((ExerciseType) -> Unit)? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogExerciseTypeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupClickListeners()
    }

    private fun setupClickListeners() {
        with(binding) {
            runningCard.setOnClickListener { selectType(ExerciseType.RUNNING) }
            walkingCard.setOnClickListener { selectType(ExerciseType.WALKING) }
            cyclingCard.setOnClickListener { selectType(ExerciseType.CYCLING) }
            swimmingCard.setOnClickListener { selectType(ExerciseType.SWIMMING) }
            strengthCard.setOnClickListener { selectType(ExerciseType.STRENGTH_TRAINING) }
            yogaCard.setOnClickListener { selectType(ExerciseType.YOGA) }
            hiitCard.setOnClickListener { selectType(ExerciseType.HIIT) }
            otherCard.setOnClickListener { selectType(ExerciseType.OTHER) }
        }
    }

    private fun selectType(type: ExerciseType) {
        onTypeSelected?.invoke(type)
        dismiss()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val TAG = "ExerciseTypeDialog"
    }
} 