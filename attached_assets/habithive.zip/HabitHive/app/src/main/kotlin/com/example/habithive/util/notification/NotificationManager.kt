package com.example.habithive.util.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.habithive.R
import com.example.habithive.ui.MainActivity
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        const val CHANNEL_ACHIEVEMENTS = "achievements"
        const val CHANNEL_LEADERBOARD = "leaderboard"
        const val CHANNEL_GOALS = "goals"
        const val CHANNEL_FRIEND_REQUESTS = "friend_requests"
        const val CHANNEL_EXERCISE = "exercise"
    }

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channels = listOf(
                NotificationChannel(
                    CHANNEL_ACHIEVEMENTS,
                    context.getString(R.string.channel_achievements),
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = context.getString(R.string.channel_achievements_description)
                },
                NotificationChannel(
                    CHANNEL_LEADERBOARD,
                    context.getString(R.string.channel_leaderboard),
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = context.getString(R.string.channel_leaderboard_description)
                },
                NotificationChannel(
                    CHANNEL_GOALS,
                    context.getString(R.string.channel_goals),
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = context.getString(R.string.channel_goals_description)
                },
                NotificationChannel(
                    CHANNEL_FRIEND_REQUESTS,
                    context.getString(R.string.channel_friend_requests),
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = context.getString(R.string.channel_friend_requests_description)
                },
                NotificationChannel(
                    CHANNEL_EXERCISE,
                    context.getString(R.string.channel_exercise),
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = context.getString(R.string.channel_exercise_description)
                }
            )

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            channels.forEach { channel ->
                notificationManager.createNotificationChannel(channel)
            }
        }
    }

    fun showAchievementNotification(title: String, description: String) {
        showNotification(
            channelId = CHANNEL_ACHIEVEMENTS,
            notificationId = System.currentTimeMillis().toInt(),
            title = title,
            content = description,
            priority = NotificationCompat.PRIORITY_DEFAULT
        )
    }

    fun showLeaderboardUpdateNotification(newRank: Int, oldRank: Int) {
        val content = when {
            newRank < oldRank -> context.getString(R.string.leaderboard_rank_improved, oldRank, newRank)
            newRank > oldRank -> context.getString(R.string.leaderboard_rank_decreased, oldRank, newRank)
            else -> return
        }

        showNotification(
            channelId = CHANNEL_LEADERBOARD,
            notificationId = System.currentTimeMillis().toInt(),
            title = context.getString(R.string.leaderboard_update),
            content = content,
            priority = NotificationCompat.PRIORITY_DEFAULT
        )
    }

    fun showGoalReminderNotification(goalTitle: String, daysLeft: Int) {
        val content = context.getString(R.string.goal_reminder, goalTitle, daysLeft)
        showNotification(
            channelId = CHANNEL_GOALS,
            notificationId = System.currentTimeMillis().toInt(),
            title = context.getString(R.string.goal_reminder_title),
            content = content,
            priority = NotificationCompat.PRIORITY_HIGH
        )
    }

    fun showFriendRequestNotification(fromUser: String) {
        showNotification(
            channelId = CHANNEL_FRIEND_REQUESTS,
            notificationId = System.currentTimeMillis().toInt(),
            title = context.getString(R.string.new_friend_request),
            content = context.getString(R.string.friend_request_from, fromUser),
            priority = NotificationCompat.PRIORITY_DEFAULT
        )
    }

    fun showExerciseReminderNotification() {
        showNotification(
            channelId = CHANNEL_EXERCISE,
            notificationId = System.currentTimeMillis().toInt(),
            title = context.getString(R.string.exercise_reminder_title),
            content = context.getString(R.string.exercise_reminder_content),
            priority = NotificationCompat.PRIORITY_HIGH
        )
    }

    private fun showNotification(
        channelId: String,
        notificationId: Int,
        title: String,
        content: String,
        priority: Int
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(content)
            .setPriority(priority)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        with(NotificationManagerCompat.from(context)) {
            notify(notificationId, builder.build())
        }
    }
} 