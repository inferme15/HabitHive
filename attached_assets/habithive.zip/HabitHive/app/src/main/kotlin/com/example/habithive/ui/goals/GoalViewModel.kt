package com.example.habithive.ui.goals

import androidx.lifecycle.viewModelScope
import com.example.habithive.base.BaseViewModel
import com.example.habithive.data.model.*
import com.example.habithive.data.repository.GoalRepository
import com.example.habithive.data.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class GoalViewModel @Inject constructor(
    private val goalRepository: GoalRepository,
    private val userRepository: UserRepository
) : BaseViewModel() {

    private val _goalsState = MutableStateFlow<GoalsState>(GoalsState.Loading)
    val goalsState: StateFlow<GoalsState> = _goalsState

    private val _goalCreationState = MutableStateFlow<GoalCreationState>(GoalCreationState.Idle)
    val goalCreationState: StateFlow<GoalCreationState> = _goalCreationState

    init {
        loadGoals()
    }

    fun loadGoals() {
        viewModelScope.launch {
            _goalsState.value = GoalsState.Loading
            safeCall(
                onError = { _goalsState.value = GoalsState.Error(it.message ?: "Failed to load goals") }
            ) {
                val userId = userRepository.getCurrentUserId()
                val goals = goalRepository.getAllGoals(userId)
                
                // Group goals by status
                val activeGoals = goals.filter { it.status == GoalStatus.IN_PROGRESS }
                val completedGoals = goals.filter { it.status == GoalStatus.COMPLETED }
                val failedGoals = goals.filter { it.status == GoalStatus.FAILED }

                _goalsState.value = GoalsState.Success(
                    activeGoals = activeGoals,
                    completedGoals = completedGoals,
                    failedGoals = failedGoals
                )
            }
        }
    }

    fun createGoal(
        title: String,
        description: String,
        type: GoalType,
        targetValue: Double,
        frequency: GoalFrequency,
        endDate: Long,
        exerciseTypes: List<ExerciseType>,
        reminderEnabled: Boolean,
        reminderTime: Long?
    ) {
        viewModelScope.launch {
            _goalCreationState.value = GoalCreationState.Loading
            safeCall(
                onError = { _goalCreationState.value = GoalCreationState.Error(it.message ?: "Failed to create goal") }
            ) {
                val userId = userRepository.getCurrentUserId()
                val goal = Goal(
                    userId = userId,
                    title = title,
                    description = description,
                    type = type,
                    targetValue = targetValue,
                    frequency = frequency,
                    endDate = endDate,
                    exerciseTypes = exerciseTypes,
                    reminderEnabled = reminderEnabled,
                    reminderTime = reminderTime
                )

                goalRepository.createGoal(goal)
                _goalCreationState.value = GoalCreationState.Success
                loadGoals()
            }
        }
    }

    fun deleteGoal(goalId: String) {
        viewModelScope.launch {
            safeCall {
                goalRepository.deleteGoal(goalId)
                loadGoals()
            }
        }
    }

    fun checkGoalStatus() {
        viewModelScope.launch {
            safeCall {
                val userId = userRepository.getCurrentUserId()
                goalRepository.checkAndUpdateGoalStatus(userId)
                loadGoals()
            }
        }
    }
} 