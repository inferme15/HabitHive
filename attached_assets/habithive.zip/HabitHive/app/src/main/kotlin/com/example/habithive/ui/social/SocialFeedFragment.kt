package com.example.habithive.ui.social

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.habithive.R
import com.example.habithive.databinding.FragmentSocialFeedBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SocialFeedFragment : Fragment(R.layout.fragment_social_feed) {
    private val binding by viewBinding(FragmentSocialFeedBinding::bind)
    private val viewModel: SocialFeedViewModel by viewModels()
    private lateinit var adapter: SocialPostAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observePosts()
    }

    private fun setupRecyclerView() {
        adapter = SocialPostAdapter(
            onLikeClick = { post -> viewModel.likePost(post.id) },
            onCommentClick = { post -> showCommentDialog(post) }
        )
        binding.postsRecyclerView.adapter = adapter
    }

    private fun observePosts() {
        viewModel.posts.observe(viewLifecycleOwner) { posts ->
            adapter.submitList(posts)
        }
    }
} 