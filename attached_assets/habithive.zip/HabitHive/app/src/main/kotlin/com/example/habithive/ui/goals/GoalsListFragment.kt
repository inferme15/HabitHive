package com.example.habithive.ui.goals

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import androidx.core.view.MenuProvider
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.example.habithive.R
import com.example.habithive.data.model.Goal
import com.example.habithive.databinding.FragmentGoalsListBinding
import com.example.habithive.util.showError
import com.example.habithive.util.viewBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayoutMediator
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class GoalsListFragment : Fragment(R.layout.fragment_goals_list), MenuProvider {

    private val binding by viewBinding(FragmentGoalsListBinding::bind)
    private val viewModel: GoalsViewModel by viewModels()
    private lateinit var goalsPagerAdapter: GoalsPagerAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeState()
        
        // Restore saved filters and sort options
        savedInstanceState?.let { state ->
            val filters = state.getSerializable(KEY_FILTERS) as? Set<GoalFilter>
            val sort = state.getSerializable(KEY_SORT) as? GoalSort
            filters?.let { viewModel.updateFilters(it.toList()) }
            sort?.let { viewModel.updateSort(it) }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putSerializable(KEY_FILTERS, viewModel.currentFilters.toSet())
        outState.putSerializable(KEY_SORT, viewModel.currentSort)
    }

    private fun setupUI() {
        setupToolbar()
        setupViewPager()
        setupFab()
        setupSwipeRefresh()
    }

    private fun setupToolbar() {
        requireActivity().addMenuProvider(this, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }

    private fun setupViewPager() {
        goalsPagerAdapter = GoalsPagerAdapter(this)
        binding.viewPager.adapter = goalsPagerAdapter

        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> getString(R.string.active_goals)
                1 -> getString(R.string.completed_goals)
                else -> throw IllegalStateException("Invalid position: $position")
            }
        }.attach()
    }

    private fun setupFab() {
        binding.fabCreateGoal.setOnClickListener {
            findNavController().navigate(
                GoalsListFragmentDirections.actionGoalsListToCreateGoal()
            )
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.refreshGoals()
        }
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.goalsState.collect { state ->
                    updateUI(state)
                }
            }
        }
    }

    private fun updateUI(state: GoalsState) {
        binding.swipeRefresh.isRefreshing = state is GoalsState.Loading
        binding.progressBar.isVisible = state is GoalsState.Loading && !binding.swipeRefresh.isRefreshing
        binding.emptyState.root.isVisible = state is GoalsState.Success && state.goals.isEmpty()
        binding.viewPager.isVisible = state is GoalsState.Success && state.goals.isNotEmpty()
        binding.tabLayout.isVisible = state is GoalsState.Success && state.goals.isNotEmpty()

        when (state) {
            is GoalsState.Success -> {
                if (state.goals.isEmpty()) {
                    binding.emptyState.tvMessage.text = getString(R.string.no_goals_message)
                    binding.emptyState.btnAction.apply {
                        text = getString(R.string.create_first_goal)
                        setOnClickListener {
                            findNavController().navigate(
                                GoalsListFragmentDirections.actionGoalsListToCreateGoal()
                            )
                        }
                    }
                }
            }
            is GoalsState.Error -> {
                showError(state.message)
                Snackbar.make(requireView(), state.message, Snackbar.LENGTH_INDEFINITE)
                    .setAction("Retry") {
                        viewModel.refreshGoals()
                    }
                    .show()
            }
            else -> Unit
        }
    }

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menuInflater.inflate(R.menu.menu_goals_list, menu)
    }

    override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
        return when (menuItem.itemId) {
            R.id.action_filter -> {
                showFilterDialog()
                true
            }
            R.id.action_sort -> {
                showSortDialog()
                true
            }
            else -> false
        }
    }

    private fun showFilterDialog() {
        val filters = GoalFilter.values()
        val filterNames = filters.map { it.name.replace("_", " ") }.toTypedArray()
        val checkedItems = BooleanArray(filters.size) { index ->
            filters[index] in viewModel.currentFilters
        }

        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.filter_goals)
            .setMultiChoiceItems(filterNames, checkedItems) { _, which, isChecked ->
                checkedItems[which] = isChecked
            }
            .setPositiveButton(R.string.apply) { _, _ ->
                val selectedFilters = filters.filterIndexed { index, _ ->
                    checkedItems[index]
                }
                viewModel.updateFilters(selectedFilters)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showSortDialog() {
        val sortOptions = GoalSort.values()
        val sortNames = sortOptions.map { it.name.replace("_", " ") }.toTypedArray()

        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.sort_goals)
            .setSingleChoiceItems(
                sortNames,
                sortOptions.indexOf(viewModel.currentSort)
            ) { dialog, which ->
                viewModel.updateSort(sortOptions[which])
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    companion object {
        private const val KEY_FILTERS = "key_filters"
        private const val KEY_SORT = "key_sort"
    }
} 