package com.example.habithive.data.repository

import com.example.habithive.data.model.Exercise
import com.example.habithive.data.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirebaseRepositoryImpl @Inject constructor(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore
) : FirebaseRepository {
    private val usersCollection = firestore.collection(User.COLLECTION)
    private val exercisesCollection = firestore.collection(Exercise.COLLECTION)
    
    override suspend fun signUp(email: String, password: String): FirebaseUser? {
        val result = auth.createUserWithEmailAndPassword(email, password).await()
        return result.user
    }
    
    override suspend fun signIn(email: String, password: String): FirebaseUser? {
        val result = auth.signInWithEmailAndPassword(email, password).await()
        return result.user
    }
    
    override suspend fun signInWithCredential(credential: PhoneAuthCredential): FirebaseUser? {
        val result = auth.signInWithCredential(credential).await()
        return result.user
    }
    
    override suspend fun signOut() {
        auth.signOut()
    }
    
    override fun getCurrentUser(): FirebaseUser? = auth.currentUser
    
    override fun getFirebaseAuth(): FirebaseAuth = auth
    
    override suspend fun createUserProfile(user: User) {
        usersCollection.document(user.id).set(user).await()
    }
    
    override suspend fun updateUserProfile(user: User) {
        usersCollection.document(user.id).set(user).await()
    }
    
    override fun getUserData(userId: String): Flow<User?> = callbackFlow {
        val subscription = usersCollection.document(userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                trySend(snapshot?.toObject(User::class.java))
            }
        awaitClose { subscription.remove() }
    }
    
    override suspend fun addExercise(exercise: Exercise) {
        val exerciseRef = exercisesCollection.document()
        val exerciseWithId = exercise.copy(id = exerciseRef.id)
        exerciseRef.set(exerciseWithId).await()

        // Update user points
        val userFlow = getUserData(exercise.userId)
        userFlow.collect { user ->
            user?.let {
                val updatedUser = it.copy(
                    points = it.points + exercise.points
                )
                updateUserProfile(updatedUser)
            }
        }
    }
    
    override suspend fun updateExercise(exercise: Exercise) {
        exercisesCollection.document(exercise.id).set(exercise).await()
    }
    
    override suspend fun deleteExercise(exerciseId: String) {
        exercisesCollection.document(exerciseId).delete().await()
    }
    
    override fun observeLeaderboard(): Flow<List<User>> = callbackFlow {
        val listener = usersCollection
            .orderBy("points", Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val users = snapshot?.documents?.mapNotNull {
                    it.toObject(User::class.java)
                } ?: emptyList()
                trySend(users)
            }
        awaitClose { listener.remove() }
    }
    
    override suspend fun updateUserPoints(userId: String, points: Int) {
        firestore.collection("users")
            .document(userId)
            .update("points", points)
            .await()
    }
    
    override suspend fun updateUserStreak(userId: String) {
        val userRef = usersCollection.document(userId)
        firestore.runTransaction { transaction ->
            val snapshot = transaction.get(userRef)
            val currentStreak = snapshot.getLong("streakCount") ?: 0
            transaction.update(userRef, "streakCount", currentStreak + 1)
        }.await()
    }

    override fun getTodayExercises(userId: String): Flow<List<Exercise>> = callbackFlow {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        val startOfDay = calendar.timeInMillis

        val subscription = exercisesCollection
            .whereEqualTo("userId", userId)
            .whereGreaterThanOrEqualTo("timestamp", startOfDay)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val exercises = snapshot?.documents?.mapNotNull {
                    it.toObject(Exercise::class.java)
                } ?: emptyList()
                trySend(exercises)
            }
        awaitClose { subscription.remove() }
    }

    override fun getAllExercises(userId: String): Flow<List<Exercise>> = callbackFlow {
        val subscription = exercisesCollection
            .whereEqualTo("userId", userId)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val exercises = snapshot?.documents?.mapNotNull {
                    it.toObject(Exercise::class.java)
                } ?: emptyList()
                trySend(exercises)
            }
        awaitClose { subscription.remove() }
    }
}