package com.example.habithive.data.model

import kotlinx.serialization.Serializable

@Serializable
data class Post(
    val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userPhotoUrl: String? = null,
    val content: String = "",
    val imageUrl: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val likes: Int = 0,
    val commentsCount: Int = 0,
    val type: PostType = PostType.GENERAL,
    val achievement: Achievement? = null,
    val exerciseData: ExerciseData? = null
)

@Serializable
enum class PostType {
    GENERAL,
    ACHIEVEMENT,
    EXERCISE_COMPLETED,
    GOAL_COMPLETED
}

@Serializable
data class ExerciseData(
    val type: String,
    val duration: Int,
    val caloriesBurned: Int
) 