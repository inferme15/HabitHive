package com.example.habithive.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.habithive.data.repository.UserRepository
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class SignInState {
    object Loading : SignInState()
    object Success : SignInState()
    data class Error(val message: String) : SignInState()
    object Idle : SignInState()
}

@HiltViewModel
class SignInViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _signInState = MutableLiveData<SignInState>(SignInState.Idle)
    val signInState: LiveData<SignInState> = _signInState

    fun signIn(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _signInState.value = SignInState.Error("Email and password cannot be empty")
            return
        }

        viewModelScope.launch {
            _signInState.value = SignInState.Loading
            try {
                userRepository.signIn(email, password)
                _signInState.value = SignInState.Success
            } catch (e: Exception) {
                _signInState.value = SignInState.Error(e.message ?: "Sign in failed")
            }
        }
    }

    fun signInWithGoogle(account: GoogleSignInAccount) {
        viewModelScope.launch {
            _signInState.value = SignInState.Loading
            try {
                val result = userRepository.signInWithGoogle(account)
                result.fold(
                    onSuccess = { _signInState.value = SignInState.Success },
                    onFailure = { _signInState.value = SignInState.Error(it.message ?: "Google sign in failed") }
                )
            } catch (e: Exception) {
                _signInState.value = SignInState.Error(e.message ?: "Google sign in failed")
            }
        }
    }
} 