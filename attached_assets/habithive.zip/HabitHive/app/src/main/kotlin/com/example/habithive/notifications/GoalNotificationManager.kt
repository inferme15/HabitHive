package com.example.habithive.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.habithive.R
import com.example.habithive.data.model.Goal
import com.example.habithive.ui.MainActivity
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoalNotificationManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val notificationManager = NotificationManagerCompat.from(context)

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channels = listOf(
                NotificationChannel(
                    CHANNEL_GOAL_REMINDERS,
                    context.getString(R.string.channel_goal_reminders),
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = context.getString(R.string.channel_goal_reminders_description)
                },
                NotificationChannel(
                    CHANNEL_GOAL_UPDATES,
                    context.getString(R.string.channel_goal_updates),
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = context.getString(R.string.channel_goal_updates_description)
                },
                NotificationChannel(
                    CHANNEL_GOAL_ACHIEVEMENTS,
                    context.getString(R.string.channel_goal_achievements),
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = context.getString(R.string.channel_goal_achievements_description)
                }
            )
            notificationManager.createNotificationChannels(channels)
        }
    }

    fun showGoalReminder(goal: Goal) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra(EXTRA_GOAL_ID, goal.id)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            goal.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Implementation of showGoalReminder method
    }
} 