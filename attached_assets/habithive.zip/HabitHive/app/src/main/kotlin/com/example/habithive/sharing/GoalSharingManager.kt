package com.example.habithive.sharing

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.habithive.R
import com.example.habithive.data.model.Goal
import com.example.habithive.data.model.GoalShare
import com.example.habithive.data.repository.GoalRepository
import com.example.habithive.util.formatValue
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoalSharingManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val goalRepository: GoalRepository,
    private val achievementManager: GoalAchievementManager
) {
    suspend fun shareGoal(goal: Goal, shareType: ShareType) {
        val shareContent = when (shareType) {
            ShareType.PROGRESS -> createProgressShare(goal)
            ShareType.ACHIEVEMENT -> createAchievementShare(goal)
            ShareType.CHALLENGE -> createChallengeShare(goal)
        }

        // Save share to history
        saveShareHistory(goal.id, shareType)

        // Generate sharing intent
        val sharingIntent = createSharingIntent(shareContent)
        
        // Launch sharing dialog
        withContext(Dispatchers.Main) {
            context.startActivity(sharingIntent)
        }
    }

    private suspend fun createProgressShare(goal: Goal): ShareContent {
        val progress = (goal.currentValue / goal.targetValue) * 100
        val progressText = context.getString(
            R.string.goal_progress_share_text,
            goal.title,
            formatValue(goal.currentValue, goal.type),
            formatValue(goal.targetValue, goal.type),
            progress.toInt()
        )

        val progressCard = createProgressCard(goal)
        return ShareContent(
            text = progressText,
            image = progressCard,
            type = ShareType.PROGRESS
        )
    }

    private suspend fun createAchievementShare(goal: Goal): ShareContent {
        val achievementText = context.getString(
            R.string.goal_achievement_share_text,
            goal.title,
            formatValue(goal.targetValue, goal.type)
        )

        val achievementCard = achievementManager.createAchievementCard(goal)
        return ShareContent(
            text = achievementText,
            image = achievementCard,
            type = ShareType.ACHIEVEMENT
        )
    }

    private suspend fun createChallengeShare(goal: Goal): ShareContent {
        val challengeText = context.getString(
            R.string.goal_challenge_share_text,
            goal.title,
            formatValue(goal.targetValue, goal.type)
        )

        val challengeCard = createChallengeCard(goal)
        return ShareContent(
            text = challengeText,
            image = challengeCard,
            type = ShareType.CHALLENGE
        )
    }

    private suspend fun saveShareHistory(goalId: String, shareType: ShareType) {
        val share = GoalShare(
            id = UUID.randomUUID().toString(),
            goalId = goalId,
            type = shareType,
            timestamp = Date()
        )
        goalRepository.saveGoalShare(share)
    }

    private suspend fun createSharingIntent(shareContent: ShareContent): Intent {
        return Intent().apply {
            action = Intent.ACTION_SEND
            type = "image/*"
            
            // Add text
            putExtra(Intent.EXTRA_TEXT, shareContent.text)
            
            // Add image
            val imageUri = saveImageToCache(shareContent.image)
            putExtra(Intent.EXTRA_STREAM, imageUri)
            
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private suspend fun saveImageToCache(bitmap: Bitmap): Uri = withContext(Dispatchers.IO) {
        val imagesFolder = File(context.cacheDir, "images")
        imagesFolder.mkdirs()

        val file = File(imagesFolder, "shared_image_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { stream ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        }

        FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }
}

enum class ShareType {
    PROGRESS,
    ACHIEVEMENT,
    CHALLENGE
}

data class ShareContent(
    val text: String,
    val image: Bitmap,
    val type: ShareType
) 