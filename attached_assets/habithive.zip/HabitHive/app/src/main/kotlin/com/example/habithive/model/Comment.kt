package com.example.habithive.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.parcelize.RawValue
import java.util.Date

@Parcelize
data class Comment(
    val id: String = "",
    val userId: String = "",
    val text: String = "",
    val timestamp: @RawValue Date = Date()
) : Parcelable 