package com.example.habithive.repository

import com.example.habithive.model.User
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LeaderboardRepository @Inject constructor(
    private val db: FirebaseFirestore
) {
    suspend fun getLeaderboard(): List<User> {
        return try {
            val snapshot = db.collection("users")
                .orderBy("totalPoints", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .limit(100)
                .get()
                .await()

            if (snapshot.isEmpty) {
                emptyList()
            } else {
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(User::class.java)
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun updateUserPoints(userId: String, points: Int) {
        try {
            db.collection("users").document(userId)
                .update("totalPoints", points)
                .await()
        } catch (e: Exception) {
            throw e
        }
    }
} 