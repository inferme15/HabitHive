package com.example.habithive.ui.community

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.habithive.databinding.FragmentCommunityGoalsBinding
import com.example.habithive.model.CommunityGoal
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class CommunityGoalsFragment : Fragment() {
    private var _binding: FragmentCommunityGoalsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: CommunityGoalViewModel by viewModels()
    private lateinit var adapter: CommunityGoalsAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCommunityGoalsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = CommunityGoalsAdapter { goal ->
            // Handle goal click
            viewModel.selectGoal(goal)
            // TODO: Navigate to goal details
        }
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@CommunityGoalsFragment.adapter
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.myGoals.collectLatest { goals ->
                adapter.submitList(goals)
                updateEmptyState(goals)
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.participatingGoals.collectLatest { goals ->
                adapter.submitList(goals)
                updateEmptyState(goals)
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.isLoading.collectLatest { isLoading ->
                binding.progressIndicator.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
        }
    }

    private fun updateEmptyState(goals: List<CommunityGoal>) {
        binding.emptyStateText.visibility = if (goals.isEmpty()) View.VISIBLE else View.GONE
    }

    fun updateGoals(goals: List<CommunityGoal>) {
        adapter.submitList(goals)
        updateEmptyState(goals)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        fun newInstance() = CommunityGoalsFragment()
    }
} 