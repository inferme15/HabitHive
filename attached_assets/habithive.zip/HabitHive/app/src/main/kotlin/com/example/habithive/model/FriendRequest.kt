package com.example.habithive.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class FriendRequest(
    val id: String,
    val senderId: String,
    val receiverId: String,
    val senderUsername: String,
    val senderProfileImageUrl: String? = null,
    val status: String = "pending"
) : Parcelable {
    // Empty constructor required for Firestore
    constructor() : this("", "", "", "", null, "pending")
}

enum class RequestStatus {
    PENDING,
    ACCEPTED,
    REJECTED
} 