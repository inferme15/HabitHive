package com.example.habithive.util

import android.content.Context
import android.content.SharedPreferences
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PreferenceManager @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs: SharedPreferences = context.getSharedPreferences(
        Constants.PREFS_NAME,
        Context.MODE_PRIVATE
    )

    var userId: String?
        get() = prefs.getString(Constants.KEY_USER_ID, null)
        set(value) = prefs.edit().putString(Constants.KEY_USER_ID, value).apply()

    var userName: String?
        get() = prefs.getString(Constants.KEY_USER_NAME, null)
        set(value) = prefs.edit().putString(Constants.KEY_USER_NAME, value).apply()

    var userEmail: String?
        get() = prefs.getString(Constants.KEY_USER_EMAIL, null)
        set(value) = prefs.edit().putString(Constants.KEY_USER_EMAIL, value).apply()

    var userPhoto: String?
        get() = prefs.getString(Constants.KEY_USER_PHOTO, null)
        set(value) = prefs.edit().putString(Constants.KEY_USER_PHOTO, value).apply()

    var theme: String
        get() = prefs.getString(Constants.KEY_THEME, "system") ?: "system"
        set(value) = prefs.edit().putString(Constants.KEY_THEME, value).apply()

    var notificationsEnabled: Boolean
        get() = prefs.getBoolean(Constants.KEY_NOTIFICATIONS, true)
        set(value) = prefs.edit().putBoolean(Constants.KEY_NOTIFICATIONS, value).apply()

    fun clearUserData() {
        prefs.edit().apply {
            remove(Constants.KEY_USER_ID)
            remove(Constants.KEY_USER_NAME)
            remove(Constants.KEY_USER_EMAIL)
            remove(Constants.KEY_USER_PHOTO)
            apply()
        }
    }
} 