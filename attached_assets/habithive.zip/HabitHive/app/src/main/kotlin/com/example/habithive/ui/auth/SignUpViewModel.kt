package com.example.habithive.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class SignUpViewModel : ViewModel() {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private val _signUpSuccess = MutableStateFlow(false)
    val signUpSuccess: StateFlow<Boolean> = _signUpSuccess.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun signUp(email: String, password: String) {
        viewModelScope.launch {
            try {
                val result = auth.createUserWithEmailAndPassword(email, password).await()
                val user = result.user
                
                if (user != null) {
                    // Create initial user document in Firestore
                    val userData = hashMapOf(
                        "id" to user.uid,
                        "email" to email,
                        "createdAt" to System.currentTimeMillis()
                    )
                    
                    db.collection("users").document(user.uid)
                        .set(userData)
                        .await()
                    
                    _signUpSuccess.value = true
                    _error.value = null
                }
            } catch (e: Exception) {
                _error.value = when {
                    e.message?.contains("email address is already in use") == true ->
                        "This email is already registered. Please sign in instead."
                    e.message?.contains("badly formatted") == true ->
                        "Please enter a valid email address."
                    e.message?.contains("password") == true ->
                        "Password should be at least 6 characters."
                    else -> "Sign up failed: ${e.message}"
                }
            }
        }
    }
} 