package com.example.habithive.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class UserLevel(
    val level: Int = 1,
    val xp: Int = 0,
    val progress: Float = 0f,
    val xpToNextLevel: Int = 100
) : Parcelable {
    companion object {
        fun fromXp(totalXp: Int): UserLevel {
            val level = LevelCalculator.calculateLevel(totalXp)
            val progress = LevelCalculator.calculateProgressToNextLevel(totalXp)
            val xpToNextLevel = LevelCalculator.calculateXpForNextLevel(totalXp)
            return UserLevel(level, totalXp, progress, xpToNextLevel)
        }
    }
}

object LevelCalculator {
    fun calculateLevel(points: Int): Int {
        return (Math.sqrt(points.toDouble() / 100) + 1).toInt()
    }

    fun pointsToNextLevel(currentLevel: Int): Int {
        return (currentLevel * 100) * (currentLevel * 100)
    }

    fun pointsInCurrentLevel(currentLevel: Int, totalPoints: Int): Int {
        val levelStartPoints = if (currentLevel > 1) {
            ((currentLevel - 1) * 100) * ((currentLevel - 1) * 100)
        } else {
            0
        }
        return totalPoints - levelStartPoints
    }

    fun calculateProgressToNextLevel(totalXp: Int): Float {
        val currentLevel = calculateLevel(totalXp)
        val xpToNextLevel = calculateXpForNextLevel(totalXp)
        val xpInCurrentLevel = pointsInCurrentLevel(currentLevel, totalXp)
        return xpInCurrentLevel.toFloat() / xpToNextLevel.toFloat()
    }

    fun calculateXpForNextLevel(totalXp: Int): Int {
        val currentLevel = calculateLevel(totalXp)
        return pointsToNextLevel(currentLevel) - totalXp
    }
} 