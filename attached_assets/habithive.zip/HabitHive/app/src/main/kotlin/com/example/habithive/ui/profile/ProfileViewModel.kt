package com.example.habithive.ui.profile

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.habithive.data.model.User
import com.example.habithive.data.repository.UserRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

data class ProfileState(
    val user: User? = null,
    val isLoading: Boolean = false,
    val error: String? = null,
    val isSignedOut: Boolean = false
)

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val auth: FirebaseAuth,
    private val storage: FirebaseStorage
) : ViewModel() {

    private val _profileState = MutableStateFlow(ProfileState())
    val profileState: StateFlow<ProfileState> = _profileState

    init {
        loadUserData()
    }

    private fun loadUserData() {
        viewModelScope.launch {
            try {
                _profileState.update { it.copy(isLoading = true) }
                val user = userRepository.getCurrentUser()
                _profileState.update { 
                    it.copy(
                        user = user,
                        isLoading = false,
                        error = null
                    )
                }
            } catch (e: Exception) {
                _profileState.update { 
                    it.copy(
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }

    fun updateProfile(user: User) {
        viewModelScope.launch {
            try {
                _profileState.update { it.copy(isLoading = true) }
                userRepository.updateUser(user)
                _profileState.update { 
                    it.copy(
                        user = user,
                        isLoading = false,
                        error = null
                    )
                }
            } catch (e: Exception) {
                _profileState.update { 
                    it.copy(
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }

    fun updateProfilePhoto(imageUri: Uri) {
        viewModelScope.launch {
            try {
                _profileState.update { it.copy(isLoading = true) }
                val userId = auth.currentUser?.uid ?: throw IllegalStateException("User not authenticated")
                val imageRef = storage.reference.child("profile_images/$userId.jpg")
                
                // Upload image
                imageRef.putFile(imageUri).await()
                
                // Get download URL
                val downloadUrl = imageRef.downloadUrl.await().toString()
                
                // Update user profile with new image URL
                val currentUser = _profileState.value.user ?: throw IllegalStateException("User data not loaded")
                val updatedUser = currentUser.copy(photoUrl = downloadUrl)
                
                userRepository.updateUser(updatedUser)
                _profileState.update { 
                    it.copy(
                        user = updatedUser,
                        isLoading = false,
                        error = null
                    )
                }
            } catch (e: Exception) {
                _profileState.update { 
                    it.copy(
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }

    fun signOut() {
        viewModelScope.launch {
            try {
                auth.signOut()
                _profileState.update { 
                    it.copy(
                        user = null,
                        isSignedOut = true
                    )
                }
            } catch (e: Exception) {
                _profileState.update { 
                    it.copy(error = e.message)
                }
            }
        }
    }

    fun refresh() {
        loadUserData()
    }
} 