package com.example.habithive.data.repository

import com.example.habithive.data.model.Goal
import com.example.habithive.data.model.Exercise
import kotlinx.coroutines.flow.Flow

interface GoalRepository {
    fun getUserGoals(userId: String): Flow<List<Goal>>
    suspend fun getGoal(goalId: String): Goal?
    suspend fun createGoal(goal: Goal)
    suspend fun updateGoal(goal: Goal)
    suspend fun deleteGoal(goalId: String)
    suspend fun completeGoal(goalId: String)
    suspend fun updateGoalProgress(goalId: String, progress: Int)
    suspend fun getAllGoals(userId: String): List<Goal>
    suspend fun getActiveGoals(userId: String): List<Goal>
    fun getGoalsFlow(userId: String): Flow<List<Goal>>
    suspend fun checkAndUpdateGoalStatus(userId: String)
    suspend fun getUserCompletedGoalsCount(userId: String): Int
} 