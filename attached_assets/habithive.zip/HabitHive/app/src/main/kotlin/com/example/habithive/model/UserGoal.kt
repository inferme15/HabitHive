package com.example.habithive.model

import com.google.firebase.firestore.DocumentId
import java.util.Date

data class UserGoal(
    @DocumentId
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val description: String = "",
    val targetValue: Double = 0.0,
    val currentValue: Double = 0.0,
    val frequency: String = "", // DAILY, WEEKLY, MONTHLY
    val type: String = "", // EXERCISE, STEPS, CALORIES, etc.
    val startDate: Date = Date(),
    val endDate: Date = Date(),
    val completed: Boolean = false,
    val unit: String = "" // km, steps, calories, etc.
) 