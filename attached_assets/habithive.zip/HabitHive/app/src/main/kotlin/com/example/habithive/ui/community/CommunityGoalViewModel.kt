package com.example.habithive.ui.community

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.habithive.model.CommunityGoal
import com.example.habithive.model.Comment
import com.example.habithive.model.GoalStatus
import com.example.habithive.repository.CommunityGoalRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CommunityGoalViewModel @Inject constructor(
    private val repository: CommunityGoalRepository
) : ViewModel() {
    private val _myGoals = MutableStateFlow<List<CommunityGoal>>(emptyList())
    val myGoals: StateFlow<List<CommunityGoal>> = _myGoals

    private val _participatingGoals = MutableStateFlow<List<CommunityGoal>>(emptyList())
    val participatingGoals: StateFlow<List<CommunityGoal>> = _participatingGoals

    private val _selectedGoal = MutableStateFlow<CommunityGoal?>(null)
    val selectedGoal: StateFlow<CommunityGoal?> = _selectedGoal

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun loadGoals(userId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val myGoalsList = repository.getGoalsByUser(userId)
                val participatingGoalsList = repository.getParticipatingGoals(userId)
                _myGoals.value = myGoalsList
                _participatingGoals.value = participatingGoalsList
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loadGoalById(goalId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val goal = repository.getGoalById(goalId)
                _selectedGoal.value = goal
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun createGoal(goal: CommunityGoal) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.createGoal(goal)
                loadGoals(goal.creatorId)
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun joinGoal(goalId: String, userId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.joinGoal(goalId, userId)
                loadGoals(userId)
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun supportGoal(goalId: String, userId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.supportGoal(goalId, userId)
                loadGoals(userId)
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun updateProgress(goalId: String, newValue: Int) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.updateProgress(goalId, newValue)
                _selectedGoal.value?.let { loadGoals(it.creatorId) }
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun addComment(goalId: String, comment: Comment) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.addComment(goalId, comment)
                _selectedGoal.value?.let { loadGoals(it.creatorId) }
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun updateGoalStatus(goalId: String, status: GoalStatus) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.updateGoalStatus(goalId, status)
                _selectedGoal.value?.let { loadGoals(it.creatorId) }
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun selectGoal(goal: CommunityGoal) {
        _selectedGoal.value = goal
    }
} 