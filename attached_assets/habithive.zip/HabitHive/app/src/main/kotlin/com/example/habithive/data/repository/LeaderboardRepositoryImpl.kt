package com.example.habithive.data.repository

import com.example.habithive.data.model.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.*
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton

@Singleton
class LeaderboardRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore,
    @Named("leaderboard") private val leaderboardCollection: CollectionReference,
    private val userRepository: UserRepository,
    private val achievementRepository: AchievementRepository,
    private val exerciseRepository: ExerciseRepository,
    private val goalRepository: GoalRepository,
    private val friendRepository: FriendRepository
) : LeaderboardRepository {

    override suspend fun getLeaderboard(type: LeaderboardType): LeaderboardStats {
        val collection = getLeaderboardCollection(type)
        val currentUser = userRepository.getCurrentUser()
            ?: throw IllegalStateException("User not found")

        val topPerformers = collection
            .orderBy("score", Query.Direction.DESCENDING)
            .limit(10)
            .get()
            .await()
            .toObjects(LeaderboardEntry::class.java)

        val userRank = getUserRank(currentUser.id, type)
        val totalParticipants = collection.count().get().await().count.toInt()
        val nearbyUsers = getNearbyUsers(currentUser.id, type)

        return LeaderboardStats(
            totalParticipants = totalParticipants,
            userRank = userRank,
            topPerformers = topPerformers,
            nearbyUsers = nearbyUsers
        )
    }

    override suspend fun getUserRank(userId: String, type: LeaderboardType): Int {
        val collection = getLeaderboardCollection(type)
        val userScore = collection
            .document(userId)
            .get()
            .await()
            .toObject(LeaderboardEntry::class.java)
            ?.score ?: 0

        return collection
            .whereGreaterThan("score", userScore)
            .count()
            .get()
            .await()
            .count
            .toInt() + 1
    }

    override suspend fun updateUserScore(userId: String) {
        val user = userRepository.getUserById(userId)
            ?: throw IllegalStateException("User not found")

        val achievements = achievementRepository.getUserAchievements(userId)
        val achievementPoints = achievements
            .filter { it.isCompleted }
            .sumOf { it.achievement?.points ?: 0 }

        val exerciseMinutes = exerciseRepository.getUserTotalExerciseDuration(userId)
        val goalsCompleted = goalRepository.getUserCompletedGoalsCount(userId)
        val currentStreak = exerciseRepository.getUserCurrentStreak(userId)

        // Calculate total score based on various factors
        val score = calculateScore(
            achievementPoints = achievementPoints,
            exerciseMinutes = exerciseMinutes,
            goalsCompleted = goalsCompleted,
            currentStreak = currentStreak
        )

        val entry = LeaderboardEntry(
            userId = userId,
            userName = user.name,
            userPhotoUrl = user.photoUrl,
            score = score,
            achievementPoints = achievementPoints,
            exerciseMinutes = exerciseMinutes,
            goalsCompleted = goalsCompleted,
            currentStreak = currentStreak
        )

        // Update all leaderboard types
        LeaderboardType.values().forEach { type ->
            val collection = getLeaderboardCollection(type)
            when (type) {
                LeaderboardType.WEEKLY, LeaderboardType.MONTHLY -> {
                    if (isWithinCurrentPeriod(type)) {
                        collection.document(userId).set(entry).await()
                    }
                }
                else -> collection.document(userId).set(entry).await()
            }
        }
    }

    override fun getLeaderboardFlow(type: LeaderboardType): Flow<LeaderboardStats> {
        return getLeaderboardCollection(type)
            .orderBy("score", Query.Direction.DESCENDING)
            .snapshots()
            .map { snapshot ->
                val entries = snapshot.toObjects(LeaderboardEntry::class.java)
                val currentUser = userRepository.getCurrentUser()
                    ?: throw IllegalStateException("User not found")

                LeaderboardStats(
                    totalParticipants = entries.size,
                    userRank = entries.indexOfFirst { it.userId == currentUser.id } + 1,
                    topPerformers = entries.take(10),
                    nearbyUsers = getNearbyUsersFromList(entries, currentUser.id)
                )
            }
    }

    override suspend fun getTopPerformers(
        type: LeaderboardType,
        limit: Int
    ): List<LeaderboardEntry> {
        return getLeaderboardCollection(type)
            .orderBy("score", Query.Direction.DESCENDING)
            .limit(limit.toLong())
            .get()
            .await()
            .toObjects(LeaderboardEntry::class.java)
    }

    override suspend fun getNearbyUsers(
        userId: String,
        type: LeaderboardType
    ): List<LeaderboardEntry> {
        val collection = getLeaderboardCollection(type)
        val userScore = collection
            .document(userId)
            .get()
            .await()
            .toObject(LeaderboardEntry::class.java)
            ?.score ?: 0

        // Get users above and below the current user
        val usersAbove = collection
            .whereLessThanOrEqualTo("score", userScore)
            .orderBy("score", Query.Direction.DESCENDING)
            .limit(2)
            .get()
            .await()
            .toObjects(LeaderboardEntry::class.java)

        val usersBelow = collection
            .whereGreaterThanOrEqualTo("score", userScore)
            .orderBy("score", Query.Direction.ASCENDING)
            .limit(2)
            .get()
            .await()
            .toObjects(LeaderboardEntry::class.java)

        return (usersAbove + usersBelow)
            .distinctBy { it.userId }
            .sortedByDescending { it.score }
    }

    private fun getLeaderboardCollection(type: LeaderboardType): CollectionReference {
        return when (type) {
            LeaderboardType.GLOBAL -> leaderboardCollection.document("global").collection("entries")
            LeaderboardType.FRIENDS -> leaderboardCollection.document("friends").collection("entries")
            LeaderboardType.WEEKLY -> leaderboardCollection.document("weekly").collection(getCurrentWeek())
            LeaderboardType.MONTHLY -> leaderboardCollection.document("monthly").collection(getCurrentMonth())
        }
    }

    private fun calculateScore(
        achievementPoints: Int,
        exerciseMinutes: Int,
        goalsCompleted: Int,
        currentStreak: Int
    ): Int {
        // Score calculation formula:
        // - Achievement points are worth 100 each
        // - Every exercise minute is worth 10 points
        // - Each completed goal is worth 500 points
        // - Current streak days are worth 200 points each
        return (achievementPoints * 100) +
                (exerciseMinutes * 10) +
                (goalsCompleted * 500) +
                (currentStreak * 200)
    }

    private fun getCurrentWeek(): String {
        val calendar = Calendar.getInstance()
        calendar.firstDayOfWeek = Calendar.MONDAY
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        return "${calendar.get(Calendar.YEAR)}_week_${calendar.get(Calendar.WEEK_OF_YEAR)}"
    }

    private fun getCurrentMonth(): String {
        val calendar = Calendar.getInstance()
        return "${calendar.get(Calendar.YEAR)}_${calendar.get(Calendar.MONTH) + 1}"
    }

    private fun isWithinCurrentPeriod(type: LeaderboardType): Boolean {
        val calendar = Calendar.getInstance()
        return when (type) {
            LeaderboardType.WEEKLY -> {
                val startOfWeek = Calendar.getInstance().apply {
                    firstDayOfWeek = Calendar.MONDAY
                    set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
                }
                calendar.timeInMillis >= startOfWeek.timeInMillis
            }
            LeaderboardType.MONTHLY -> {
                val startOfMonth = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_MONTH, 1)
                }
                calendar.timeInMillis >= startOfMonth.timeInMillis
            }
            else -> true
        }
    }

    private fun getNearbyUsersFromList(
        entries: List<LeaderboardEntry>,
        userId: String
    ): List<LeaderboardEntry> {
        val userIndex = entries.indexOfFirst { it.userId == userId }
        if (userIndex == -1) return emptyList()

        val startIndex = (userIndex - 2).coerceAtLeast(0)
        val endIndex = (userIndex + 2).coerceAtMost(entries.size - 1)
        return entries.subList(startIndex, endIndex + 1)
    }
} 