package com.example.habithive.repository

import com.example.habithive.data.DailyExerciseSummary
import com.example.habithive.model.Exercise
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.CollectionReference
import java.util.Calendar
import java.util.Date
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Named

class ExerciseRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth,
    @Named("exercises_collection") private val exercisesCollection: CollectionReference,
    @Named("daily_summaries_collection") private val dailySummariesCollection: CollectionReference
) {
    suspend fun createExercise(exercise: Exercise) {
        try {
            exercisesCollection.add(exercise).await()
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun getExercises(userId: String): List<Exercise> {
        return try {
            exercisesCollection
                .whereEqualTo("userId", userId)
                .get()
                .await()
                .documents
                .mapNotNull { doc ->
                    doc.toObject(Exercise::class.java)
                }
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun getExercisesByType(userId: String, type: String): List<Exercise> {
        return try {
            exercisesCollection
                .whereEqualTo("userId", userId)
                .whereEqualTo("type", type)
                .get()
                .await()
                .documents
                .mapNotNull { doc ->
                    doc.toObject(Exercise::class.java)
                }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun updateExercise(exercise: Exercise) {
        try {
            exercisesCollection.document(exercise.id)
                .set(exercise)
                .await()
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun deleteExercise(exerciseId: String) {
        try {
            exercisesCollection.document(exerciseId).delete().await()
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun getExercisesByDateRange(userId: String, startTime: Long, endTime: Long): List<Exercise> {
        return try {
            exercisesCollection
                .whereEqualTo("userId", userId)
                .whereGreaterThanOrEqualTo("date", Timestamp(Date(startTime)))
                .whereLessThanOrEqualTo("date", Timestamp(Date(endTime)))
                .get()
                .await()
                .documents
                .mapNotNull { doc ->
                    doc.toObject(Exercise::class.java)
                }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun calculatePoints(exercise: Exercise): Int {
        // Base points calculation logic
        var points = exercise.duration * 2 // 2 points per minute
        points += exercise.calories / 10 // 1 point per 10 calories
        
        // Bonus points based on exercise type
        when (exercise.type.uppercase()) {
            // Standing exercises (high intensity)
            "RUNNING" -> points += 50
            "JUMPING" -> points += 45
            "BOXING" -> points += 40
            "DANCING" -> points += 35
            "BASKETBALL" -> points += 40

            // Walking exercises (medium-high intensity)
            "JOGGING" -> points += 40
            "HIKING" -> points += 35
            "WALKING" -> points += 30

            // Sitting exercises (medium intensity)
            "CYCLING" -> points += 35
            "ROWING" -> points += 35
            "SEATED_EXERCISES" -> points += 25

            // Lying exercises (low intensity)
            "YOGA" -> points += 25
            "STRETCHING" -> points += 20
            "MEDITATION" -> points += 15
        }
        
        return points
    }

    fun saveExercise(exercise: Exercise, onComplete: (Boolean, String?) -> Unit) {
        val userId = auth.currentUser?.uid ?: return onComplete(false, "User not authenticated")
        
        // Add the user ID to the exercise
        val exerciseWithUserId = exercise.copy(userId = userId)
        
        exercisesCollection
            .add(exerciseWithUserId)
            .addOnSuccessListener {
                updateDailySummary(exerciseWithUserId) { success, error ->
                    onComplete(success, error)
                }
            }
            .addOnFailureListener { e ->
                onComplete(false, e.message)
            }
    }

    private fun updateDailySummary(exercise: Exercise, onComplete: (Boolean, String?) -> Unit) {
        val userId = auth.currentUser?.uid ?: return onComplete(false, "User not authenticated")
        
        // Get the start of the day
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val startOfDay = Timestamp(calendar.time)
        
        // Get the end of the day
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        val endOfDay = Timestamp(calendar.time)

        // Query for today's summary
        dailySummariesCollection
            .whereEqualTo("userId", userId)
            .whereGreaterThanOrEqualTo("date", startOfDay)
            .whereLessThanOrEqualTo("date", endOfDay)
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    // Create new daily summary
                    val newSummary = DailyExerciseSummary(
                        userId = userId,
                        date = startOfDay,
                        totalCalories = exercise.calories,
                        exercises = listOf(exercise)
                    )
                    dailySummariesCollection
                        .add(newSummary)
                        .addOnSuccessListener { onComplete(true, null) }
                        .addOnFailureListener { e -> onComplete(false, e.message) }
                } else {
                    // Update existing summary
                    val doc = documents.documents[0]
                    val currentSummary = doc.toObject(DailyExerciseSummary::class.java)
                    val updatedExercises = currentSummary?.exercises?.plus(exercise) ?: listOf(exercise)
                    val updatedCalories = updatedExercises.sumOf { it.calories }
                    
                    doc.reference.update(
                        mapOf(
                            "totalCalories" to updatedCalories,
                            "exercises" to updatedExercises
                        )
                    )
                    .addOnSuccessListener { onComplete(true, null) }
                    .addOnFailureListener { e -> onComplete(false, e.message) }
                }
            }
            .addOnFailureListener { e ->
                onComplete(false, e.message)
            }
    }

    fun getWeeklySummary(onComplete: (List<DailyExerciseSummary>?, String?) -> Unit) {
        val userId = auth.currentUser?.uid ?: return onComplete(null, "User not authenticated")
        
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_YEAR, -7)
        val startDate = Timestamp(calendar.time)
        
        dailySummariesCollection
            .whereEqualTo("userId", userId)
            .whereGreaterThanOrEqualTo("date", startDate)
            .orderBy("date", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { documents ->
                val summaries = documents.toObjects(DailyExerciseSummary::class.java)
                onComplete(summaries, null)
            }
            .addOnFailureListener { e ->
                onComplete(null, e.message)
            }
    }

    fun getDailySummary(date: Date, onComplete: (DailyExerciseSummary?, String?) -> Unit) {
        val userId = auth.currentUser?.uid ?: return onComplete(null, "User not authenticated")
        
        val calendar = Calendar.getInstance()
        calendar.time = date
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val startOfDay = Timestamp(calendar.time)
        
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        val endOfDay = Timestamp(calendar.time)

        dailySummariesCollection
            .whereEqualTo("userId", userId)
            .whereGreaterThanOrEqualTo("date", startOfDay)
            .whereLessThanOrEqualTo("date", endOfDay)
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    onComplete(null, null)
                } else {
                    val summary = documents.documents[0].toObject(DailyExerciseSummary::class.java)
                    onComplete(summary, null)
                }
            }
            .addOnFailureListener { e ->
                onComplete(null, e.message)
            }
    }
} 