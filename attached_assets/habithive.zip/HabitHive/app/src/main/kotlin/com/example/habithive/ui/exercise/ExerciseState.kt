package com.example.habithive.ui.exercise

import com.example.habithive.data.model.Exercise
import com.example.habithive.data.model.ExerciseSession
import com.example.habithive.data.model.ExerciseStats

sealed class ExerciseState {
    object Loading : ExerciseState()
    data class Success(
        val exercises: List<Exercise>,
        val stats: ExerciseStats,
        val activeSession: ExerciseSession?
    ) : ExerciseState()
    data class Error(val message: String) : ExerciseState()
}

sealed class ExerciseTrackingState {
    object Idle : ExerciseTrackingState()
    object Starting : ExerciseTrackingState()
    data class Active(
        val session: ExerciseSession,
        val elapsedTime: Long,
        val pace: Double,
        val distance: Double,
        val calories: Int
    ) : ExerciseTrackingState()
    data class Paused(val session: ExerciseSession) : ExerciseTrackingState()
    data class Completed(val exercise: Exercise) : ExerciseTrackingState()
    data class Error(val message: String) : ExerciseTrackingState()
} 