package com.example.habithive.util

object LevelCalculator {
    private const val BASE_XP = 100
    private const val XP_MULTIPLIER = 1.5

    fun calculateLevel(xp: Int): Int {
        var level = 1
        var xpNeeded = BASE_XP
        var currentXp = xp

        while (currentXp >= xpNeeded) {
            currentXp -= xpNeeded
            level++
            xpNeeded = (xpNeeded * XP_MULTIPLIER).toInt()
        }

        return level
    }

    fun calculateXpForNextLevel(currentXp: Int): Int {
        val currentLevel = calculateLevel(currentXp)
        return (BASE_XP * Math.pow(XP_MULTIPLIER, (currentLevel - 1).toDouble())).toInt()
    }

    fun calculateProgressToNextLevel(currentXp: Int): Float {
        val currentLevel = calculateLevel(currentXp)
        val xpForCurrentLevel = if (currentLevel == 1) 0 else {
            (BASE_XP * Math.pow(XP_MULTIPLIER, (currentLevel - 2).toDouble())).toInt()
        }
        val xpForNextLevel = (BASE_XP * Math.pow(XP_MULTIPLIER, (currentLevel - 1).toDouble())).toInt()
        val xpInCurrentLevel = currentXp - xpForCurrentLevel
        val xpNeededForNextLevel = xpForNextLevel - xpForCurrentLevel

        return xpInCurrentLevel.toFloat() / xpNeededForNextLevel
    }
} 