package com.example.habithive.data.repository

import com.example.habithive.data.model.User
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepositoryImpl @Inject constructor(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore
) : UserRepository {

    override suspend fun getCurrentUser(): User? {
        val currentUser = auth.currentUser ?: return null
        val doc = firestore.collection(User.COLLECTION).document(currentUser.uid).get().await()
        return doc.toObject(User::class.java)
    }

    override suspend fun getCurrentUserId(): String? {
        return auth.currentUser?.uid
    }

    override suspend fun updateUser(user: User) {
        val currentUser = auth.currentUser ?: throw IllegalStateException("User not logged in")
        firestore.collection(User.COLLECTION).document(currentUser.uid).set(user).await()
    }

    override suspend fun getUserByEmail(email: String): User? {
        val snapshot = firestore.collection(User.COLLECTION)
            .whereEqualTo("email", email)
            .get()
            .await()
        
        return snapshot.documents.firstOrNull()?.toObject(User::class.java)?.copy(
            id = snapshot.documents.firstOrNull()?.id ?: ""
        )
    }

    override suspend fun signOut() {
        auth.signOut()
    }

    override suspend fun signInWithGoogle(account: GoogleSignInAccount): Result<User> {
        return try {
            val credential = GoogleAuthProvider.getCredential(account.idToken, null)
            val result = auth.signInWithCredential(credential).await()
            val user = result.user ?: throw IllegalStateException("Failed to sign in with Google")

            // Check if user exists in Firestore
            val userDoc = firestore.collection(User.COLLECTION).document(user.uid).get().await()
            val existingUser = userDoc.toObject(User::class.java)

            if (existingUser == null) {
                // Create new user
                val newUser = User(
                    id = user.uid,
                    name = account.displayName ?: "",
                    email = account.email ?: "",
                    photoUrl = account.photoUrl?.toString()
                )
                firestore.collection(User.COLLECTION).document(user.uid).set(newUser).await()
                Result.success(newUser)
            } else {
                Result.success(existingUser)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override fun getUserFlow(): Flow<User?> = callbackFlow {
        val currentUser = auth.currentUser ?: run {
            trySend(null)
            return@callbackFlow
        }

        val subscription = firestore.collection(User.COLLECTION)
            .document(currentUser.uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                trySend(snapshot?.toObject(User::class.java))
            }

        awaitClose { subscription.remove() }
    }

    override suspend fun resetPassword(email: String) {
        auth.sendPasswordResetEmail(email).await()
    }

    override suspend fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password).await()
    }
} 