package com.example.habithive.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.example.habithive.data.repository.GoalRepository
import com.example.habithive.notifications.GoalNotificationManager
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

@HiltWorker
class GoalReminderWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val goalRepository: GoalRepository,
    private val notificationManager: GoalNotificationManager
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val goalId = inputData.getString(KEY_GOAL_ID) ?: return Result.failure()
        
        return try {
            val goal = goalRepository.getGoal(goalId).first()
            if (goal != null) {
                notificationManager.showGoalReminder(goal)
                Result.success()
            } else {
                Result.failure()
            }
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val KEY_GOAL_ID = "goal_id"
        private const val WORK_NAME_PREFIX = "goal_reminder_"

        fun schedule(
            context: Context,
            goalId: String,
            reminderHour: Int,
            reminderMinute: Int
        ) {
            val workManager = WorkManager.getInstance(context)
            
            // Cancel any existing reminder for this goal
            workManager.cancelUniqueWork(WORK_NAME_PREFIX + goalId)

            // Create input data with goal ID
            val inputData = workDataOf(KEY_GOAL_ID to goalId)

            // Calculate initial delay
            val now = java.util.Calendar.getInstance()
            val scheduledTime = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, reminderHour)
                set(java.util.Calendar.MINUTE, reminderMinute)
                set(java.util.Calendar.SECOND, 0)
                if (before(now)) {
                    add(java.util.Calendar.DAY_OF_YEAR, 1)
                }
            }
            val initialDelay = scheduledTime.timeInMillis - now.timeInMillis

            // Create work request
            val workRequest = PeriodicWorkRequestBuilder<GoalReminderWorker>(
                24, TimeUnit.HOURS,
                15, TimeUnit.MINUTES
            )
                .setInputData(inputData)
                .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
                .build()

            // Enqueue unique work
            workManager.enqueueUniquePeriodicWork(
                WORK_NAME_PREFIX + goalId,
                ExistingPeriodicWorkPolicy.REPLACE,
                workRequest
            )
        }

        fun cancel(context: Context, goalId: String) {
            WorkManager.getInstance(context)
                .cancelUniqueWork(WORK_NAME_PREFIX + goalId)
        }
    }
} 