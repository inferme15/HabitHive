package com.example.habithive.ui.goals

import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.habithive.R
import com.example.habithive.data.model.Goal
import com.example.habithive.databinding.FragmentGoalsListPageBinding
import com.example.habithive.util.showPopupMenu
import com.example.habithive.util.viewBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class GoalsListPageFragment : Fragment(R.layout.fragment_goals_list_page) {

    private val binding by viewBinding(FragmentGoalsListPageBinding::bind)
    private val viewModel: GoalsViewModel by activityViewModels()
    private lateinit var goalAdapter: GoalAdapter
    private lateinit var goalStatus: GoalStatus

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        goalStatus = requireArguments().getSerializable(ARG_GOAL_STATUS) as GoalStatus
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observeState()
    }

    private fun setupRecyclerView() {
        goalAdapter = GoalAdapter(
            onItemClick = { goal ->
                navigateToGoalDetails(goal)
            },
            onMenuClick = { goal, anchor ->
                showGoalOptionsMenu(goal, anchor)
            }
        )

        binding.recyclerView.apply {
            adapter = goalAdapter
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
        }

        binding.swipeRefreshLayout.setOnRefreshListener {
            viewModel.refreshGoals()
        }
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.goalsState.collect { state ->
                    when (state) {
                        is GoalsState.Success -> {
                            binding.swipeRefreshLayout.isRefreshing = false
                            val filteredGoals = state.goals.filter { it.status == goalStatus }
                            updateUI(filteredGoals)
                        }
                        is GoalsState.Error -> {
                            binding.swipeRefreshLayout.isRefreshing = false
                            showError(state.message)
                        }
                        is GoalsState.Loading -> {
                            if (!binding.swipeRefreshLayout.isRefreshing) {
                                binding.swipeRefreshLayout.isRefreshing = true
                            }
                        }
                    }
                }
            }
        }
    }

    private fun updateUI(goals: List<Goal>) {
        binding.emptyStateGroup.isVisible = goals.isEmpty()
        goalAdapter.submitList(goals)
    }

    private fun showGoalOptionsMenu(goal: Goal, anchor: View) {
        val options = if (goal.status == GoalStatus.ACTIVE) {
            arrayOf(
                getString(R.string.edit),
                getString(R.string.mark_as_completed),
                getString(R.string.delete)
            )
        } else {
            arrayOf(
                getString(R.string.view_details),
                getString(R.string.delete)
            )
        }

        anchor.showPopupMenu(options) { position ->
            when {
                options[position] == getString(R.string.edit) -> {
                    navigateToEditGoal(goal)
                }
                options[position] == getString(R.string.mark_as_completed) -> {
                    viewModel.markGoalAsCompleted(goal.id)
                }
                options[position] == getString(R.string.view_details) -> {
                    navigateToGoalDetails(goal)
                }
                options[position] == getString(R.string.delete) -> {
                    showDeleteConfirmation(goal)
                }
            }
        }
    }

    private fun navigateToGoalDetails(goal: Goal) {
        findNavController().navigate(
            GoalsListFragmentDirections.actionGoalsListToGoalDetails(goal.id)
        )
    }

    private fun navigateToEditGoal(goal: Goal) {
        findNavController().navigate(
            GoalsListFragmentDirections.actionGoalsListToEditGoal(goal.id)
        )
    }

    private fun showDeleteConfirmation(goal: Goal) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.delete_goal)
            .setMessage(getString(R.string.delete_goal_confirmation_format, goal.title))
            .setPositiveButton(R.string.delete) { _, _ ->
                viewModel.deleteGoal(goal.id)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    companion object {
        private const val ARG_GOAL_STATUS = "goal_status"

        fun newInstance(status: GoalStatus): GoalsListPageFragment {
            return GoalsListPageFragment().apply {
                arguments = Bundle().apply {
                    putSerializable(ARG_GOAL_STATUS, status)
                }
            }
        }
    }
} 