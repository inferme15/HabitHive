package com.example.habithive.templates

import com.example.habithive.data.model.*
import com.example.habithive.data.repository.GoalTemplateRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoalTemplateManager @Inject constructor(
    private val templateRepository: GoalTemplateRepository
) {
    suspend fun createTemplate(goal: Goal, name: String, description: String? = null): GoalTemplate {
        val template = GoalTemplate(
            id = UUID.randomUUID().toString(),
            name = name,
            description = description,
            type = goal.type,
            targetValue = goal.targetValue,
            frequency = goal.frequency,
            duration = goal.duration,
            exerciseTypes = goal.exerciseTypes,
            reminderEnabled = goal.reminderEnabled,
            reminderTime = goal.reminderTime,
            userId = goal.userId,
            isPublic = false,
            createdAt = Date()
        )

        return templateRepository.saveTemplate(template)
    }

    fun getTemplates(
        userId: String,
        filter: TemplateFilter = TemplateFilter.ALL
    ): Flow<List<GoalTemplate>> {
        return when (filter) {
            TemplateFilter.ALL -> templateRepository.getUserTemplates(userId)
            TemplateFilter.PUBLIC -> templateRepository.getPublicTemplates()
            TemplateFilter.PRIVATE -> templateRepository.getPrivateTemplates(userId)
            TemplateFilter.POPULAR -> templateRepository.getPopularTemplates()
        }
    }

    suspend fun createGoalFromTemplate(
        template: GoalTemplate,
        userId: String,
        customizations: GoalCustomization? = null
    ): Goal {
        return Goal(
            id = UUID.randomUUID().toString(),
            title = customizations?.title ?: generateTitleFromTemplate(template),
            description = customizations?.description,
            type = template.type,
            targetValue = template.targetValue,
            frequency = template.frequency,
            duration = template.duration,
            exerciseTypes = template.exerciseTypes,
            reminderEnabled = template.reminderEnabled,
            reminderTime = template.reminderTime,
            userId = userId,
            status = GoalStatus.IN_PROGRESS,
            createdAt = Date()
        )
    }

    private fun generateTitleFromTemplate(template: GoalTemplate): String {
        // Implementation of generateTitleFromTemplate method
        // This method should return a generated title based on the template
        // For now, we'll use a placeholder implementation
        return "Generated Title"
    }
} 