package com.example.habithive.network

import kotlinx.serialization.Serializable

@Serializable
data class QuoteResponse(
    val content: String,
    val author: String
) 