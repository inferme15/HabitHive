package com.example.habithive.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
enum class GoalType : Parcelable {
    EXERCISE,
    MEDITATION,
    READING,
    WATER_INTAKE,
    SLEEP,
    CUSTOM
} 