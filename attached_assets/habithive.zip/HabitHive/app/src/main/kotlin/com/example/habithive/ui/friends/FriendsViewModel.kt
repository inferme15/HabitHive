package com.example.habithive.ui.friends

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.habithive.data.model.FriendRequest
import com.example.habithive.data.model.User
import com.example.habithive.data.repository.FriendRepository
import com.example.habithive.data.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

data class FriendsState(
    val friends: List<User> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

data class FriendRequestsState(
    val requests: List<FriendRequest> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

data class AddFriendState(
    val user: User? = null,
    val isLoading: Boolean = false,
    val error: String? = null,
    val isRequestSent: Boolean = false
)

@HiltViewModel
class FriendsViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val friendRepository: FriendRepository
) : ViewModel() {

    private val _searchResult = MutableLiveData<User?>()
    val searchResult: LiveData<User?> = _searchResult

    private val _friendsState = MutableStateFlow(FriendsState())
    val friendsState: StateFlow<FriendsState> = _friendsState

    private val _friendRequestsState = MutableStateFlow(FriendRequestsState())
    val friendRequestsState: StateFlow<FriendRequestsState> = _friendRequestsState

    private val _addFriendState = MutableStateFlow(AddFriendState())
    val addFriendState: StateFlow<AddFriendState> = _addFriendState

    init {
        loadFriends()
        loadFriendRequests()
    }

    private fun loadFriends() {
        viewModelScope.launch {
            try {
                _friendsState.update { it.copy(isLoading = true) }
                friendRepository.getFriends().collect { friendsList ->
                    _friendsState.update { 
                        it.copy(
                            friends = friendsList,
                            isLoading = false,
                            error = null
                        )
                    }
                }
            } catch (e: Exception) {
                _friendsState.update { 
                    it.copy(
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }

    fun refreshFriends() {
        loadFriends()
    }

    private fun loadFriendRequests() {
        viewModelScope.launch {
            try {
                _friendRequestsState.update { it.copy(isLoading = true) }
                val currentUserId = userRepository.getCurrentUserId() ?: return@launch
                val requests = friendRepository.getFriendRequests(currentUserId)
                _friendRequestsState.update {
                    it.copy(
                        requests = requests,
                        isLoading = false,
                        error = null
                    )
                }
            } catch (e: Exception) {
                _friendRequestsState.update {
                    it.copy(
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }

    fun refreshFriendRequests() {
        loadFriendRequests()
    }

    fun searchUserByEmail(email: String) {
        viewModelScope.launch {
            try {
                _addFriendState.update { it.copy(isLoading = true) }
                val user = userRepository.getUserByEmail(email)
                _addFriendState.update {
                    it.copy(
                        user = user,
                        isLoading = false,
                        error = null
                    )
                }
            } catch (e: Exception) {
                _addFriendState.update {
                    it.copy(
                        user = null,
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }

    fun sendFriendRequest() {
        viewModelScope.launch {
            try {
                _addFriendState.update { it.copy(isLoading = true) }
                val currentUser = userRepository.getCurrentUser() ?: throw IllegalStateException("User not logged in")
                val targetUser = _addFriendState.value.user ?: throw IllegalStateException("No user selected")
                
                friendRepository.sendFriendRequest(
                    senderId = currentUser.id,
                    receiverId = targetUser.id,
                    senderName = currentUser.name,
                    senderPhotoUrl = currentUser.photoUrl
                )

                _addFriendState.update {
                    it.copy(
                        isLoading = false,
                        isRequestSent = true,
                        error = null
                    )
                }
            } catch (e: Exception) {
                _addFriendState.update {
                    it.copy(
                        isLoading = false,
                        error = e.message
                    )
                }
            }
        }
    }

    fun acceptFriendRequest(requestId: String) {
        viewModelScope.launch {
            try {
                friendRepository.acceptFriendRequest(requestId)
                loadFriendRequests() // Refresh the list
                loadFriends() // Refresh friends list as well
            } catch (e: Exception) {
                _friendRequestsState.update {
                    it.copy(error = e.message)
                }
            }
        }
    }

    fun rejectFriendRequest(requestId: String) {
        viewModelScope.launch {
            try {
                friendRepository.rejectFriendRequest(requestId)
                loadFriendRequests() // Refresh the list
            } catch (e: Exception) {
                _friendRequestsState.update {
                    it.copy(error = e.message)
                }
            }
        }
    }

    fun removeFriend(friendId: String) {
        viewModelScope.launch {
            try {
                friendRepository.removeFriend(friendId)
                loadFriends() // Refresh the list
            } catch (e: Exception) {
                _friendsState.update {
                    it.copy(error = e.message)
                }
            }
        }
    }
} 