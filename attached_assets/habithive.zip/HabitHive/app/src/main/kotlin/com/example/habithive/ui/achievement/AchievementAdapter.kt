package com.example.habithive.ui.achievement

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.habithive.data.model.UserAchievement
import com.example.habithive.databinding.ItemAchievementBinding

class AchievementAdapter : ListAdapter<UserAchievement, AchievementAdapter.AchievementViewHolder>(AchievementDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AchievementViewHolder {
        val binding = ItemAchievementBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return AchievementViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AchievementViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class AchievementViewHolder(
        private val binding: ItemAchievementBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(userAchievement: UserAchievement) {
            val achievement = userAchievement.achievement ?: return
            
            binding.achievementName.text = achievement.title
            binding.achievementDescription.text = achievement.description
            binding.achievementPoints.text = "${userAchievement.progress}/${achievement.requirement}"
            
            // Set achievement icon using Glide or similar library
            // binding.achievementIcon.load(achievement.iconUrl)
            
            // Show/hide lock icon based on achievement status
            binding.lockIcon.visibility = if (userAchievement.isCompleted) {
                android.view.View.GONE
            } else {
                android.view.View.VISIBLE
            }
            
            // Set different background color for completed achievements
            binding.root.setCardBackgroundColor(
                if (userAchievement.isCompleted) {
                    android.graphics.Color.parseColor("#E8F5E9") // Light green
                } else {
                    android.graphics.Color.WHITE
                }
            )
        }
    }

    private class AchievementDiffCallback : DiffUtil.ItemCallback<UserAchievement>() {
        override fun areItemsTheSame(oldItem: UserAchievement, newItem: UserAchievement): Boolean {
            return oldItem.achievementId == newItem.achievementId && oldItem.userId == newItem.userId
        }

        override fun areContentsTheSame(oldItem: UserAchievement, newItem: UserAchievement): Boolean {
            return oldItem == newItem
        }
    }
} 