package com.example.habithive.service

import android.content.Context
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.example.habithive.data.model.Exercise
import com.example.habithive.data.model.Goal
import com.example.habithive.data.model.GoalStatus
import com.example.habithive.data.repository.GoalRepository
import com.example.habithive.notifications.GoalNotificationManager
import com.example.habithive.util.formatValue
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoalProgressTracker @Inject constructor(
    @ApplicationContext private val context: Context,
    private val goalRepository: GoalRepository,
    private val notificationManager: GoalNotificationManager,
    private val achievementManager: GoalAchievementManager
) {
    private val scope = ProcessLifecycleOwner.get().lifecycleScope

    init {
        startTracking()
    }

    private fun startTracking() {
        scope.launch {
            goalRepository.getActiveGoals()
                .collect { goals ->
                    goals.forEach { goal ->
                        updateGoalProgress(goal)
                    }
                }
        }
    }

    fun trackExercise(exercise: Exercise) {
        scope.launch {
            goalRepository.getActiveGoals()
                .first()
                .filter { goal ->
                    exercise.type in goal.exerciseTypes
                }
                .forEach { goal ->
                    val contribution = calculateContribution(exercise, goal)
                    updateGoalWithContribution(goal, contribution)
                }
        }
    }

    private fun calculateContribution(exercise: Exercise, goal: Goal): Double {
        return when (goal.type) {
            GoalType.DISTANCE -> exercise.distance
            GoalType.DURATION -> exercise.duration.toDouble()
            GoalType.CALORIES -> exercise.caloriesBurned.toDouble()
            GoalType.WORKOUTS -> 1.0
            GoalType.STREAK -> if (isStreak(exercise.timestamp, goal)) 1.0 else 0.0
        }
    }

    private suspend fun updateGoalWithContribution(goal: Goal, contribution: Double) {
        val updatedGoal = goal.copy(
            currentValue = goal.currentValue + contribution
        )
        
        goalRepository.updateGoal(updatedGoal)
        
        val progress = ((updatedGoal.currentValue / updatedGoal.targetValue) * 100).toInt()
        
        // Show progress notification at certain thresholds
        if (progress in progressNotificationThresholds) {
            notificationManager.showGoalProgress(updatedGoal, progress)
        }

        // Check for goal completion
        if (updatedGoal.currentValue >= updatedGoal.targetValue) {
            handleGoalCompletion(updatedGoal)
        }
    }

    private suspend fun handleGoalCompletion(goal: Goal) {
        val completedGoal = goal.copy(
            status = GoalStatus.COMPLETED,
            completedAt = Calendar.getInstance().time
        )
        goalRepository.updateGoal(completedGoal)
        
        // Trigger achievement celebration
        achievementManager.celebrateAchievement(completedGoal)
        
        // Create follow-up goal if it's a recurring goal
        if (goal.isRecurring) {
            createNextRecurringGoal(goal)
        }
    }

    private suspend fun createNextRecurringGoal(previousGoal: Goal) {
        val nextStartDate = Calendar.getInstance().apply {
            time = previousGoal.startDate
            add(Calendar.DAY_OF_YEAR, previousGoal.frequency.days)
        }.time

        val nextEndDate = Calendar.getInstance().apply {
            time = previousGoal.endDate
            add(Calendar.DAY_OF_YEAR, previousGoal.frequency.days)
        }.time

        val nextGoal = previousGoal.copy(
            id = UUID.randomUUID().toString(),
            startDate = nextStartDate,
            endDate = nextEndDate,
            currentValue = 0.0,
            status = GoalStatus.ACTIVE,
            completedAt = null
        )

        goalRepository.createGoal(nextGoal)
    }

    private fun isStreak(timestamp: Date, goal: Goal): Boolean {
        val calendar = Calendar.getInstance()
        calendar.time = timestamp
        
        val today = Calendar.getInstance()
        return calendar.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR) &&
                calendar.get(Calendar.YEAR) == today.get(Calendar.YEAR)
    }

    companion object {
        private val progressNotificationThresholds = setOf(25, 50, 75, 90)
    }
} 