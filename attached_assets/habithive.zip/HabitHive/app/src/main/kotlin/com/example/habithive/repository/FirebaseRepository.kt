package com.example.habithive.repository

import com.example.habithive.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class FirebaseRepository @Inject constructor(
    private val auth: FirebaseAuth,
    private val db: FirebaseFirestore
) {
    private val usersCollection = db.collection("users")

    suspend fun createUser(email: String, password: String): Result<User> {
        return try {
            val authResult = auth.createUserWithEmailAndPassword(email, password).await()
            val user = User(
                id = authResult.user?.uid ?: "",
                email = email,
                username = email.substringBefore("@")
            )
            usersCollection.document(user.id ?: "").set(user).await()
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getCurrentUser(): Result<User> {
        return try {
            val uid = auth.currentUser?.uid ?: throw Exception("User not logged in")
            val document = usersCollection.document(uid).get().await()
            val user = document.toObject(User::class.java) 
                ?: throw Exception("User data not found")
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateStepCount(steps: Int): Result<Unit> {
        return try {
            val uid = auth.currentUser?.uid ?: throw Exception("User not logged in")
            usersCollection.document(uid).update("stepCount", steps).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateDailyGoal(goal: Int): Result<Unit> {
        return try {
            val uid = auth.currentUser?.uid ?: throw Exception("User not logged in")
            usersCollection.document(uid).update("dailyGoal", goal).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createUserInFirestore(userId: String, email: String, name: String) {
        try {
            val user = hashMapOf(
                "id" to userId,
                "email" to email,
                "name" to name,
                "photoUrl" to (auth.currentUser?.photoUrl?.toString() ?: ""),
                "username" to "",
                "profileImageUrl" to "",
                "level" to 1,
                "totalPoints" to 0
            )
            
            db.collection("users").document(userId).set(user).await()
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun updateUserPhotoUrl(userId: String, photoUrl: String?) {
        try {
            db.collection("users").document(userId)
                .update("photoUrl", photoUrl ?: "")
                .await()
        } catch (e: Exception) {
            throw e
        }
    }
} 