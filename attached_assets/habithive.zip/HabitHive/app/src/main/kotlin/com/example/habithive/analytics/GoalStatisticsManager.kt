package com.example.habithive.analytics

import com.example.habithive.data.model.*
import com.example.habithive.data.repository.GoalRepository
import com.example.habithive.util.DateRange
import com.example.habithive.util.TimeUnit
import kotlinx.coroutines.flow.*
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manages and calculates statistics for user goals.
 * Provides various metrics and analytics about goal completion, progress, and trends.
 */
@Singleton
class GoalStatisticsManager @Inject constructor(
    private val goalRepository: GoalRepository
) {
    /**
     * Retrieves comprehensive statistics for a user's goals within a specified time range.
     * @param userId The ID of the user to get statistics for
     * @param timeRange The date range to analyze goals within
     * @return [GoalStatistics] containing various metrics and analytics
     */
    suspend fun getGoalStatistics(userId: String, timeRange: DateRange): GoalStatistics {
        val goals = goalRepository.getUserGoals(userId)
            .first()
            .filter { goal -> 
                goal.startDate >= timeRange.start.time &&
                goal.startDate <= timeRange.end.time
            }

        return GoalStatistics(
            totalGoals = goals.size,
            completedGoals = goals.count { it.status == GoalStatus.COMPLETED },
            activeGoals = goals.count { it.status == GoalStatus.ACTIVE },
            completionRate = calculateCompletionRate(goals),
            averageCompletion = calculateAverageCompletion(goals),
            goalsByType = calculateGoalsByType(goals),
            progressOverTime = calculateProgressOverTime(goals, timeRange),
            streaks = calculateStreaks(goals),
            mostPopularTypes = findMostPopularTypes(goals),
            failedGoals = goals.count { it.status == GoalStatus.FAILED },
            archivedGoals = goals.count { it.status == GoalStatus.ARCHIVED },
            averageGoalDuration = calculateAverageGoalDuration(goals),
            bestPerformingType = findBestPerformingType(goals),
            worstPerformingType = findWorstPerformingType(goals),
            weeklyProgress = calculateWeeklyProgress(goals),
            monthlyProgress = calculateMonthlyProgress(goals)
        )
    }

    /**
     * Calculates the percentage of completed goals.
     * @param goals List of goals to analyze
     * @return Percentage of completed goals (0-100)
     */
    private fun calculateCompletionRate(goals: List<Goal>): Double {
        if (goals.isEmpty()) return 0.0
        val completedGoals = goals.count { it.status == GoalStatus.COMPLETED }
        return (completedGoals.toDouble() / goals.size) * 100
    }

    /**
     * Calculates the average completion percentage for each goal type.
     * @param goals List of goals to analyze
     * @return Map of goal types to their average completion percentage
     */
    private fun calculateAverageCompletion(goals: List<Goal>): Map<GoalType, Double> {
        return goals
            .groupBy { it.type }
            .mapValues { (_, typeGoals) ->
                typeGoals.map { goal ->
                    (goal.currentValue.toDouble() / goal.targetValue.toDouble()) * 100
                }.average()
            }
    }

    /**
     * Calculates detailed statistics for each goal type.
     * @param goals List of goals to analyze
     * @return Map of goal types to their detailed statistics
     */
    private fun calculateGoalsByType(goals: List<Goal>): Map<GoalType, TypeStatistics> {
        return goals
            .groupBy { it.type }
            .mapValues { (_, typeGoals) ->
                TypeStatistics(
                    total = typeGoals.size,
                    completed = typeGoals.count { it.status == GoalStatus.COMPLETED },
                    totalValue = typeGoals.sumOf { it.currentValue.toDouble() },
                    averageValue = typeGoals.map { it.currentValue.toDouble() }.average(),
                    failureRate = calculateFailureRate(typeGoals),
                    averageDuration = calculateAverageGoalDuration(typeGoals),
                    bestStreak = calculateBestStreak(typeGoals),
                    totalPoints = calculateTotalPoints(typeGoals)
                )
            }
    }

    /**
     * Calculates goal progress over time within a date range.
     * @param goals List of goals to analyze
     * @param timeRange The date range to analyze progress within
     * @return List of progress points showing daily progress
     */
    private fun calculateProgressOverTime(
        goals: List<Goal>,
        timeRange: DateRange
    ): List<ProgressPoint> {
        val calendar = Calendar.getInstance().apply {
            time = Date(timeRange.start.time)
        }
        val endMillis = timeRange.end.time
        val progressPoints = mutableListOf<ProgressPoint>()

        while (calendar.timeInMillis <= endMillis) {
            val currentTime = calendar.timeInMillis
            val activeGoals = goals.filter { goal ->
                currentTime >= goal.startDate && currentTime <= goal.endDate
            }

            val averageProgress = if (activeGoals.isNotEmpty()) {
                activeGoals.map { goal ->
                    (goal.currentValue.toDouble() / goal.targetValue.toDouble()) * 100
                }.average()
            } else 0.0

            progressPoints.add(
                ProgressPoint(
                    timestamp = currentTime,
                    progress = averageProgress,
                    activeGoals = activeGoals.size,
                    completedGoals = activeGoals.count { it.status == GoalStatus.COMPLETED },
                    failedGoals = activeGoals.count { it.status == GoalStatus.FAILED },
                    totalPoints = calculateTotalPoints(activeGoals)
                )
            )

            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }

        return progressPoints
    }

    private data class StreakInfo(
        var currentStreak: Int = 0,
        var longestStreak: Int = 0,
        var streakStartDate: Long = 0,
        var streakEndDate: Long = 0,
        var lastCompletionDate: Long = 0,
        val streakHistory: MutableList<Streak> = mutableListOf()
    )

    /**
     * Calculates streak statistics for completed goals.
     * @param goals List of goals to analyze
     * @return Statistics about current and longest streaks
     */
    private fun calculateStreaks(goals: List<Goal>): StreakStatistics {
        val completedGoals = goals
            .filter { it.status == GoalStatus.COMPLETED && it.completedAt != null }
            .sortedBy { it.completedAt }

        val streakInfo = StreakInfo()
        var isFirstGoal = true

        completedGoals.forEach { goal ->
            goal.completedAt?.let { completionDate ->
                if (isFirstGoal) {
                    streakInfo.currentStreak = 1
                    streakInfo.streakStartDate = completionDate
                    streakInfo.lastCompletionDate = completionDate
                    isFirstGoal = false
                } else {
                    val daysDifference = getDaysDifference(streakInfo.lastCompletionDate, completionDate)
                    if (daysDifference == 1) {
                        streakInfo.currentStreak++
                    } else {
                        // Save the previous streak
                        if (streakInfo.currentStreak > 1) {
                            streakInfo.streakHistory.add(
                                Streak(
                                    startDate = streakInfo.streakStartDate,
                                    endDate = streakInfo.lastCompletionDate,
                                    length = streakInfo.currentStreak,
                                    goalsCompleted = streakInfo.currentStreak
                                )
                            )
                        }
                        streakInfo.currentStreak = 1
                        streakInfo.streakStartDate = completionDate
                    }
                }

                if (streakInfo.currentStreak > streakInfo.longestStreak) {
                    streakInfo.longestStreak = streakInfo.currentStreak
                }

                streakInfo.streakEndDate = completionDate
                streakInfo.lastCompletionDate = completionDate
            }
        }

        // Add the final streak if it exists
        if (streakInfo.currentStreak > 1) {
            streakInfo.streakHistory.add(
                Streak(
                    startDate = streakInfo.streakStartDate,
                    endDate = streakInfo.streakEndDate,
                    length = streakInfo.currentStreak,
                    goalsCompleted = streakInfo.currentStreak
                )
            )
        }

        val (bestDay, worstDay) = calculateBestAndWorstDays(completedGoals)

        return StreakStatistics(
            currentStreak = streakInfo.currentStreak,
            longestStreak = streakInfo.longestStreak,
            totalDays = completedGoals.mapNotNull { it.completedAt }.distinct().size,
            averageStreak = if (streakInfo.streakHistory.isEmpty()) 0.0 
                          else streakInfo.streakHistory.map { it.length }.average(),
            streakHistory = streakInfo.streakHistory,
            bestDayOfWeek = bestDay,
            worstDayOfWeek = worstDay
        )
    }

    /**
     * Finds the most popular exercise types and their success rates.
     * @param goals List of goals to analyze
     * @return List of popular exercise types sorted by frequency
     */
    private fun findMostPopularTypes(goals: List<Goal>): List<PopularType> {
        return goals
            .filter { it.type == GoalType.EXERCISE }
            .flatMap { it.exerciseTypes }
            .groupBy { it }
            .map { (type, occurrences) ->
                val typeGoals = goals.filter { type in it.exerciseTypes }
                PopularType(
                    type = type,
                    count = occurrences.size,
                    successRate = calculateSuccessRate(typeGoals),
                    averageProgress = calculateAverageProgress(typeGoals),
                    totalDuration = calculateTotalDuration(typeGoals),
                    pointsEarned = calculateTotalPoints(typeGoals)
                )
            }
            .sortedByDescending { it.count }
    }

    /**
     * Calculates the success rate for a specific exercise type.
     * @param goals List of goals to analyze
     * @return Percentage of successful completions (0-100)
     */
    private fun calculateSuccessRate(goals: List<Goal>): Double {
        if (goals.isEmpty()) return 0.0
        return goals.count { it.status == GoalStatus.COMPLETED }.toDouble() / goals.size * 100
    }

    private fun calculateAverageProgress(goals: List<Goal>): Double {
        if (goals.isEmpty()) return 0.0
        return goals.map { (it.currentValue.toDouble() / it.targetValue.toDouble()) * 100 }.average()
    }

    private fun calculateTotalDuration(goals: List<Goal>): Long {
        return goals.sumOf { it.endDate - it.startDate }
    }

    private fun calculateTotalPoints(goals: List<Goal>): Int {
        // Implement your points calculation logic here
        return 0
    }

    private fun calculateFailureRate(goals: List<Goal>): Double {
        if (goals.isEmpty()) return 0.0
        return goals.count { it.status == GoalStatus.FAILED }.toDouble() / goals.size * 100
    }

    private fun calculateAverageGoalDuration(goals: List<Goal>): Long {
        if (goals.isEmpty()) return 0
        return goals.map { it.endDate - it.startDate }.average().toLong()
    }

    private fun calculateBestStreak(goals: List<Goal>): Int {
        return calculateStreaks(goals).longestStreak
    }

    private fun calculateBestAndWorstDays(goals: List<Goal>): Pair<Int, Int> {
        if (goals.isEmpty()) return Pair(1, 1)
        
        val completionsByDay = goals
            .mapNotNull { it.completedAt }
            .groupBy { getDayOfWeek(it) }
            .mapValues { it.value.size }

        val bestDay = completionsByDay.maxByOrNull { it.value }?.key ?: 1
        val worstDay = completionsByDay.minByOrNull { it.value }?.key ?: 1

        return Pair(bestDay, worstDay)
    }

    private fun getDayOfWeek(timestamp: Long): Int {
        val calendar = Calendar.getInstance().apply {
            timeInMillis = timestamp
        }
        return calendar.get(Calendar.DAY_OF_WEEK)
    }

    /**
     * Calculates the number of days between two timestamps.
     * @param date1 First timestamp
     * @param date2 Second timestamp
     * @return Number of days between the timestamps
     */
    private fun getDaysDifference(date1: Long, date2: Long): Int {
        val diff = date2 - date1
        return (diff / (24 * 60 * 60 * 1000)).toInt()
    }

    private fun findBestPerformingType(goals: List<Goal>): GoalType? {
        if (goals.isEmpty()) return null
        return calculateAverageCompletion(goals)
            .maxByOrNull { it.value }
            ?.key
    }

    private fun findWorstPerformingType(goals: List<Goal>): GoalType? {
        if (goals.isEmpty()) return null
        return calculateAverageCompletion(goals)
            .minByOrNull { it.value }
            ?.key
    }

    private fun calculateWeeklyProgress(goals: List<Goal>): WeeklyProgress? {
        // Implement weekly progress calculation
        return null
    }

    private fun calculateMonthlyProgress(goals: List<Goal>): MonthlyProgress? {
        // Implement monthly progress calculation
        return null
    }
} 