package com.example.habithive.data.repository

import com.example.habithive.data.model.Exercise
import com.example.habithive.data.model.ExerciseSession
import com.example.habithive.data.model.DailyExerciseSummary
import com.example.habithive.data.model.ExerciseType
import kotlinx.coroutines.flow.Flow
import kotlinx.datetime.LocalDate

interface ExerciseRepository {
    suspend fun saveExercise(exercise: Exercise)
    suspend fun getExercises(): Flow<List<Exercise>>
    suspend fun deleteExercise(exerciseId: String)
    suspend fun getDailySummary(date: LocalDate): DailyExerciseSummary?
    suspend fun getWeeklySummary(): List<DailyExerciseSummary>
    suspend fun updateExercise(exercise: Exercise)
    suspend fun startExercise(type: ExerciseType): ExerciseSession
    suspend fun updateExerciseSession(session: ExerciseSession)
    suspend fun endExercise(sessionId: String): Exercise
    suspend fun getAllExercises(userId: String): List<Exercise>
    suspend fun getExercise(exerciseId: String): Exercise?
    fun getActiveSession(): Flow<ExerciseSession?>
    suspend fun getExerciseStats(userId: String): ExerciseStats
    suspend fun getUserCurrentStreak(userId: String): Int
    suspend fun getUserTotalExerciseDuration(userId: String): Long
    suspend fun getUserTotalCaloriesBurned(userId: String): Int
}

data class ExerciseStats(
    val totalExercises: Int = 0,
    val totalDuration: Long = 0,
    val totalCaloriesBurned: Int = 0,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val favoriteType: ExerciseType? = null,
    val weeklyProgress: Map<Int, Long> = emptyMap() // Day of week -> Duration in minutes
) 