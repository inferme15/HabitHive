package com.example.habithive.ui.goals

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.habithive.R
import com.example.habithive.databinding.FragmentUserGoalBinding
import com.example.habithive.model.UserGoal
import com.google.android.material.tabs.TabLayout
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.Date

@AndroidEntryPoint
class UserGoalFragment : Fragment() {

    private var _binding: FragmentUserGoalBinding? = null
    private val binding get() = _binding!!
    private val viewModel: UserGoalViewModel by viewModels()
    private lateinit var adapter: UserGoalAdapter
    private var currentTab = 0 // 0 for active, 1 for all goals

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUserGoalBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupTabLayout()
        setupSpinner()
        setupCreateGoalButton()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = UserGoalAdapter(
            onProgressUpdate = { goalId, newValue ->
                viewModel.updateGoalProgress(goalId, newValue)
            },
            onDelete = { goalId ->
                viewModel.deleteGoal(goalId)
            }
        )
        binding.recyclerViewGoals.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@UserGoalFragment.adapter
        }
    }

    private fun setupTabLayout() {
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Active Goals"))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("All Goals"))

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                currentTab = tab?.position ?: 0
                when (currentTab) {
                    0 -> {
                        binding.spinnerFrequency.visibility = View.GONE
                        viewModel.loadActiveGoals()
                    }
                    1 -> {
                        binding.spinnerFrequency.visibility = View.VISIBLE
                        val frequency = if (binding.spinnerFrequency.selectedItemPosition == 0) null
                        else binding.spinnerFrequency.selectedItem.toString()
                        viewModel.loadGoals(frequency)
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupSpinner() {
        val frequencies = arrayOf("All", "DAILY", "WEEKLY", "MONTHLY")
        val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, frequencies)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        
        binding.spinnerFrequency.adapter = spinnerAdapter
        binding.spinnerFrequency.visibility = View.GONE // Initially hidden as we start with active goals
        
        binding.spinnerFrequency.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (currentTab == 1) { // Only load if we're on the "All Goals" tab
                    val selected = if (position == 0) null else frequencies[position]
                    viewModel.loadGoals(selected)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupCreateGoalButton() {
        binding.fabAddGoal.setOnClickListener {
            showCreateGoalDialog()
        }
    }

    private fun showCreateGoalDialog() {
        CreateGoalDialogFragment { goal ->
            viewModel.createGoal(goal)
        }.show(childFragmentManager, "CreateGoalDialog")
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.goals.collect { goals ->
                        if (currentTab == 1) {
                            adapter.submitList(goals)
                            updateEmptyState(goals)
                        }
                    }
                }

                launch {
                    viewModel.activeGoals.collect { goals ->
                        if (currentTab == 0) {
                            adapter.submitList(goals)
                            updateEmptyState(goals)
                        }
                    }
                }

                launch {
                    viewModel.loading.collect { isLoading ->
                        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
                    }
                }

                launch {
                    viewModel.error.collect { error ->
                        error?.let {
                            Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }
    }

    private fun updateEmptyState(goals: List<UserGoal>) {
        binding.textViewEmpty.text = when (currentTab) {
            0 -> getString(R.string.no_active_goals)
            else -> getString(R.string.no_goals_found)
        }
        
        if (goals.isEmpty()) {
            binding.textViewEmpty.visibility = View.VISIBLE
            binding.recyclerViewGoals.visibility = View.GONE
        } else {
            binding.textViewEmpty.visibility = View.GONE
            binding.recyclerViewGoals.visibility = View.VISIBLE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 