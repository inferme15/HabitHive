package com.example.habithive.ui.community

import com.example.habithive.data.model.Post
import com.example.habithive.data.model.Comment

sealed class CommunityState {
    object Loading : CommunityState()
    data class Success(
        val posts: List<Post>,
        val trendingPosts: List<Post>,
        val userPosts: List<Post>
    ) : CommunityState()
    data class Error(val message: String) : CommunityState()
}

sealed class PostState {
    object Loading : PostState()
    data class Success(
        val post: Post,
        val comments: List<Comment>,
        val likes: Int,
        val isLiked: Boolean
    ) : PostState()
    data class Error(val message: String) : PostState()
}

sealed class PostCreationState {
    object Idle : PostCreationState()
    object Loading : PostCreationState()
    object Success : PostCreationState()
    data class Error(val message: String) : PostCreationState()
} 