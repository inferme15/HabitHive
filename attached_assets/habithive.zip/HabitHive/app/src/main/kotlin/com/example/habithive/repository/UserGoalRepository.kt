package com.example.habithive.repository

import com.example.habithive.model.UserGoal
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserGoalRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) {
    private val goalsCollection = firestore.collection("user_goals")

    suspend fun createGoal(goal: UserGoal): String {
        val goalWithUserId = goal.copy(userId = auth.currentUser?.uid ?: throw Exception("User not authenticated"))
        val docRef = goalsCollection.add(goalWithUserId).await()
        return docRef.id
    }

    suspend fun updateGoal(goal: UserGoal) {
        goalsCollection.document(goal.id).set(goal).await()
    }

    suspend fun deleteGoal(goalId: String) {
        goalsCollection.document(goalId).delete().await()
    }

    suspend fun getGoal(goalId: String): UserGoal {
        return goalsCollection.document(goalId)
            .get()
            .await()
            .toObject(UserGoal::class.java) ?: throw Exception("Goal not found")
    }

    fun getUserGoals(frequency: String? = null): Flow<List<UserGoal>> = flow {
        val userId = auth.currentUser?.uid ?: throw Exception("User not authenticated")
        var query: Query = goalsCollection.whereEqualTo("userId", userId)
        
        if (frequency != null) {
            query = query.whereEqualTo("frequency", frequency)
        }
        
        query = query.orderBy("startDate", Query.Direction.DESCENDING)
        
        val snapshot = query.get().await()
        val goals = snapshot.documents.mapNotNull { doc ->
            doc.toObject(UserGoal::class.java)
        }
        emit(goals)
    }

    fun getActiveGoals(): Flow<List<UserGoal>> = flow {
        val userId = auth.currentUser?.uid ?: throw Exception("User not authenticated")
        val currentDate = java.util.Date()
        
        val snapshot = goalsCollection
            .whereEqualTo("userId", userId)
            .whereEqualTo("completed", false)
            .whereLessThanOrEqualTo("startDate", currentDate)
            .whereGreaterThanOrEqualTo("endDate", currentDate)
            .get()
            .await()
            
        val goals = snapshot.documents.mapNotNull { doc ->
            doc.toObject(UserGoal::class.java)
        }
        emit(goals)
    }

    suspend fun updateGoalProgress(goalId: String, currentValue: Double) {
        val goal = getGoal(goalId)
        val completed = currentValue >= goal.targetValue
        val updatedGoal = goal.copy(
            currentValue = currentValue,
            completed = completed
        )
        updateGoal(updatedGoal)
    }
} 