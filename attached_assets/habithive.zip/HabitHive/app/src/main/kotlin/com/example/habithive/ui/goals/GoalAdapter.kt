package com.example.habithive.ui.goals

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.habithive.data.model.ExerciseType
import com.example.habithive.data.model.Goal
import com.example.habithive.databinding.ItemGoalBinding
import com.example.habithive.util.*
import com.google.android.material.chip.Chip

class GoalAdapter(
    private val onItemClick: (Goal) -> Unit,
    private val onMenuClick: (Goal, android.view.View) -> Unit
) : ListAdapter<Goal, GoalAdapter.ViewHolder>(GoalDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemGoalBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: ItemGoalBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onItemClick(getItem(position))
                }
            }

            binding.menuButton.setOnClickListener { view ->
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onMenuClick(getItem(position), view)
                }
            }
        }

        fun bind(goal: Goal) {
            with(binding) {
                goalTitleText.text = goal.title
                goalDescriptionText.text = goal.description
            }
        }
    }
} 