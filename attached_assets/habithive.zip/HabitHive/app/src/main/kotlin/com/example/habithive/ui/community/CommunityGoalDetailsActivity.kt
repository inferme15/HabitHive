package com.example.habithive.ui.community

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.habithive.databinding.ActivityCommunityGoalDetailsBinding
import com.example.habithive.model.CommunityGoal
import com.example.habithive.model.Comment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import java.util.Date
import androidx.activity.OnBackPressedCallback

class CommunityGoalDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCommunityGoalDetailsBinding
    private val viewModel: CommunityGoalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCommunityGoalDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupViews()
        observeViewModel()
        loadGoal()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finish()
            }
        })
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { onBackPressed() }
    }

    private fun setupViews() {
        // Implementation of setupViews method
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.selectedGoal.collectLatest { goal ->
                goal?.let { updateUI(it) }
            }
        }

        lifecycleScope.launch {
            viewModel.error.collectLatest { error ->
                error?.let {
                    Toast.makeText(this@CommunityGoalDetailsActivity, it, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun setupClickListeners() {
        binding.joinButton.setOnClickListener {
            val goal = viewModel.selectedGoal.value
            goal?.let {
                val userId = "current_user_id" // Replace with actual user ID
                viewModel.joinGoal(it.id, userId)
            }
        }

        binding.supportButton.setOnClickListener {
            val goal = viewModel.selectedGoal.value
            goal?.let {
                val userId = "current_user_id" // Replace with actual user ID
                viewModel.supportGoal(it.id, userId)
            }
        }

        binding.addCommentButton.setOnClickListener {
            showAddCommentDialog()
        }
    }

    private fun showAddCommentDialog() {
        val textInputLayout = TextInputLayout(this).apply {
            hint = "Comment"
            addView(TextInputEditText(context))
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Add Comment")
            .setView(textInputLayout)
            .setPositiveButton("Add") { _, _ ->
                val input = textInputLayout.editText
                input?.text?.toString()?.let { commentText ->
                    val goal = viewModel.selectedGoal.value
                    goal?.let {
                        val userId = "current_user_id" // Replace with actual user ID
                        val comment = Comment(
                            userId = userId,
                            text = commentText,
                            timestamp = Date()
                        )
                        viewModel.addComment(it.id, comment)
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateUI(goal: CommunityGoal) {
        binding.apply {
            titleText.text = goal.title
            descriptionText.text = goal.description
            progressText.text = "${goal.currentValue}/${goal.targetValue}"
            progressIndicator.progress = (goal.currentValue.toFloat() / goal.targetValue * 100).toInt()
            participantsText.text = "${goal.participants.size} participants"
            supportersText.text = "${goal.supporters.size} supporters"
            statusText.text = goal.status.name

            joinButton.text = if (goal.participants.contains("current_user_id")) "Leave" else "Join"
            supportButton.text = if (goal.supporters.contains("current_user_id")) "Unsupport" else "Support"

            // TODO: Update comments RecyclerView
        }
    }

    private fun loadGoal() {
        val goalId = intent.getStringExtra("goal_id")
        goalId?.let { id ->
            viewModel.loadGoalById(id)
        }
    }
} 