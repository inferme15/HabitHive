package com.example.habithive.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
enum class GoalStatus : Parcelable {
    ACTIVE,
    COMPLETED,
    CANCELLED
} 