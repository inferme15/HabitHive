package com.example.habithive.data.repository

import com.example.habithive.data.model.LeaderboardEntry
import com.example.habithive.data.model.LeaderboardStats
import com.example.habithive.data.model.LeaderboardType
import kotlinx.coroutines.flow.Flow

interface LeaderboardRepository {
    suspend fun getLeaderboard(type: LeaderboardType): LeaderboardStats
    suspend fun getUserRank(userId: String, type: LeaderboardType): Int
    suspend fun updateUserScore(userId: String)
    fun getLeaderboardFlow(type: LeaderboardType): Flow<LeaderboardStats>
    suspend fun getTopPerformers(type: LeaderboardType, limit: Int = 10): List<LeaderboardEntry>
    suspend fun getNearbyUsers(userId: String, type: LeaderboardType): List<LeaderboardEntry>
} 