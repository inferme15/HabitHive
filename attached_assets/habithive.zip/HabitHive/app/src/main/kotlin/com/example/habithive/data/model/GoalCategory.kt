package com.example.habithive.data.model

import kotlinx.serialization.Serializable

@Serializable
data class GoalCategory(
    val id: String = "",
    val name: String = "",
    val description: String = "",
    val icon: String = "",
    val color: String = "",
    val parentCategoryId: String? = null,
    val order: Int = 0,
    val tags: List<GoalTag> = emptyList()
)

@Serializable
data class GoalTag(
    val id: String = "",
    val name: String = "",
    val color: Int = 0,
    val usageCount: Int = 0,
    val categoryId: String = ""
)

@Serializable
data class CategoryWithGoals(
    val category: GoalCategory,
    val goals: List<Goal> = emptyList(),
    val subcategories: List<CategoryWithGoals> = emptyList()
) 