package com.example.habithive.data.model

import kotlinx.serialization.Serializable

@Serializable
data class LeaderboardEntry(
    val userId: String = "",
    val userName: String = "",
    val userPhotoUrl: String? = null,
    val score: Int = 0,
    val rank: Int = 0,
    val achievementPoints: Int = 0,
    val exerciseMinutes: Int = 0,
    val goalsCompleted: Int = 0,
    val currentStreak: Int = 0
)

@Serializable
enum class LeaderboardType {
    GLOBAL,
    FRIENDS,
    WEEKLY,
    MONTHLY
}

@Serializable
data class LeaderboardStats(
    val totalParticipants: Int = 0,
    val userRank: Int = 0,
    val topPerformers: List<LeaderboardEntry> = emptyList(),
    val nearbyUsers: List<LeaderboardEntry> = emptyList()
) 