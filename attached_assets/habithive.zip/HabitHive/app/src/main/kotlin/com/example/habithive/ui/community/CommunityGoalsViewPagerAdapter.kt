package com.example.habithive.ui.community

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.habithive.model.CommunityGoal

class CommunityGoalsViewPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
    private val myGoalsFragment = CommunityGoalsFragment.newInstance()
    private val participatingFragment = CommunityGoalsFragment.newInstance()

    override fun getItemCount(): Int = 2

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> myGoalsFragment
            1 -> participatingFragment
            else -> throw IllegalArgumentException("Invalid position: $position")
        }
    }

    fun updateMyGoals(goals: List<CommunityGoal>) {
        (myGoalsFragment as? CommunityGoalsFragment)?.let { fragment ->
            fragment.updateGoals(goals)
        }
    }

    fun updateParticipatingGoals(goals: List<CommunityGoal>) {
        (participatingFragment as? CommunityGoalsFragment)?.let { fragment ->
            fragment.updateGoals(goals)
        }
    }
} 