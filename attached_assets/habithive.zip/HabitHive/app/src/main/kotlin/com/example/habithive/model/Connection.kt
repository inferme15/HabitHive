package com.example.habithive.model

data class Connection(
    val id: String = "",
    val userId: String = "",
    val friendId: String = "",
    val friendName: String = "",
    val friendEmail: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    // Empty constructor for Firestore
    constructor() : this("", "", "", "", "")
} 