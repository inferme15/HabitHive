package com.example.habithive.util.transitions

import android.view.View
import androidx.fragment.app.Fragment
import androidx.transition.*
import com.google.android.material.transition.MaterialArcMotion
import com.google.android.material.transition.MaterialContainerTransform
import com.google.android.material.transition.MaterialElevationScale
import com.google.android.material.transition.MaterialFadeThrough

object TransitionManager {

    fun Fragment.setupTransitions() {
        enterTransition = MaterialFadeThrough()
        exitTransition = MaterialFadeThrough()
        reenterTransition = MaterialFadeThrough()
    }

    fun Fragment.setupSharedElementTransition(
        startView: View,
        endView: View,
        duration: Long = 300L
    ) {
        sharedElementEnterTransition = MaterialContainerTransform().apply {
            this.duration = duration
            setPathMotion(MaterialArcMotion())
            scrimColor = android.R.color.transparent
            fadeMode = MaterialContainerTransform.FADE_MODE_THROUGH
            startView.transitionName = "shared_element_container"
            endView.transitionName = "shared_element_container"
        }
    }

    fun Fragment.setupElevationTransition() {
        exitTransition = MaterialElevationScale(false)
        reenterTransition = MaterialElevationScale(true)
    }

    fun Fragment.setupCustomTransition(
        enter: Boolean,
        duration: Long = 300L
    ) {
        val transition = TransitionSet().apply {
            addTransition(ChangeBounds())
            addTransition(ChangeTransform())
            addTransition(ChangeImageTransform())
            this.duration = duration
        }

        if (enter) {
            enterTransition = transition
        } else {
            exitTransition = transition
        }
    }
} 