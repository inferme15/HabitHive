package com.example.habithive.data.repository

import com.example.habithive.data.model.Post
import com.example.habithive.data.model.Comment
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton

@Singleton
class CommunityRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val userRepository: UserRepository,
    @Named("posts") private val postsCollection: CollectionReference,
    @Named("comments") private val commentsCollection: CollectionReference,
    @Named("likes") private val likesCollection: CollectionReference
) : CommunityRepository {

    override suspend fun createPost(post: Post): String {
        val postRef = postsCollection.document()
        val postWithId = post.copy(id = postRef.id)
        postRef.set(postWithId).await()
        return postRef.id
    }

    override suspend fun getPost(postId: String): Post? {
        return postsCollection.document(postId).get().await()
            .toObject(Post::class.java)
    }

    override suspend fun getAllPosts(): List<Post> {
        return postsCollection
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .get()
            .await()
            .toObjects(Post::class.java)
    }

    override suspend fun getUserPosts(userId: String): List<Post> {
        return postsCollection
            .whereEqualTo("userId", userId)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .get()
            .await()
            .toObjects(Post::class.java)
    }

    override suspend fun getTrendingPosts(): List<Post> {
        return postsCollection
            .orderBy("likes", Query.Direction.DESCENDING)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .limit(10)
            .get()
            .await()
            .toObjects(Post::class.java)
    }

    override fun getPostsFlow(): Flow<List<Post>> {
        return postsCollection
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .snapshot()
            .map { snapshot -> snapshot.toObjects(Post::class.java) }
    }

    override suspend fun updatePost(post: Post) {
        postsCollection.document(post.id).set(post).await()
    }

    override suspend fun deletePost(postId: String) {
        // Delete post, its comments, and likes in a batch
        val batch = firestore.batch()
        
        // Delete post
        batch.delete(postsCollection.document(postId))
        
        // Delete comments
        val comments = commentsCollection
            .whereEqualTo("postId", postId)
            .get()
            .await()
        comments.documents.forEach { doc ->
            batch.delete(doc.reference)
        }
        
        // Delete likes
        val likes = likesCollection
            .whereEqualTo("postId", postId)
            .get()
            .await()
        likes.documents.forEach { doc ->
            batch.delete(doc.reference)
        }
        
        batch.commit().await()
    }

    override suspend fun likePost(postId: String) {
        val userId = userRepository.getCurrentUserId()
        val likeDoc = likesCollection.document("${userId}_${postId}")
        
        firestore.runTransaction { transaction ->
            val postRef = postsCollection.document(postId)
            val post = transaction.get(postRef).toObject(Post::class.java)
                ?: throw IllegalStateException("Post not found")
            
            transaction.set(likeDoc, mapOf(
                "userId" to userId,
                "postId" to postId,
                "timestamp" to System.currentTimeMillis()
            ))
            
            transaction.set(postRef, post.copy(likes = post.likes + 1))
        }.await()
    }

    override suspend fun unlikePost(postId: String) {
        val userId = userRepository.getCurrentUserId()
        val likeDoc = likesCollection.document("${userId}_${postId}")
        
        firestore.runTransaction { transaction ->
            val postRef = postsCollection.document(postId)
            val post = transaction.get(postRef).toObject(Post::class.java)
                ?: throw IllegalStateException("Post not found")
            
            transaction.delete(likeDoc)
            transaction.set(postRef, post.copy(likes = post.likes - 1))
        }.await()
    }

    override suspend fun isPostLiked(postId: String): Boolean {
        val userId = userRepository.getCurrentUserId()
        return likesCollection.document("${userId}_${postId}")
            .get()
            .await()
            .exists()
    }

    override suspend fun addComment(comment: Comment): String {
        val commentRef = commentsCollection.document()
        val commentWithId = comment.copy(id = commentRef.id)
        
        firestore.runTransaction { transaction ->
            val postRef = postsCollection.document(comment.postId)
            val post = transaction.get(postRef).toObject(Post::class.java)
                ?: throw IllegalStateException("Post not found")
            
            transaction.set(commentRef, commentWithId)
            transaction.set(postRef, post.copy(commentsCount = post.commentsCount + 1))
        }.await()
        
        return commentRef.id
    }

    override suspend fun getComments(postId: String): List<Comment> {
        return commentsCollection
            .whereEqualTo("postId", postId)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .get()
            .await()
            .toObjects(Comment::class.java)
    }

    override suspend fun deleteComment(commentId: String) {
        val comment = commentsCollection.document(commentId)
            .get()
            .await()
            .toObject(Comment::class.java)
            ?: return
        
        firestore.runTransaction { transaction ->
            val postRef = postsCollection.document(comment.postId)
            val post = transaction.get(postRef).toObject(Post::class.java)
                ?: throw IllegalStateException("Post not found")
            
            transaction.delete(commentsCollection.document(commentId))
            transaction.set(postRef, post.copy(commentsCount = post.commentsCount - 1))
        }.await()
    }
} 