package com.example.habithive.di

import com.example.habithive.data.repository.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.storage.FirebaseStorage
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import javax.inject.Named

@Module
@InstallIn(SingletonComponent::class)
object FirebaseModule {

    @Provides
    @Singleton
    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

    @Provides
    @Singleton
    fun provideFirebaseFirestore(): FirebaseFirestore = FirebaseFirestore.getInstance()

    @Provides
    @Singleton
    fun provideFirebaseStorage(): FirebaseStorage = FirebaseStorage.getInstance()

    @Provides
    @Named("exercises_collection")
    fun provideExercisesCollection(firestore: FirebaseFirestore): CollectionReference =
        firestore.collection("exercises")

    @Provides
    @Named("daily_summaries_collection")
    fun provideDailySummariesCollection(firestore: FirebaseFirestore): CollectionReference =
        firestore.collection("dailySummaries")

    @Provides
    @Singleton
    fun provideUserRepository(
        auth: FirebaseAuth,
        firestore: FirebaseFirestore
    ): UserRepository = UserRepositoryImpl(auth, firestore)

    @Provides
    @Singleton
    fun provideExerciseRepository(
        firestore: FirebaseFirestore,
        auth: FirebaseAuth,
        exercisesCollection: CollectionReference,
        dailySummariesCollection: CollectionReference
    ): ExerciseRepository = ExerciseRepositoryImpl(firestore, auth, exercisesCollection, dailySummariesCollection)

    @Provides
    @Singleton
    fun provideFriendRepository(
        firestore: FirebaseFirestore,
        auth: FirebaseAuth
    ): FriendRepository = FriendRepositoryImpl(firestore, auth)
} 