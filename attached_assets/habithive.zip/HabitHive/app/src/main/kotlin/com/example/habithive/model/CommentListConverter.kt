package com.example.habithive.model

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class CommentListConverter {
    private val gson = Gson()

    @TypeConverter
    fun fromCommentList(comments: List<Comment>): String {
        return gson.toJson(comments)
    }

    @TypeConverter
    fun toCommentList(commentsString: String): List<Comment> {
        val type = object : TypeToken<List<Comment>>() {}.type
        return gson.fromJson(commentsString, type)
    }
} 