package com.example.habithive.repository

import com.example.habithive.model.CommunityGoal
import com.example.habithive.model.Comment
import com.example.habithive.model.GoalStatus
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.util.Date
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CommunityGoalRepository @Inject constructor(
    private val db: FirebaseFirestore
) {
    private val goalsCollection = db.collection("communityGoals")

    suspend fun createGoal(goal: CommunityGoal) {
        try {
            goalsCollection.add(goal).await()
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun getGoalById(goalId: String): CommunityGoal {
        return try {
            goalsCollection.document(goalId).get().await()
                .toObject(CommunityGoal::class.java) ?: throw Exception("Goal not found")
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun getGoalsByUser(userId: String): List<CommunityGoal> {
        return try {
            val snapshot = goalsCollection
                .whereEqualTo("creatorId", userId)
                .get()
                .await()
            snapshot.documents.map { doc ->
                doc.toObject(CommunityGoal::class.java) ?: throw Exception("Failed to parse goal")
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getParticipatingGoals(userId: String): List<CommunityGoal> {
        return try {
            val snapshot = goalsCollection
                .whereArrayContains("participants", userId)
                .get()
                .await()
            snapshot.documents.map { doc ->
                doc.toObject(CommunityGoal::class.java) ?: throw Exception("Failed to parse goal")
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun joinGoal(goalId: String, userId: String) {
        try {
            val goal = goalsCollection.document(goalId).get().await()
                .toObject(CommunityGoal::class.java) ?: throw Exception("Goal not found")
            
            val updatedParticipants = goal.participants.toMutableList().apply {
                if (!contains(userId)) {
                    add(userId)
                }
            }
            
            goalsCollection.document(goalId)
                .update("participants", updatedParticipants)
                .await()
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun supportGoal(goalId: String, userId: String) {
        try {
            val goal = goalsCollection.document(goalId).get().await()
                .toObject(CommunityGoal::class.java) ?: throw Exception("Goal not found")
            
            val updatedSupporters = goal.supporters.toMutableList().apply {
                if (!contains(userId)) {
                    add(userId)
                }
            }
            
            goalsCollection.document(goalId)
                .update("supporters", updatedSupporters)
                .await()
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun updateProgress(goalId: String, newValue: Int) {
        try {
            goalsCollection.document(goalId)
                .update("currentValue", newValue)
                .await()
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun addComment(goalId: String, comment: Comment) {
        try {
            val goal = goalsCollection.document(goalId).get().await()
                .toObject(CommunityGoal::class.java) ?: throw Exception("Goal not found")
            
            val updatedComments = goal.comments.toMutableList().apply {
                add(comment)
            }
            
            goalsCollection.document(goalId)
                .update("comments", updatedComments)
                .await()
        } catch (e: Exception) {
            throw e
        }
    }

    suspend fun updateGoalStatus(goalId: String, status: GoalStatus) {
        try {
            goalsCollection.document(goalId)
                .update("status", status)
                .await()
        } catch (e: Exception) {
            throw e
        }
    }
} 