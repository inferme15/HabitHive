package com.example.habithive.util.notification

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.example.habithive.data.repository.ExerciseRepository
import com.example.habithive.data.repository.GoalRepository
import com.example.habithive.data.repository.LeaderboardRepository
import com.example.habithive.data.repository.UserRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

@HiltWorker
class NotificationWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val notificationManager: NotificationManager,
    private val userRepository: UserRepository,
    private val exerciseRepository: ExerciseRepository,
    private val goalRepository: GoalRepository,
    private val leaderboardRepository: LeaderboardRepository
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        private const val WORK_NAME = "notification_worker"

        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val periodicWork = PeriodicWorkRequestBuilder<NotificationWorker>(
                1, TimeUnit.HOURS,
                15, TimeUnit.MINUTES
            )
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                periodicWork
            )
        }
    }

    override suspend fun doWork(): Result {
        try {
            val currentUser = userRepository.getCurrentUser() ?: return Result.success()

            // Check for goal reminders
            checkGoalReminders(currentUser.id)

            // Check exercise streak
            checkExerciseStreak(currentUser.id)

            // Check leaderboard changes
            checkLeaderboardChanges(currentUser.id)

            return Result.success()
        } catch (e: Exception) {
            return if (runAttemptCount < 3) {
                Result.retry()
            } else {
                Result.failure()
            }
        }
    }

    private suspend fun checkGoalReminders(userId: String) {
        val goals = goalRepository.getActiveGoals(userId)
        for (goal in goals) {
            val daysLeft = goal.getDaysLeft()
            if (daysLeft in 1..3) {
                notificationManager.showGoalReminderNotification(
                    goalTitle = goal.title,
                    daysLeft = daysLeft
                )
            }
        }
    }

    private suspend fun checkExerciseStreak(userId: String) {
        val lastExercise = exerciseRepository.getLastExercise(userId)
        val daysSinceLastExercise = lastExercise?.getDaysSinceCompletion() ?: Int.MAX_VALUE

        if (daysSinceLastExercise >= 1) {
            notificationManager.showExerciseReminderNotification()
        }
    }

    private suspend fun checkLeaderboardChanges(userId: String) {
        val previousRank = inputData.getInt("previous_rank", -1)
        val currentRank = leaderboardRepository.getUserRank(userId, LeaderboardType.GLOBAL)

        if (previousRank != -1 && previousRank != currentRank) {
            notificationManager.showLeaderboardUpdateNotification(
                newRank = currentRank,
                oldRank = previousRank
            )
        }

        // Store current rank for next comparison
        val outputData = workDataOf("previous_rank" to currentRank)
        setProgress(outputData)
    }
} 