package com.example.habithive.data.model

import kotlinx.serialization.Serializable
import kotlinx.datetime.LocalDate

@Serializable
data class DailyExerciseSummary(
    val date: LocalDate,
    val totalDuration: Long = 0,
    val totalCaloriesBurned: Int = 0,
    val totalDistance: Double = 0.0,
    val exercises: List<Exercise> = emptyList()
) 