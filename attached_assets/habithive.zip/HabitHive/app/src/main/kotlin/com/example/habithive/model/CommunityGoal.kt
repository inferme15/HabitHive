package com.example.habithive.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.parcelize.RawValue
import java.util.Date

@Parcelize
data class CommunityGoal(
    val id: String = "",
    val creatorId: String,
    val title: String,
    val description: String,
    val type: GoalType,
    val targetValue: Int,
    val currentValue: Int = 0,
    val status: GoalStatus = GoalStatus.ACTIVE,
    val participants: List<String> = emptyList(),
    val supporters: List<String> = emptyList(),
    @androidx.room.TypeConverters(CommentListConverter::class)
    val comments: List<@RawValue Comment> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable {
    // Empty constructor required for Firestore
    constructor() : this("", "", "", "", GoalType.CUSTOM, 0)
} 