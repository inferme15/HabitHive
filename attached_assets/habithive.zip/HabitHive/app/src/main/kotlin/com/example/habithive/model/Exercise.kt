package com.example.habithive.model

import android.os.Parcelable
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.PropertyName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Exercise(
    @DocumentId
    val id: String = "",
    val userId: String = "",
    val type: String = "",
    val duration: Int = 0,
    val calories: Int = 0,
    val date: Timestamp = Timestamp.now(),
    val notes: String = ""
) : Parcelable {
    // Empty constructor required for Firestore
    constructor() : this("", "", "", 0, 0, Timestamp.now(), "")
} 