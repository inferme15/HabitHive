package com.example.habithive.data.model

import kotlinx.serialization.Serializable

@Serializable
data class FitnessQuote(
    val id: String = "",
    val content: String = "",
    val author: String = "",
    val category: String = "",
    val likes: Int = 0,
    val shares: Int = 0
) 