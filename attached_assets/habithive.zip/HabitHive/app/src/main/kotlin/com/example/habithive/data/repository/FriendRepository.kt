package com.example.habithive.data.repository

import com.example.habithive.data.model.FriendRequest
import com.example.habithive.data.model.User
import kotlinx.coroutines.flow.Flow

interface FriendRepository {
    suspend fun getFriends(): Flow<List<User>>
    suspend fun sendFriendRequest(
        senderId: String,
        receiverId: String,
        senderName: String,
        senderPhotoUrl: String?
    )
    suspend fun acceptFriendRequest(requestId: String)
    suspend fun rejectFriendRequest(requestId: String)
    suspend fun getFriendRequests(): Flow<List<FriendRequest>>
    suspend fun getPendingRequests(userId: String): List<FriendRequest>
    suspend fun removeFriend(friendId: String)
} 