package com.example.habithive.model

enum class ExerciseType(val category: String, val caloriesPerMinute: Int) {
    // Standing Exercises
    JUMPING("Standing", 10),
    RUNNING("Standing", 12),
    DANCING("Standing", 8),
    BOXING("Standing", 9),
    BASKETBALL("Standing", 8),

    // Sitting Exercises
    CYCLING("Sitting", 7),
    ROWING("Sitting", 8),
    SEATED_EXERCISES("Sitting", 4),
    
    // Walking Exercises
    WALKING("Walking", 5),
    JOGGING("Walking", 8),
    HIKING("Walking", 6),

    // Sleeping/Lying Exercises
    YOGA("Lying", 3),
    STRETCHING("Lying", 2),
    MEDITATION("Lying", 1);

    companion object {
        fun getByCategory(category: String): List<ExerciseType> {
            return values().filter { it.category == category }
        }

        fun getCategories(): List<String> {
            return values().map { it.category }.distinct()
        }

        fun calculateCalories(type: ExerciseType, durationMinutes: Int): Int {
            return type.caloriesPerMinute * durationMinutes
        }
    }
} 