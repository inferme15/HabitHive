package com.example.habithive.repository

import com.example.habithive.model.FriendRequest
import com.example.habithive.model.RequestStatus
import com.example.habithive.model.User
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FriendRepository @Inject constructor(
    private val firestore: FirebaseFirestore
) {
    private val usersCollection = firestore.collection("users")
    private val friendRequestsCollection = firestore.collection("friendRequests")

    suspend fun getFriends(userId: String): List<User> {
        val userDoc = usersCollection.document(userId).get().await()
        val friendIds = (userDoc.get("friends") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
        
        return if (friendIds.isEmpty()) {
            emptyList()
        } else {
            usersCollection.whereIn("id", friendIds).get().await()
                .documents.mapNotNull { doc ->
                    doc.toObject(User::class.java)
                }
        }
    }

    suspend fun getPendingRequests(userId: String): List<FriendRequest> {
        return friendRequestsCollection
            .whereEqualTo("receiverId", userId)
            .whereEqualTo("status", "pending")
            .get()
            .await()
            .documents
            .mapNotNull { doc ->
                doc.toObject(FriendRequest::class.java)
            }
    }

    suspend fun searchUsers(query: String): List<User> {
        return usersCollection
            .whereGreaterThanOrEqualTo("username", query)
            .whereLessThanOrEqualTo("username", query + '\uf8ff')
            .get()
            .await()
            .documents
            .mapNotNull { doc ->
                doc.toObject(User::class.java)
            }
    }

    suspend fun sendFriendRequest(senderId: String, receiverId: String) {
        val sender = usersCollection.document(senderId).get().await()
            .toObject(User::class.java) ?: throw IllegalStateException("Sender not found")

        val request = FriendRequest(
            id = friendRequestsCollection.document().id,
            senderId = senderId,
            receiverId = receiverId,
            senderUsername = sender.username,
            senderProfileImageUrl = sender.profileImageUrl
        )

        friendRequestsCollection.document(request.id).set(request).await()
    }

    suspend fun acceptFriendRequest(request: FriendRequest) {
        // Update request status
        friendRequestsCollection.document(request.id)
            .update("status", "accepted")
            .await()

        // Add each user to the other's friends list
        val senderRef = usersCollection.document(request.senderId)
        val receiverRef = usersCollection.document(request.receiverId)

        firestore.runTransaction { transaction ->
            val senderFriends = (transaction.get(senderRef).get("friends") as? List<*>)?.filterIsInstance<String>()?.toMutableList() ?: mutableListOf()
            val receiverFriends = (transaction.get(receiverRef).get("friends") as? List<*>)?.filterIsInstance<String>()?.toMutableList() ?: mutableListOf()

            if (!senderFriends.contains(request.receiverId)) {
                senderFriends.add(request.receiverId)
            }
            if (!receiverFriends.contains(request.senderId)) {
                receiverFriends.add(request.senderId)
            }

            transaction.update(senderRef, "friends", senderFriends)
            transaction.update(receiverRef, "friends", receiverFriends)
        }.await()
    }

    suspend fun rejectFriendRequest(request: FriendRequest) {
        friendRequestsCollection.document(request.id)
            .update("status", "rejected")
            .await()
    }
} 