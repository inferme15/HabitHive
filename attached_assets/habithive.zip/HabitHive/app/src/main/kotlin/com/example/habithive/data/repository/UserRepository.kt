package com.example.habithive.data.repository

import com.example.habithive.data.model.User
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import kotlinx.coroutines.flow.Flow

interface UserRepository {
    suspend fun getCurrentUser(): User?
    suspend fun getCurrentUserId(): String?
    suspend fun updateUser(user: User)
    suspend fun getUserByEmail(email: String): User?
    suspend fun signOut()
    suspend fun signInWithGoogle(account: GoogleSignInAccount): Result<User>
    fun getUserFlow(): Flow<User?>
    suspend fun resetPassword(email: String)
    suspend fun signIn(email: String, password: String)
} 