package com.example.habithive.ui.adapters

class ChallengesAdapter(
    private val onJoinClick: (Challenge) -> Unit,
    private val onDetailsClick: (Challenge) -> Unit
) : ListAdapter<Challenge, ChallengesAdapter.ViewHolder>(ChallengeDiffCallback()) {
    // Implementation
}

class SocialPostAdapter(
    private val onLikeClick: (SocialPost) -> Unit,
    private val onCommentClick: (SocialPost) -> Unit
) : ListAdapter<SocialPost, SocialPostAdapter.ViewHolder>(PostDiffCallback()) {
    // Implementation
}

class LeaderboardAdapter : ListAdapter<LeaderboardEntry, LeaderboardAdapter.ViewHolder>(LeaderboardDiffCallback()) {
    // Implementation
}

class RewardsAdapter(
    private val onPurchaseClick: (Reward) -> Unit
) : ListAdapter<Reward, RewardsAdapter.ViewHolder>(RewardDiffCallback()) {
    // Implementation
} 