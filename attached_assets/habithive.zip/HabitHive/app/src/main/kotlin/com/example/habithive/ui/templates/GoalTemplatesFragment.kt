package com.example.habithive.ui.templates

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.example.habithive.R
import com.example.habithive.data.model.GoalTemplate
import com.example.habithive.data.model.TemplateFilter
import com.example.habithive.databinding.FragmentGoalTemplatesBinding
import com.example.habithive.util.showError
import com.google.android.material.tabs.TabLayout
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class GoalTemplatesFragment : Fragment(R.layout.fragment_goal_templates) {
    private val binding by viewBinding(FragmentGoalTemplatesBinding::bind)
    private val viewModel: GoalTemplatesViewModel by viewModels()
    private lateinit var templatesAdapter: GoalTemplatesAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeState()
    }

    private fun setupUI() {
        setupTabs()
        setupRecyclerView()
        setupFab()
    }

    private fun setupTabs() {
        binding.filterTabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> viewModel.updateFilter(TemplateFilter.ALL)
                    1 -> viewModel.updateFilter(TemplateFilter.PUBLIC)
                    2 -> viewModel.updateFilter(TemplateFilter.PRIVATE)
                    3 -> viewModel.updateFilter(TemplateFilter.POPULAR)
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }
} 