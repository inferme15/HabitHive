package com.example.habithive.ui.exercise

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.example.habithive.R
import com.example.habithive.databinding.FragmentExerciseTrackingBinding
import com.example.habithive.util.formatDuration
import com.example.habithive.util.formatPace
import com.example.habithive.util.viewBinding
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class ExerciseTrackingFragment : Fragment(R.layout.fragment_exercise_tracking) {

    private val binding by viewBinding(FragmentExerciseTrackingBinding::bind)
    private val viewModel: ExerciseViewModel by viewModels()
    private var googleMap: GoogleMap? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeState()
    }

    private fun setupUI() {
        with(binding) {
            toolbar.setNavigationOnClickListener {
                showStopConfirmationDialog()
            }

            mapView.onCreate(null)
            mapView.getMapAsync { map ->
                googleMap = map
                map.isMyLocationEnabled = true
                map.uiSettings.isZoomControlsEnabled = true
            }

            pauseButton.setOnClickListener {
                when (pauseButton.text) {
                    getString(R.string.pause) -> viewModel.pauseExercise()
                    getString(R.string.resume) -> viewModel.resumeExercise()
                }
            }

            stopButton.setOnClickListener {
                showStopConfirmationDialog()
            }
        }
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.trackingState.collect { state ->
                    updateUI(state)
                }
            }
        }
    }

    private fun updateUI(state: ExerciseTrackingState) {
        when (state) {
            is ExerciseTrackingState.Active -> {
                with(binding) {
                    timeTextView.text = formatDuration(state.elapsedTime)
                    distanceTextView.text = getString(
                        R.string.distance_format,
                        state.distance
                    )
                    paceTextView.text = formatPace(state.pace)
                    caloriesTextView.text = getString(
                        R.string.calories_format,
                        state.calories
                    )
                    pauseButton.text = getString(R.string.pause)

                    updateMap(state.session.locationPoints)
                }
            }
            is ExerciseTrackingState.Paused -> {
                binding.pauseButton.text = getString(R.string.resume)
            }
            is ExerciseTrackingState.Completed -> {
                findNavController().navigate(
                    ExerciseTrackingFragmentDirections.actionTrackingToSummary(state.exercise.id)
                )
            }
            is ExerciseTrackingState.Error -> {
                // Show error message
            }
            else -> { /* Handle other states */ }
        }
    }

    private fun updateMap(points: List<LocationPoint>) {
        val map = googleMap ?: return
        if (points.isEmpty()) return

        val latLngs = points.map { LatLng(it.latitude, it.longitude) }
        
        // Draw route
        map.clear()
        map.addPolyline(
            PolylineOptions()
                .addAll(latLngs)
                .color(resources.getColor(R.color.colorPrimary, null))
                .width(12f)
        )

        // Update camera to follow current location
        map.animateCamera(
            CameraUpdateFactory.newLatLngZoom(
                latLngs.last(),
                17f
            )
        )
    }

    private fun showStopConfirmationDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.stop_exercise)
            .setMessage(R.string.stop_exercise_confirmation)
            .setPositiveButton(R.string.stop) { _, _ ->
                viewModel.stopExercise()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        binding.mapView.onResume()
    }

    override fun onPause() {
        binding.mapView.onPause()
        super.onPause()
    }

    override fun onDestroyView() {
        googleMap = null
        binding.mapView.onDestroy()
        super.onDestroyView()
    }
} 