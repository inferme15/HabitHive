package com.example.habithive.ui.leaderboard

import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.habithive.R
import com.example.habithive.data.model.LeaderboardType
import com.example.habithive.databinding.FragmentLeaderboardBinding
import com.example.habithive.util.viewBinding
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class LeaderboardFragment : Fragment(R.layout.fragment_leaderboard) {

    private val binding by viewBinding(FragmentLeaderboardBinding::bind)
    private val viewModel: LeaderboardViewModel by viewModels()

    private lateinit var topPerformersAdapter: LeaderboardAdapter
    private lateinit var nearbyUsersAdapter: LeaderboardAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupTabs()
        setupRecyclerView()
        observeLeaderboard()
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener { tab ->
            when (tab.position) {
                0 -> viewModel.updateType(LeaderboardType.COMPLETION_RATE)
                1 -> viewModel.updateType(LeaderboardType.TOTAL_DISTANCE)
                2 -> viewModel.updateType(LeaderboardType.STREAK)
                3 -> viewModel.updateType(LeaderboardType.EXPERIENCE)
            }
        }
    }

    private fun setupRecyclerView() {
        topPerformersAdapter = LeaderboardAdapter(viewModel.getCurrentUserId())
        nearbyUsersAdapter = LeaderboardAdapter(viewModel.getCurrentUserId())

        binding.topPerformersRecyclerView.adapter = topPerformersAdapter
        binding.nearbyUsersRecyclerView.adapter = nearbyUsersAdapter

        binding.swipeRefresh.setOnRefreshListener {
            viewModel.refreshLeaderboard()
        }
    }

    private fun observeLeaderboard() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.leaderboardState.collect { state ->
                    updateUI(state)
                }
            }
        }
    }

    private fun updateUI(state: LeaderboardState) {
        with(binding) {
            progressIndicator.isVisible = state is LeaderboardState.Loading
            swipeRefresh.isRefreshing = state is LeaderboardState.Loading

            when (state) {
                is LeaderboardState.Success -> {
                    state.userEntry?.let { entry ->
                        userRankItem.root.isVisible = true
                        with(userRankItem) {
                            rankTextView.text = "#${entry.rank}"
                            userNameTextView.text = entry.userName
                            statsTextView.text = getString(
                                R.string.leaderboard_stats_format,
                                entry.exerciseMinutes,
                                entry.goalsCompleted,
                                entry.currentStreak
                            )
                            scoreTextView.text = entry.score.toString()
                        }
                    } ?: run {
                        userRankItem.root.isVisible = false
                    }

                    topPerformersAdapter.submitList(state.stats.topPerformers)
                    nearbyUsersAdapter.submitList(state.stats.nearbyUsers)

                    topPerformersCard.isVisible = state.stats.topPerformers.isNotEmpty()
                    nearbyUsersCard.isVisible = state.stats.nearbyUsers.isNotEmpty()
                }

                is LeaderboardState.Error -> {
                    Snackbar.make(
                        requireView(),
                        state.message,
                        Snackbar.LENGTH_LONG
                    ).show()
                }

                LeaderboardState.Loading -> {
                    // Loading state handled by progress indicator
                }
            }
        }
    }
} 