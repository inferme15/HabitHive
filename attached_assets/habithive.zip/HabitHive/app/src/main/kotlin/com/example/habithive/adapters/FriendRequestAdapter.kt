package com.example.habithive.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.habithive.R
import com.example.habithive.databinding.ItemFriendRequestBinding
import com.example.habithive.data.model.FriendRequest

class FriendRequestAdapter(
    private val onAcceptClick: (FriendRequest) -> Unit,
    private val onRejectClick: (FriendRequest) -> Unit
) : ListAdapter<FriendRequest, FriendRequestAdapter.FriendRequestViewHolder>(FriendRequestDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FriendRequestViewHolder {
        val binding = ItemFriendRequestBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return FriendRequestViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FriendRequestViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class FriendRequestViewHolder(
        private val binding: ItemFriendRequestBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(friendRequest: FriendRequest) {
            binding.apply {
                tvUsername.text = friendRequest.senderName

                // Load profile image using Glide
                Glide.with(ivProfile)
                    .load(friendRequest.senderPhotoUrl)
                    .placeholder(R.drawable.default_profile)
                    .error(R.drawable.default_profile)
                    .circleCrop()
                    .into(ivProfile)

                btnAccept.setOnClickListener {
                    onAcceptClick(friendRequest)
                }

                btnDecline.setOnClickListener {
                    onRejectClick(friendRequest)
                }
            }
        }
    }

    private class FriendRequestDiffCallback : DiffUtil.ItemCallback<FriendRequest>() {
        override fun areItemsTheSame(oldItem: FriendRequest, newItem: FriendRequest): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: FriendRequest, newItem: FriendRequest): Boolean {
            return oldItem == newItem
        }
    }
} 