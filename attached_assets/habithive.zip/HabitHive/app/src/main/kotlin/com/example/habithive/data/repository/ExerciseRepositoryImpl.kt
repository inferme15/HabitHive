package com.example.habithive.data.repository

import com.example.habithive.data.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton
import kotlinx.datetime.*
import java.util.UUID

@Singleton
class ExerciseRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth,
    @Named("exercises") private val exercisesCollection: CollectionReference,
    @Named("exercise_sessions") private val sessionsCollection: CollectionReference,
    private val userRepository: UserRepository
) : ExerciseRepository {

    private val currentUserId: String
        get() = auth.currentUser?.uid ?: throw IllegalStateException("User not logged in")

    private val activeSessionFlow = MutableStateFlow<ExerciseSession?>(null)

    override suspend fun saveExercise(exercise: Exercise) {
        exercisesCollection.document(exercise.id).set(exercise).await()
        updateDailySummary(exercise)
    }

    override suspend fun getExercises(): Flow<List<Exercise>> = flow {
        val snapshot = exercisesCollection
            .whereEqualTo("userId", currentUserId)
            .orderBy("date", Query.Direction.DESCENDING)
            .get()
            .await()
        emit(snapshot.toObjects(Exercise::class.java))
    }

    override suspend fun startExercise(type: ExerciseType): ExerciseSession {
        val session = ExerciseSession(
            id = UUID.randomUUID().toString(),
            exerciseId = UUID.randomUUID().toString(),
            startTime = Clock.System.now().toEpochMilliseconds(),
            isActive = true,
            type = type
        )
        activeSessionFlow.value = session
        sessionsCollection.document(session.id).set(session).await()
        return session
    }

    override suspend fun updateExerciseSession(session: ExerciseSession) {
        sessionsCollection.document(session.id).set(session).await()
        activeSessionFlow.value = session
    }

    override suspend fun endExercise(sessionId: String): Exercise {
        val session = sessionsCollection.document(sessionId).get().await()
            .toObject(ExerciseSession::class.java)
            ?: throw IllegalStateException("Session not found")

        val exercise = Exercise(
            id = session.exerciseId,
            userId = currentUserId,
            type = session.type,
            duration = session.endTime - session.startTime,
            distance = session.currentDistance,
            caloriesBurned = session.currentCalories,
            date = session.startTime,
            notes = null
        )

        exercisesCollection.document(exercise.id).set(exercise).await()
        sessionsCollection.document(sessionId).delete().await()
        activeSessionFlow.value = null
        updateDailySummary(exercise)

        return exercise
    }

    override suspend fun getAllExercises(userId: String): List<Exercise> {
        return exercisesCollection
            .whereEqualTo("userId", userId)
            .orderBy("date", Query.Direction.DESCENDING)
            .get()
            .await()
            .toObjects(Exercise::class.java)
    }

    override suspend fun getExercise(exerciseId: String): Exercise? {
        return exercisesCollection
            .document(exerciseId)
            .get()
            .await()
            .toObject(Exercise::class.java)
    }

    override fun getActiveSession(): Flow<ExerciseSession?> = activeSessionFlow

    override suspend fun getExerciseStats(userId: String): ExerciseStats {
        val exercises = getAllExercises(userId)
        
        return ExerciseStats(
            totalExercises = exercises.size,
            totalDuration = exercises.sumOf { it.duration },
            totalCaloriesBurned = exercises.sumOf { it.caloriesBurned ?: 0 },
            currentStreak = calculateCurrentStreak(exercises),
            longestStreak = calculateLongestStreak(exercises),
            favoriteType = calculateFavoriteType(exercises),
            weeklyProgress = calculateWeeklyProgress(exercises)
        )
    }

    override suspend fun deleteExercise(exerciseId: String) {
        exercisesCollection.document(exerciseId).delete().await()
    }

    override suspend fun getUserCurrentStreak(userId: String): Int {
        return calculateCurrentStreak(getAllExercises(userId))
    }

    override suspend fun getUserTotalExerciseDuration(userId: String): Long {
        return getAllExercises(userId).sumOf { it.duration }
    }

    override suspend fun getUserTotalCaloriesBurned(userId: String): Int {
        return getAllExercises(userId).sumOf { it.caloriesBurned ?: 0 }
    }

    override suspend fun getDailySummary(date: LocalDate): DailyExerciseSummary? {
        val startInstant = date.atStartOfDayIn(TimeZone.currentSystemDefault())
        val endInstant = date.plus(DatePeriod(days = 1)).atStartOfDayIn(TimeZone.currentSystemDefault())
        
        val exercises = exercisesCollection
            .whereEqualTo("userId", currentUserId)
            .whereGreaterThanOrEqualTo("date", startInstant.toEpochMilliseconds())
            .whereLessThan("date", endInstant.toEpochMilliseconds())
            .get()
            .await()
            .toObjects(Exercise::class.java)

        return if (exercises.isNotEmpty()) {
            DailyExerciseSummary(
                date = date,
                exercises = exercises,
                totalDuration = exercises.sumOf { it.duration },
                totalCaloriesBurned = exercises.sumOf { it.caloriesBurned ?: 0 },
                totalDistance = exercises.sumOf { it.distance ?: 0.0 }
            )
        } else null
    }

    override suspend fun getWeeklySummary(): List<DailyExerciseSummary> {
        val today = Clock.System.now().toLocalDateTime(TimeZone.currentSystemDefault()).date
        val startDate = today.minus(DatePeriod(days = 7))
        
        val summaries = mutableListOf<DailyExerciseSummary>()
        var currentDate = startDate

        while (currentDate <= today) {
            getDailySummary(currentDate)?.let { summaries.add(it) }
            currentDate = currentDate.plus(DatePeriod(days = 1))
        }

        return summaries
    }

    override suspend fun updateExercise(exercise: Exercise) {
        exercisesCollection.document(exercise.id).set(exercise).await()
        updateDailySummary(exercise)
    }

    private suspend fun updateDailySummary(exercise: Exercise) {
        val date = Instant.fromEpochMilliseconds(exercise.date)
            .toLocalDateTime(TimeZone.currentSystemDefault())
            .date
        getDailySummary(date)
    }

    private fun calculateCurrentStreak(exercises: List<Exercise>): Int {
        if (exercises.isEmpty()) return 0

        var streak = 0
        var currentDate = Clock.System.now().toLocalDateTime(TimeZone.currentSystemDefault()).date
        val exercisesByDate = exercises.groupBy { 
            Instant.fromEpochMilliseconds(it.date)
                .toLocalDateTime(TimeZone.currentSystemDefault())
                .date 
        }

        while (exercisesByDate.containsKey(currentDate)) {
            streak++
            currentDate = currentDate.minus(DatePeriod(days = 1))
        }

        return streak
    }

    private fun calculateLongestStreak(exercises: List<Exercise>): Int {
        if (exercises.isEmpty()) return 0

        var maxStreak = 0
        var currentStreak = 0
        var lastDate: LocalDate? = null

        val sortedDates = exercises
            .map { Instant.fromEpochMilliseconds(it.date)
                .toLocalDateTime(TimeZone.currentSystemDefault())
                .date }
            .distinct()
            .sorted()

        for (date in sortedDates) {
            if (lastDate == null || date == lastDate.plus(DatePeriod(days = 1))) {
                currentStreak++
                maxStreak = maxOf(maxStreak, currentStreak)
            } else {
                currentStreak = 1
            }
            lastDate = date
        }

        return maxStreak
    }

    private fun calculateFavoriteType(exercises: List<Exercise>): ExerciseType? {
        return exercises
            .groupBy { it.type }
            .maxByOrNull { (_, exercises) -> exercises.size }
            ?.key
    }

    private fun calculateWeeklyProgress(exercises: List<Exercise>): Map<Int, Long> {
        return exercises
            .filter { 
                val exerciseDate = Instant.fromEpochMilliseconds(it.date)
                    .toLocalDateTime(TimeZone.currentSystemDefault())
                    .date
                val today = Clock.System.now()
                    .toLocalDateTime(TimeZone.currentSystemDefault())
                    .date
                exerciseDate >= today.minus(DatePeriod(days = 7))
            }
            .groupBy { 
                Instant.fromEpochMilliseconds(it.date)
                    .toLocalDateTime(TimeZone.currentSystemDefault())
                    .dayOfWeek.value 
            }
            .mapValues { (_, exercises) -> exercises.sumOf { it.duration } }
    }
} 