package com.example.habithive.gamification

import com.example.habithive.data.model.*
import com.example.habithive.data.repository.AchievementRepository
import com.example.habithive.data.repository.UserRepository
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoalGamificationManager @Inject constructor(
    private val userRepository: UserRepository,
    private val achievementRepository: AchievementRepository
) {
    suspend fun processGoalCompletion(goal: Goal, user: User) {
        // Calculate experience points
        val experiencePoints = calculateExperiencePoints(goal)
        
        // Update user level and experience
        updateUserProgress(user, experiencePoints)
        
        // Check and award achievements
        checkAndAwardAchievements(user, goal)
        
        // Update user streaks
        updateStreaks(user, goal)
    }

    private fun calculateExperiencePoints(goal: Goal): Int {
        val basePoints = when (goal.type) {
            GoalType.DISTANCE -> (goal.targetValue * 10).toInt()
            GoalType.DURATION -> (goal.targetValue * 5).toInt()
            GoalType.CALORIES -> (goal.targetValue * 0.1).toInt()
            GoalType.WORKOUTS -> (goal.targetValue * 50).toInt()
            GoalType.STREAK -> (goal.targetValue * 100).toInt()
        }

        // Apply multipliers based on difficulty and completion time
        val difficultyMultiplier = when (goal.difficulty) {
            Difficulty.EASY -> 1.0
            Difficulty.MEDIUM -> 1.5
            Difficulty.HARD -> 2.0
        }

        val timeMultiplier = calculateTimeMultiplier(goal)

        return (basePoints * difficultyMultiplier * timeMultiplier).toInt()
    }

    private fun calculateTimeMultiplier(goal: Goal): Double {
        val completionTime = goal.completedAt!!.time - goal.startDate.time
        val expectedDuration = goal.endDate.time - goal.startDate.time
        
        return when {
            completionTime <= expectedDuration * 0.5 -> 1.5 // Early completion bonus
            completionTime <= expectedDuration * 0.75 -> 1.25
            completionTime <= expectedDuration -> 1.0
            else -> 0.75 // Late completion penalty
        }
    }

    private suspend fun updateUserProgress(user: User, experiencePoints: Int) {
        val currentLevel = user.level
        val newExperience = user.experience + experiencePoints
        val (newLevel, remainingExp) = calculateNewLevel(newExperience)

        val updatedUser = user.copy(
            level = newLevel,
            experience = remainingExp
        )

        userRepository.updateUser(updatedUser)

        if (newLevel > currentLevel) {
            handleLevelUp(updatedUser, newLevel)
        }
    }

    private fun calculateNewLevel(totalExperience: Int): Pair<Int, Int> {
        var remainingExp = totalExperience
        var level = 1

        while (remainingExp >= experienceRequiredForLevel(level)) {
            remainingExp -= experienceRequiredForLevel(level)
            level++
        }

        return Pair(level, remainingExp)
    }

    private fun experienceRequiredForLevel(level: Int): Int {
        return (100 * Math.pow(1.5, level.toDouble())).toInt()
    }

    private suspend fun handleLevelUp(user: User, newLevel: Int) {
        // Award level-up rewards
        val rewards = generateLevelUpRewards(newLevel)
        awardRewards(user, rewards)

        // Check for level-based achievements
        checkLevelAchievements(user, newLevel)
    }

    private fun generateLevelUpRewards(level: Int): List<Reward> {
        return listOf(
            Reward(
                type = RewardType.COINS,
                amount = level * 100
            ),
            Reward(
                type = RewardType.BADGE,
                badgeId = "level_$level"
            )
        )
    }

    private suspend fun checkAndAwardAchievements(user: User, goal: Goal) {
        val achievements = mutableListOf<Achievement>()

        // Check goal-specific achievements
        achievements.addAll(checkGoalAchievements(user, goal))

        // Check milestone achievements
        achievements.addAll(checkMilestoneAchievements(user))

        // Award achievements
        achievements.forEach { achievement ->
            achievementRepository.awardAchievement(user.id, achievement.id)
        }
    }

    private suspend fun checkGoalAchievements(user: User, goal: Goal): List<Achievement> {
        val achievements = mutableListOf<Achievement>()
        
        // Check completion time achievements
        if (isEarlyCompletion(goal)) {
            achievements.add(Achievement.EARLY_BIRD)
        }

        // Check streak achievements
        val currentStreak = calculateCurrentStreak(user)
        when {
            currentStreak >= 30 -> achievements.add(Achievement.STREAK_MASTER)
            currentStreak >= 7 -> achievements.add(Achievement.STREAK_WARRIOR)
        }

        // Check goal type achievements
        val completedGoalsOfType = countCompletedGoalsOfType(user, goal.type)
        when (goal.type) {
            GoalType.DISTANCE -> when {
                completedGoalsOfType >= 50 -> achievements.add(Achievement.DISTANCE_MASTER)
                completedGoalsOfType >= 10 -> achievements.add(Achievement.DISTANCE_ENTHUSIAST)
            }
            // Add similar checks for other goal types
        }

        return achievements
    }

    private suspend fun checkMilestoneAchievements(user: User): List<Achievement> {
        val achievements = mutableListOf<Achievement>()
        
        // Check total goals completed
        val totalCompleted = countTotalCompletedGoals(user)
        when {
            totalCompleted >= 100 -> achievements.add(Achievement.CENTURION)
            totalCompleted >= 50 -> achievements.add(Achievement.GOAL_MASTER)
            totalCompleted >= 10 -> achievements.add(Achievement.GOAL_SETTER)
        }

        // Check diverse goal types
        val uniqueTypes = countUniqueGoalTypes(user)
        if (uniqueTypes >= GoalType.values().size) {
            achievements.add(Achievement.VERSATILE_ACHIEVER)
        }

        return achievements
    }

    private suspend fun updateStreaks(user: User, goal: Goal) {
        val currentStreak = calculateCurrentStreak(user)
        val updatedUser = user.copy(
            currentStreak = currentStreak,
            bestStreak = maxOf(currentStreak, user.bestStreak)
        )
        userRepository.updateUser(updatedUser)
    }
} 