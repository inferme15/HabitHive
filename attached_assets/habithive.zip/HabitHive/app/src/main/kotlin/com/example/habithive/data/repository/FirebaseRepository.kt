package com.example.habithive.data.repository

import com.example.habithive.data.model.Exercise
import com.example.habithive.data.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.PhoneAuthCredential
import kotlinx.coroutines.flow.Flow

interface FirebaseRepository {
    // Authentication
    suspend fun signUp(email: String, password: String): FirebaseUser?
    suspend fun signIn(email: String, password: String): FirebaseUser?
    suspend fun signInWithCredential(credential: PhoneAuthCredential): FirebaseUser?
    suspend fun signOut()
    fun getCurrentUser(): FirebaseUser?
    fun getFirebaseAuth(): FirebaseAuth
    
    // User operations
    suspend fun createUserProfile(user: User)
    suspend fun updateUserProfile(user: User)
    fun getUserData(userId: String): Flow<User?>
    
    // Exercise operations
    suspend fun addExercise(exercise: Exercise)
    suspend fun updateExercise(exercise: Exercise)
    suspend fun deleteExercise(exerciseId: String)
    fun getTodayExercises(userId: String): Flow<List<Exercise>>
    fun getAllExercises(userId: String): Flow<List<Exercise>>
    
    // Leaderboard operations
    fun observeLeaderboard(): Flow<List<User>>
    suspend fun updateUserPoints(userId: String, points: Int)
    suspend fun updateUserStreak(userId: String)
} 