package com.example.habithive.util.notification

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class NotificationService : FirebaseMessagingService() {

    @Inject
    lateinit var notificationManager: NotificationManager

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)

        message.data.let { data ->
            when (data["type"]) {
                "achievement" -> {
                    notificationManager.showAchievementNotification(
                        title = data["title"] ?: return,
                        description = data["description"] ?: return
                    )
                }
                "friend_request" -> {
                    notificationManager.showFriendRequestNotification(
                        fromUser = data["from_user"] ?: return
                    )
                }
                "leaderboard" -> {
                    val newRank = data["new_rank"]?.toIntOrNull() ?: return
                    val oldRank = data["old_rank"]?.toIntOrNull() ?: return
                    notificationManager.showLeaderboardUpdateNotification(
                        newRank = newRank,
                        oldRank = oldRank
                    )
                }
                "goal" -> {
                    notificationManager.showGoalReminderNotification(
                        goalTitle = data["goal_title"] ?: return,
                        daysLeft = data["days_left"]?.toIntOrNull() ?: return
                    )
                }
                "exercise" -> {
                    notificationManager.showExerciseReminderNotification()
                }
            }
        }
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // Update token in the backend
        // This could be implemented in a separate TokenManager class
    }
} 