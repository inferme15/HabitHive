package com.example.habithive.network

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit

object NetworkClient {
    private const val BASE_URL = "https://api.quotable.io/"
    private const val TIMEOUT = 10L

    private val json = Json { ignoreUnknownKeys = true }
    private val contentType = "application/json".toMediaType()

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        })
        .connectTimeout(TIMEOUT, TimeUnit.SECONDS)
        .readTimeout(TIMEOUT, TimeUnit.SECONDS)
        .writeTimeout(TIMEOUT, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(json.asConverterFactory(contentType))
        .build()

    fun getQuoteService(): QuoteService {
        return retrofit.create(QuoteService::class.java)
    }

    // Fallback quotes for offline use
    val fallbackQuotes = listOf(
        QuoteResponse(
            "The only bad workout is the one that didn't happen.",
            "Anonymous"
        ),
        QuoteResponse(
            "Success is not final, failure is not fatal: it is the courage to continue that counts.",
            "Winston Churchill"
        ),
        QuoteResponse(
            "The difference between try and triumph is just a little umph!",
            "Marvin Phillips"
        ),
        QuoteResponse(
            "The hard days are the best because that's when champions are made.",
            "Gabrielle Reece"
        ),
        QuoteResponse(
            "Take care of your body. It's the only place you have to live.",
            "Jim Rohn"
        )
    )
} 