package com.example.habithive.ui.dialogs

import android.os.Bundle
import android.view.View
import androidx.fragment.app.DialogFragment
import com.example.habithive.R
import com.example.habithive.data.model.Achievement
import com.example.habithive.databinding.DialogAchievementUnlockBinding
import com.example.habithive.util.loadImage
import com.example.habithive.util.viewBinding

class AchievementUnlockDialog : DialogFragment(R.layout.dialog_achievement_unlock) {
    private val binding by viewBinding(DialogAchievementUnlockBinding::bind)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        val achievement = requireArguments().getParcelable<Achievement>(ARG_ACHIEVEMENT)
            ?: throw IllegalArgumentException("Achievement must be provided")

        setupUI(achievement)
    }

    private fun setupUI(achievement: Achievement) {
        with(binding) {
            achievementIcon.loadImage(achievement.icon)
            titleText.text = achievement.title
            descriptionText.text = achievement.description
            experienceText.text = getString(
                R.string.experience_gained_format,
                achievement.experiencePoints
            )

            achievement.reward?.let { reward ->
                rewardGroup.visibility = View.VISIBLE
                rewardIcon.setImageResource(
                    when (reward.type) {
                        RewardType.COINS -> R.drawable.ic_coin
                        RewardType.BADGE -> R.drawable.ic_badge
                        RewardType.ITEM -> R.drawable.ic_item
                    }
                )
                rewardText.text = when (reward.type) {
                    RewardType.COINS -> getString(R.string.coins_reward_format, reward.amount)
                    RewardType.BADGE -> getString(R.string.badge_unlocked)
                    RewardType.ITEM -> getString(R.string.item_unlocked)
                }
            }

            closeButton.setOnClickListener {
                dismiss()
            }
        }
    }

    companion object {
        private const val ARG_ACHIEVEMENT = "achievement"

        fun newInstance(achievement: Achievement): AchievementUnlockDialog {
            return AchievementUnlockDialog().apply {
                arguments = Bundle().apply {
                    putParcelable(ARG_ACHIEVEMENT, achievement)
                }
            }
        }
    }
} 