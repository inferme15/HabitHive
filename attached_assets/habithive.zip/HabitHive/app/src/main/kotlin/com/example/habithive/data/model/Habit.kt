package com.example.habithive.data.model

import kotlinx.serialization.Serializable

@Serializable
data class Habit(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val description: String = "",
    val category: HabitCategory = HabitCategory.OTHER,
    val frequency: HabitFrequency = HabitFrequency.DAILY,
    val reminder: Boolean = false,
    val reminderTime: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val lastCompletedAt: Long? = null,
    val streak: Int = 0,
    val status: HabitStatus = HabitStatus.ACTIVE
)

@Serializable
enum class HabitCategory {
    HEALTH,
    FITNESS,
    PRODUCTIVITY,
    MINDFULNESS,
    LEARNING,
    SOCIAL,
    OTHER
}

@Serializable
enum class HabitFrequency {
    DAILY,
    WEEKLY,
    MONTHLY
}

@Serializable
enum class HabitStatus {
    ACTIVE,
    COMPLETED,
    ARCHIVED
} 