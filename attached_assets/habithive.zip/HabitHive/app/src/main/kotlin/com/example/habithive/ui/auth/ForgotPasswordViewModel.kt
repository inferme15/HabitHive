package com.example.habithive.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.habithive.data.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class ResetPasswordResult {
    object Success : ResetPasswordResult()
    data class Error(val message: String) : ResetPasswordResult()
    object Loading : ResetPasswordResult()
}

@HiltViewModel
class ForgotPasswordViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _resetPasswordResult = MutableLiveData<ResetPasswordResult>()
    val resetPasswordResult: LiveData<ResetPasswordResult> = _resetPasswordResult

    fun resetPassword(email: String) {
        if (email.isBlank()) {
            _resetPasswordResult.value = ResetPasswordResult.Error("Email cannot be empty")
            return
        }

        viewModelScope.launch {
            _resetPasswordResult.value = ResetPasswordResult.Loading
            try {
                userRepository.resetPassword(email)
                _resetPasswordResult.value = ResetPasswordResult.Success
            } catch (e: Exception) {
                _resetPasswordResult.value = ResetPasswordResult.Error(e.message ?: "Failed to reset password")
            }
        }
    }
} 