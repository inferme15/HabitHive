package com.example.habithive.data.model

import com.google.firebase.firestore.Exclude

enum class RequestStatus {
    PENDING, ACCEPTED, REJECTED
}

data class FriendRequest(
    val id: String,
    val senderId: String,
    val receiverId: String,
    val senderName: String,
    val senderPhotoUrl: String?,
    val status: RequestStatus = RequestStatus.PENDING,
    val timestamp: Long = System.currentTimeMillis()
) {
    @Exclude
    fun isPending() = status == RequestStatus.PENDING

    @Exclude
    fun isAccepted() = status == RequestStatus.ACCEPTED

    @Exclude
    fun isRejected() = status == RequestStatus.REJECTED
} 