package com.example.habithive.ui.goals

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.habithive.databinding.ItemUserGoalBinding
import com.example.habithive.model.UserGoal
import java.text.SimpleDateFormat
import java.util.Locale

class UserGoalAdapter(
    private val onProgressUpdate: (String, Double) -> Unit,
    private val onDelete: (String) -> Unit
) : ListAdapter<UserGoal, UserGoalAdapter.GoalViewHolder>(GoalDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GoalViewHolder {
        val binding = ItemUserGoalBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return GoalViewHolder(binding)
    }

    override fun onBindViewHolder(holder: GoalViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class GoalViewHolder(
        private val binding: ItemUserGoalBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

        fun bind(goal: UserGoal) {
            binding.apply {
                textViewTitle.text = goal.title
                textViewDescription.text = goal.description
                textViewFrequency.text = goal.frequency
                textViewType.text = goal.type
                textViewProgress.text = "${goal.currentValue}/${goal.targetValue} ${goal.unit}"
                textViewDates.text = "${dateFormat.format(goal.startDate)} - ${dateFormat.format(goal.endDate)}"
                
                progressBar.max = (goal.targetValue * 100).toInt()
                progressBar.progress = (goal.currentValue * 100).toInt()

                buttonUpdateProgress.setOnClickListener {
                    val newValue = editTextProgress.text.toString().toDoubleOrNull()
                    if (newValue != null) {
                        onProgressUpdate(goal.id, newValue)
                        editTextProgress.text?.clear()
                    }
                }

                buttonDelete.setOnClickListener {
                    onDelete(goal.id)
                }
            }
        }
    }

    private class GoalDiffCallback : DiffUtil.ItemCallback<UserGoal>() {
        override fun areItemsTheSame(oldItem: UserGoal, newItem: UserGoal): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: UserGoal, newItem: UserGoal): Boolean {
            return oldItem == newItem
        }
    }
} 