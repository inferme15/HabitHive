package com.example.habithive.ui.goals

import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter

class GoalsPagerAdapter(fragment: Fragment) : FragmentStateAdapter(fragment) {

    override fun getItemCount(): Int = 2

    override fun createFragment(position: Int): Fragment {
        return GoalsListPageFragment.newInstance(
            when (position) {
                0 -> GoalStatus.ACTIVE
                1 -> GoalStatus.COMPLETED
                else -> throw IllegalStateException("Invalid position: $position")
            }
        )
    }
} 